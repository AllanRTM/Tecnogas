/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

/**
 *
 * @author radioshack
 */
import java.sql.*;
import javax.swing.JOptionPane;
import org.apache.log4j.Logger;
import q.login;

public class conexion {
     final static Logger logger = Logger.getLogger(conexion.class);
    static Connection conect = null;
     
    public static Connection conexion()
       {
           try{
              
            conect = DriverManager.getConnection("jdbc:mysql://localhost:3306/tecnogasprueba?useTimezone=true&serverTimezone=UTC","root","onepiece");
                
              
           }catch ( SQLException e) {
               JOptionPane.showMessageDialog(null, "Error en la conexion:" + e);
               logger.fatal("Error: "+e.getMessage());
        
          }
       return conect;
       }
     
     

    public Statement createStatement() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
