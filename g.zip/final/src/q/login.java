/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q;
import static com.mysql.cj.conf.PropertyKey.logger;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.log4j.Logger;

import org.apache.log4j.BasicConfigurator;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import org.apache.log4j.PropertyConfigurator;
import servicios.conexion;
import sistematecnogas.panelEmpleado;
import sistematecnogas.panelcentral;

/**
 *
 * @author radioshack
 */
public class login extends javax.swing.JFrame {

    /**
     * Creates new form login
     */
    conexion cc = new conexion();
    Connection cn = conexion.conexion();
    

    final static Logger logger = Logger.getLogger(login.class);
    //Logger = LogManager.getRootLogger();
    
    String m;
		
    
    public login() {
        
        initComponents();
        setLocationRelativeTo(null);
        usuario.requestFocus();
        fecha_pantalla.setText(fecha());
        setTitle("Ingreso al sistema");
        PropertyConfigurator.configure("log4j.properties");
       //setIconImage(new ImageIcon(getClass().getResource("/Imagen/image.png")).getImage());
    }
    int timer=0;
    
    
    public static String fecha(){
    Date fecha = new Date();
    SimpleDateFormat formatofecha = new SimpleDateFormat("dd/MM/YYYY");
    return formatofecha.format(fecha);
    }
    
   void bo(String dato){
   String cap1="";
        String sql="SELECT * FROM `usuariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo2(String dato){
   String cap1="";
        String sql="SELECT * FROM `proveedorrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.proveedores.setVisible(true);
            
            }
            else{
                panelcentral.proveedores.setVisible(false);
                panelcentral.jLabel2.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo3(String dato){
   String cap1="";
        String sql="SELECT * FROM `categoriarol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.categorias.setVisible(true);
            
            }
            else{
                panelcentral.categorias.setVisible(false);
                panelcentral.jLabel6.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo4(String dato){
   String cap1="";
        String sql="SELECT * FROM `bombasrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.bombas.setVisible(true);
            
            }
            else{
                panelcentral.jLabel5.setVisible(false);
                panelcentral.bombas.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo5(String dato){
   String cap1="";
        String sql="SELECT * FROM `productorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.productos.setVisible(true);
            
            }
            else{
                panelcentral.productos.setVisible(false);
                panelcentral.jLabel9.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo6(String dato){
   String cap1="";
        String sql="SELECT * FROM `seriedigitalrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario6.setVisible(true);
            
            }
            else{
                panelcentral.jLabel8.setVisible(false);
                panelcentral.usuario6.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo7(String dato){
   String cap1="";
        String sql="SELECT * FROM `inventariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario4.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo8(String dato){
   String cap1="";
        String sql="SELECT * FROM `preciorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.control.setVisible(true);
            
            }
            else{
                panelcentral.usuario4.setVisible(false);
                panelcentral.jLabel10.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
        
          
   
   void acceder(String usuario, String pass)
    {
    
       String cap="";
       String qw ="";
       String sql="SELECT * FROM `usuarios` WHERE `nombre`='"+usuario+"' && `contraseña`=MD5('"+pass+"')";
        try {
            
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("tipo_usuario");
                qw=rs.getString("estado_usuario");
                
            }
            if(cap.equals("Administrador") && qw.equals("Activo"))
            {
                
                   
                    this.setVisible(false);
                    panelcentral ingreso = new panelcentral();
                     bo(usuario);
                     bo2(usuario);
                     bo3(usuario);
                     bo4(usuario);
                     bo5(usuario);
                     bo6(usuario);
                     bo7(usuario);
                     bo8(usuario);
                    logger.debug("Se logueo usuario administrador: "+ usuario);
                    panelcentral.User.setText(usuario);
                    ingreso.setVisible(true);
                    ingreso.pack();
                    //
                    
                    //
                    
             
            }
            else if (cap.equals("Empleado") && qw.equals("Activo")) {
                    
                    this.setVisible(false);
                    panelcentral ingreso = new panelcentral();
                     bo(usuario);
                     bo2(usuario);
                     bo3(usuario);
                     bo4(usuario);
                     bo5(usuario);
                     bo6(usuario);
                     bo7(usuario);
                     bo8(usuario);
                    logger.debug("Se logueo usuario empleado: "+ usuario);
                    panelcentral.User.setText(usuario);
                    ingreso.setVisible(true);
                    
            }
            
            if(qw.equals("Inactivo"))
            {
             error1.setText("");
             error3.setText("Su usuario ya no trabaja en nuestra empresa ó se bloqueo !!");
                   
            }
            if((!qw.equals("Activo"))&& (!qw.equals("Inactivo")))
            {
                
                error1.setText("No existe el usuario ó contraseña !!");
                //error3.setText("te quedan "+(3-timer)+" intentos");
                if (timer==4) {
                  timer = 0;  
                }else{
                 timer = timer +1;
                }
               
            }
            if (timer==3) {
                 error1.setText("El usuario bloqueado!!");
                 JOptionPane.showMessageDialog(rootPane, "Se bloqueo el usuario contacta al administrador");
                 String consu ="UPDATE `usuarios` SET `estado_usuario` = 'Inactivo' WHERE `usuarios`.`nombre` = '"+usuario+"'";
                 st.executeUpdate(consu);
                 timer = 0;
            }
        } catch (Exception  ex) {
            logger.fatal("Error: "+ex.getMessage());
            JOptionPane.showMessageDialog(rootPane, ex);
            
  
        }
       
        }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        botonLogin = new javax.swing.JButton();
        contraseña = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        label_iconotecnogas = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        fecha_pantalla = new javax.swing.JLabel();
        usuario = new javax.swing.JTextField();
        error1 = new javax.swing.JLabel();
        error3 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 0, 204));
        setForeground(new java.awt.Color(204, 255, 255));
        setIconImages(null);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        botonLogin.setBackground(new java.awt.Color(204, 204, 204));
        botonLogin.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        botonLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/nave.png"))); // NOI18N
        botonLogin.setText("Ingresar");
        botonLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonLoginMouseClicked(evt);
            }
        });
        botonLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonLoginActionPerformed(evt);
            }
        });
        botonLogin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                botonLoginKeyPressed(evt);
            }
        });
        getContentPane().add(botonLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, -1, 47));

        contraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contraseñaActionPerformed(evt);
            }
        });
        getContentPane().add(contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 230, 210, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Ingrese nombre de usuario:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 130, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Contraseña:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 200, -1, -1));

        label_iconotecnogas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/logo_tecnogas_transp.png"))); // NOI18N
        label_iconotecnogas.setText("jLabel4");
        label_iconotecnogas.setPreferredSize(new java.awt.Dimension(270, 134));
        getContentPane().add(label_iconotecnogas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 230, 130));

        jLabel1.setText("Fecha:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 30, -1, -1));

        fecha_pantalla.setText("dd-MM-YYYY");
        getContentPane().add(fecha_pantalla, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 30, -1, -1));

        usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usuarioActionPerformed(evt);
            }
        });
        usuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                usuarioKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                usuarioKeyTyped(evt);
            }
        });
        getContentPane().add(usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 160, 210, -1));

        error1.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        error1.setForeground(new java.awt.Color(255, 0, 51));
        error1.setText("...");
        getContentPane().add(error1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 270, 210, -1));

        error3.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        error3.setForeground(new java.awt.Color(255, 0, 51));
        error3.setText("...");
        getContentPane().add(error3, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 290, 350, 20));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(51, 153, 255));
        jLabel17.setText("¡BIENVENIDO!");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 50, -1, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/fondo5.jpg"))); // NOI18N
        fondo.setText("jLabel4");
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 730, 460));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonLoginActionPerformed

        String usu=usuario.getText();
        String pas=new String(contraseña.getPassword());
        acceder(usu, pas);

    }//GEN-LAST:event_botonLoginActionPerformed

    private void contraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contraseñaActionPerformed

    private void usuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usuarioActionPerformed
        // TODO add your handling code here:
        usuario.requestFocus();
    }//GEN-LAST:event_usuarioActionPerformed

    private void usuarioKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_usuarioKeyReleased
        // TODO add your handling code here:
        if (!usuario.getText().isEmpty()) {
            error1.setText("");
            error3.setText("");
        }
        
    }//GEN-LAST:event_usuarioKeyReleased

    private void usuarioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_usuarioKeyTyped
        // TODO add your handling code here:
        
        error3.setText("");
    }//GEN-LAST:event_usuarioKeyTyped

    private void botonLoginKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botonLoginKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonLoginKeyPressed

    private void botonLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonLoginMouseClicked
        // TODO add your handling code here:
        
        
        //panelcentral.usuaoo.setText(usuario.getText());
        
    }//GEN-LAST:event_botonLoginMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new login().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonLogin;
    private javax.swing.JPasswordField contraseña;
    private javax.swing.JLabel error1;
    private javax.swing.JLabel error3;
    private javax.swing.JLabel fecha_pantalla;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel label_iconotecnogas;
    public static javax.swing.JTextField usuario;
    // End of variables declaration//GEN-END:variables
}
