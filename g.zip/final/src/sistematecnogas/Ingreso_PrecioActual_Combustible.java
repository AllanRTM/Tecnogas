/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistematecnogas;

import Atxy2k.CustomTextField.RestrictedTextField;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import servicios.conexion;
import static sistematecnogas.Categoria.useCategoria;
import static sistematecnogas.Control_Combustible_Diario.logger;
import static sistematecnogas.Proveedores.prove;

/**
 *
 * @author Wilfredo Serrano
 */
public class Ingreso_PrecioActual_Combustible extends javax.swing.JFrame {
final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(Ingreso_PrecioActual_Combustible.class);
    
    //valores_conection
  
    conexion cc = new conexion();
    Connection cn = conexion.conexion();
    PreparedStatement ps;
    ResultSet rs;
    public void limitar(){
    
    RestrictedTextField limitar1 =new RestrictedTextField(caja_litro_super);
    limitar1.setLimit(13);
  
    
    
    }
    public static String fecha(){
    Date fecha = new Date();
    SimpleDateFormat formatofecha = new SimpleDateFormat("dd/MM/YYYY");
           return formatofecha.format(fecha);
    }
    public void Valida(){
        if (caja_litro_super.getText().isEmpty()) {
            error1.setText("No puede estar vacio !!");
        } else {
            error1.setText("");
        }   
    } 
    
    void mostrartipoproducto(){
       String sql="SELECT * FROM `tipo_combustible`";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                iidtipocomb.addItem(rs.getString("id_tipo_combustible"));
            }
        } catch (java.sql.SQLException ex) {
            Logger.getLogger(Proveedores.class.getName()).log(Level.SEVERE, null, ex);
        }
       
   }
    void cargar(String valor){
    /*String mostrar="SELECT * FROM `categoria` WHERE '%"+valor+"%'";*/
    String mostrar="SELECT `id_precio_combustible`, `precio`, `id_tipo_combustible`, `decha_precio_combustible` FROM `precio_combustible` WHERE `id_precio_combustible` LIKE '%"+valor+"%'";
    String []titulos={"ID de precio","Precio","ID combustible","Fecha"};
    String []Registros=new String[4];
    DefaultTableModel model = new DefaultTableModel(null,titulos);
  
        try {
              Statement st = cn.createStatement();
              java.sql.ResultSet rs = st.executeQuery(mostrar);
              
              while(rs.next())
              {
                  Registros[0]= rs.getString("id_precio_combustible");
                  Registros[1]= rs.getString("precio");
                  Registros[2]= rs.getString("id_tipo_combustible");
                  Registros[3]= rs.getString("decha_precio_combustible");
                  
                  
                           
                  model.addRow(Registros);
              }
              tabla.setModel(model);
        } catch (java.sql.SQLException ex) {
            Logger.getLogger(Proveedores.class.getName()).log(Level.SEVERE, null, ex);
        }
    
  }
    
    
    public void limpiarcajas(){
    caja_litro_super.setText(null);
    iidtipocomb.setSelectedIndex(0);
    idtipo.setText(null);
    id.setText(null);
    fecha_pantalla.setText(null);
    JOptionPane.showMessageDialog(null, "Cajas de texto limpiadas!!");
   
    };
   
    
    
    public Ingreso_PrecioActual_Combustible() {
        initComponents();
       mostrartipoproducto();
        limitar();
        cargar("");
        setLocationRelativeTo(null);
       
        fecha_pantalla.setText(fecha());
        setTitle("Precio Actual de Combustible");
        //setIconImage(new ImageIcon(getClass().getResource("/Imagen/logo_tecnogas_transp.png")).getImage());
        
    }
    
     void bo(String dato){
   String cap1="";
        String sql="SELECT * FROM `usuariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo2(String dato){
   String cap1="";
        String sql="SELECT * FROM `proveedorrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.proveedores.setVisible(true);
            
            }
            else{
                panelcentral.proveedores.setVisible(false);
                panelcentral.jLabel2.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo3(String dato){
   String cap1="";
        String sql="SELECT * FROM `categoriarol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.categorias.setVisible(true);
            
            }
            else{
                panelcentral.categorias.setVisible(false);
                panelcentral.jLabel6.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo4(String dato){
   String cap1="";
        String sql="SELECT * FROM `bombasrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.bombas.setVisible(true);
            
            }
            else{
                panelcentral.jLabel5.setVisible(false);
                panelcentral.bombas.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo5(String dato){
   String cap1="";
        String sql="SELECT * FROM `productorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.productos.setVisible(true);
            
            }
            else{
                panelcentral.productos.setVisible(false);
                panelcentral.jLabel9.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo6(String dato){
   String cap1="";
        String sql="SELECT * FROM `seriedigitalrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario6.setVisible(true);
            
            }
            else{
                panelcentral.jLabel8.setVisible(false);
                panelcentral.usuario6.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo7(String dato){
   String cap1="";
        String sql="SELECT * FROM `inventariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario4.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo8(String dato){
   String cap1="";
        String sql="SELECT * FROM `preciorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.control.setVisible(true);
            
            }
            else{
                panelcentral.usuario4.setVisible(false);
                panelcentral.jLabel10.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    
        
    
    
    
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        fecha_pantalla = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        buttom_insert_preciosuper = new javax.swing.JButton();
        caja_litro_super = new javax.swing.JTextField();
        error1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        id = new javax.swing.JLabel();
        idtipo = new javax.swing.JLabel();
        iidtipocomb = new javax.swing.JComboBox();
        buscar = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        buttom_limpiar = new javax.swing.JToggleButton();
        buttom_modificar = new javax.swing.JToggleButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        error2 = new javax.swing.JLabel();
        usePrecioActual = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        annu1 = new javax.swing.JLabel();
        annu = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        jLabel5.setText("jLabel5");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 89, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("Introduzca precio de combustible: ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 148, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("Usuario:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

        fecha_pantalla.setText("dd/MM/YYYY");
        getContentPane().add(fecha_pantalla, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 60, 100, -1));

        jButton1.setText("Atrás");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 381, 110, -1));

        jLabel8.setText("Litro");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(345, 149, -1, -1));

        jLabel10.setText("L.");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(212, 149, -1, -1));

        buttom_insert_preciosuper.setText("Inserte precio actual");
        buttom_insert_preciosuper.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttom_insert_preciosuperActionPerformed(evt);
            }
        });
        getContentPane().add(buttom_insert_preciosuper, new org.netbeans.lib.awtextra.AbsoluteConstraints(422, 195, -1, -1));

        caja_litro_super.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                caja_litro_superActionPerformed(evt);
            }
        });
        caja_litro_super.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                caja_litro_superKeyTyped(evt);
            }
        });
        getContentPane().add(caja_litro_super, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 146, 115, -1));

        error1.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        error1.setForeground(new java.awt.Color(255, 0, 51));
        error1.setText("...");
        getContentPane().add(error1, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 175, 215, -1));

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Galones Recibidos", "Recibidos in³", "Inventario Inicial", "Inventario Inicial in³", "Litros Faltantes", "Litros Faltantes in³", "Despachado", "Despachado in³", "Inventario Final", "Inventario Final in³", "ID Usuario", "Tipo Combustible"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, true, true, false, false, false, false, true, true, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 244, 567, 92));

        id.setText("...");
        getContentPane().add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(349, 58, 36, -1));

        idtipo.setText("...");
        getContentPane().add(idtipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(349, 89, 36, -1));

        iidtipocomb.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Seleccione.." }));
        iidtipocomb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iidtipocombActionPerformed(evt);
            }
        });
        iidtipocomb.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                iidtipocombKeyPressed(evt);
            }
        });
        getContentPane().add(iidtipocomb, new org.netbeans.lib.awtextra.AbsoluteConstraints(422, 146, 127, -1));

        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });
        buscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buscarKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                buscarKeyTyped(evt);
            }
        });
        getContentPane().add(buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(78, 219, 55, -1));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel21.setText("Buscar: ");
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 64, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel18.setText("1. Super");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(476, 89, 78, -1));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel19.setText("2. Diesel");
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(476, 110, 78, -1));

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel20.setText("Tipos:");
        getContentPane().add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(422, 91, -1, -1));

        buttom_limpiar.setText("Limpiar");
        buttom_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttom_limpiarActionPerformed(evt);
            }
        });
        getContentPane().add(buttom_limpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(241, 381, 110, -1));

        buttom_modificar.setText("Modificar");
        buttom_modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttom_modificarActionPerformed(evt);
            }
        });
        getContentPane().add(buttom_modificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(467, 381, 110, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("ID combustible:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 57, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setText("ID tipo de combustible:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 89, -1, 13));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(51, 153, 255));
        jLabel22.setText("Precio actual de combustible");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 10, -1, -1));

        error2.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        error2.setForeground(new java.awt.Color(255, 0, 51));
        error2.setText("...");
        getContentPane().add(error2, new org.netbeans.lib.awtextra.AbsoluteConstraints(143, 221, 215, -1));

        usePrecioActual.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        usePrecioActual.setText("....");
        getContentPane().add(usePrecioActual, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 90, 60, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setText("Fecha actual:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 57, -1, -1));

        annu1.setText("....");
        getContentPane().add(annu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 410, 110, -1));

        annu.setText("....");
        getContentPane().add(annu, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 220, 130, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/fondo5.jpg"))); // NOI18N
        fondo.setText("jLabel4");
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 440));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
panelcentral botonatras = new panelcentral();
botonatras.setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1MouseClicked

    private void buttom_insert_preciosuperActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttom_insert_preciosuperActionPerformed
        String cap="";
         
        String sql="SELECT * FROM `preciorol` WHERE `nombre` = '"+usePrecioActual.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("insertar"); 
            }
            if(cap.equals("Activo"))
            {
             Valida();
        
        try{
            
            ps = (PreparedStatement) cn.prepareStatement("INSERT INTO `precio_combustible` (`id_precio_combustible`, `precio`, `id_tipo_combustible`, `decha_precio_combustible`) VALUES (NULL, ?, ?, SYSDATE())");
            if (caja_litro_super.getText().isEmpty()) {
                error1.setText("No puede haber campos vacios !!"); 
            }
            if (Double.parseDouble(caja_litro_super.getText())==0) {
                error1.setText("No puede ser cero !!");
            } else{
                ps.setString(1,caja_litro_super.getText());
            }
            //ps.setString(1,caja_litro_super.getText());
            ps.setString(2, (String) iidtipocomb.getSelectedItem());
            int resultado = ps.executeUpdate(); //ejecutamos la inserción en la base de datos
            
            if (resultado > 0){
                JOptionPane.showMessageDialog(null, "Registro insertado correctamente.");
                limpiarcajas();
                cargar("");
                
            }else{
                    JOptionPane.showMessageDialog(null, "Error al insertar el registro.");}
 
        }catch(Exception e){
            error1.setText("Ingresa todos los datos !!");            
        }
                
                
            }
            else{
            buttom_insert_preciosuper.setEnabled(true);
            annu.setText("No tienes permiso");
            logger.info("El usuario "+usePrecioActual.getText()+" inserto precio actual. ");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.fatal("Error: "+ex);
            
        }  
        
        
        
    }//GEN-LAST:event_buttom_insert_preciosuperActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
       panelcentral ingresar = new panelcentral();
       ingresar.setVisible(true);   
       panelcentral.User.setText(usePrecioActual.getText());
       this.dispose();
                     bo(usePrecioActual.getText());
                     bo2(usePrecioActual.getText());
                     bo3(usePrecioActual.getText());
                     bo4(usePrecioActual.getText());
                     bo5(usePrecioActual.getText());
                     bo6(usePrecioActual.getText());
                     bo7(usePrecioActual.getText());
                     bo8(usePrecioActual.getText());
    }//GEN-LAST:event_jButton1ActionPerformed

    private void caja_litro_superKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_caja_litro_superKeyTyped
        // TODO add your handling code here:
          char validar =evt.getKeyChar();
        
        if(Character.isLetter(validar)||Character.isSpaceChar(validar)){
        getToolkit().beep();
        evt.consume();
        error1.setText("Solo numeros y sin espacios !!");
        }
        if(!Character.isDigit(evt.getKeyChar())&& evt.getKeyChar()!='.' ){
            evt.consume();
  }        if(evt.getKeyChar()=='.'&&caja_litro_super.getText().contains(".")){
          evt.consume(); }
    }//GEN-LAST:event_caja_litro_superKeyTyped

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
        // TODO add your handling code here:
        int seleccionar = tabla.rowAtPoint(evt.getPoint());
        id.setText(String.valueOf(tabla.getValueAt(seleccionar,0)));
        caja_litro_super.setText(String.valueOf(tabla.getValueAt(seleccionar,1)));
        idtipo.setText(String.valueOf(tabla.getValueAt(seleccionar,2)));
        fecha_pantalla.setText(String.valueOf(tabla.getValueAt(seleccionar,3)));
        

    }//GEN-LAST:event_tablaMouseClicked

    private void iidtipocombActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iidtipocombActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iidtipocombActionPerformed

    private void iidtipocombKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_iidtipocombKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_iidtipocombKeyPressed

    private void buscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_buscarKeyReleased
        // TODO add your handling code here:
        cargar(buscar.getText());
    }//GEN-LAST:event_buscarKeyReleased

    private void buttom_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttom_limpiarActionPerformed
        // TODO add your handling code here:
         limpiarcajas();
    }//GEN-LAST:event_buttom_limpiarActionPerformed

    private void buttom_modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttom_modificarActionPerformed
        // TODO add your handling code here:
        
        String cap="";
         
        String sql="SELECT * FROM `preciorol` WHERE `nombre` = '"+usePrecioActual.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("modificar"); 
            }
            if(cap.equals("Activo"))
            {
             try {
            
            String re="";
            int rr =0;
            if (caja_litro_super.getText().isEmpty()) {
                error1.setText("No puede haber campos vacios !!"); 
            }
            if (Double.parseDouble(caja_litro_super.getText())==0) {
                error1.setText("No puede ser cero !!");
            } else{
                 re= caja_litro_super.getText();
                
            }
            
             

            String consulta = "UPDATE `precio_combustible` SET `precio` = '"+re+"', `id_tipo_combustible` = ?, `decha_precio_combustible` = SYSDATE() WHERE `precio_combustible`.`id_precio_combustible` = '"+id.getText()+"'";
            PreparedStatement pst  = cn.prepareStatement(consulta);
            pst.setString(1, iidtipocomb.getSelectedItem().toString());

            

            int resultado = pst.executeUpdate(); //ejecutamos la inserción en la base de datos
            
            if (resultado > 0){
                JOptionPane.showMessageDialog(null, "Registro actualizado correctamente.");
                limpiarcajas();
                cargar("");
                
            }else{
            
            }
                
            
           

        } catch (java.sql.SQLException ex) {
            error1.setText("No puede haber campos vacios !!");

        }
                
            }
            else{
            buttom_insert_preciosuper.setEnabled(true);
            annu1.setText("No tienes permiso");
            logger.info("El usuario "+usePrecioActual.getText()+" inserto precio actual. ");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.fatal("Error: "+ex);
            
        }  
        
         
    }//GEN-LAST:event_buttom_modificarActionPerformed

    private void caja_litro_superActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_caja_litro_superActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_caja_litro_superActionPerformed

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        // TODO add your handling code here:
        cargar(buscar.getText());
    }//GEN-LAST:event_buscarActionPerformed

    private void buscarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_buscarKeyTyped
        // TODO add your handling code here:
         char validar =evt.getKeyChar();
        
        if(Character.isLetter(validar)){
        getToolkit().beep();
        evt.consume();
        error2.setText("Solo se puede buscar por ID !!");
        }
    }//GEN-LAST:event_buscarKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ingreso_PrecioActual_Combustible.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ingreso_PrecioActual_Combustible.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ingreso_PrecioActual_Combustible.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ingreso_PrecioActual_Combustible.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ingreso_PrecioActual_Combustible().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel annu;
    private javax.swing.JLabel annu1;
    private javax.swing.JTextField buscar;
    private javax.swing.JButton buttom_insert_preciosuper;
    private javax.swing.JToggleButton buttom_limpiar;
    private javax.swing.JToggleButton buttom_modificar;
    private javax.swing.JTextField caja_litro_super;
    private javax.swing.JLabel error1;
    private javax.swing.JLabel error2;
    private javax.swing.JLabel fecha_pantalla;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel id;
    private javax.swing.JLabel idtipo;
    private javax.swing.JComboBox iidtipocomb;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabla;
    public static javax.swing.JLabel usePrecioActual;
    // End of variables declaration//GEN-END:variables
}
