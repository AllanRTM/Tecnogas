/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistematecnogas;

import Atxy2k.CustomTextField.RestrictedTextField;
import java.sql.*;

import servicios.conexion;
import javax.swing.table.DefaultTableModel;

import javax.swing.JOptionPane;
import static sistematecnogas.Categoria.fecha;
import static sistematecnogas.Categoria.useCategoria;
import static sistematecnogas.Control_Combustible_Diario.logger;




/**
 *
 * @author Wilfredo Serrano
 */
public class Productos extends javax.swing.JFrame {
 final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(Productos.class);
    
    conexion cc=new conexion();
    Connection cn = conexion.conexion();
    java.sql.Statement sent;
    DefaultTableModel model;
    
     
    public Productos() {
      initComponents();
      setLocationRelativeTo(null);
      validar();
      fechaActual.setText(fecha());
      m1();
      limita();
      Llenar();
      
     //ImageIcon Img = new ImageIcon(getClass().getResource("/Imagen/logo_tecnogas_transp.png"));
     //setIconImage(new ImageIcon(getClass().getResource("/Imagen/logo_tecnogas_transp.png")).getImage());
     
    validacion1.setVisible(false);
    validacion2.setVisible(false);
    txtactualizacion.setVisible(false);
    txtcreacion.setVisible(false);
      
      //categoria
            try{
        sent=cn.createStatement();
        String sql="SELECT * FROM `categoria_productos` WHERE `estado` = 'activo'";
             java.sql.Statement st=cn.createStatement();
        java.sql.ResultSet rs=sent.executeQuery(sql);
        cmbcategoria.addItem("seleccione producto");
        while(rs.next()){
         
            this.cmbcategoria.addItem(rs.getString("categoria"));
        }
        }catch(Exception e){
            
        }
            
       //estado

        try{
        sent=cn.createStatement();
        String sql="SELECT * FROM `estado` ";
        java.sql.Statement st=cn.createStatement();
        java.sql.ResultSet rs=sent.executeQuery(sql);
        cmbestado.addItem("seleccione estado");
        while(rs.next()){
         
            this.cmbestado.addItem(rs.getString("estado"));
        }
        }catch(Exception e){
            
        }       
                    
       try{
        sent=cn.createStatement();
        String sql="SELECT * FROM `usuarios` WHERE `estado_usuario` = 'activo'";
             java.sql.Statement st=cn.createStatement();
        java.sql.ResultSet rs=sent.executeQuery(sql);
        cmbusuario.addItem("seleccione usuario");
        while(rs.next()){
         
            this.cmbusuario.addItem(rs.getString("nombre"));
        }
        }catch(Exception e){
            
        }        
            
                    
       
     
    }
    
    public void limita(){
   txtnombre.setDocument(new limitar(txtnombre,3,12));
   txtprecio.setDocument(new limitar(txtprecio,1,12));
    }
    
    
    void validar(){
    RestrictedTextField limitar0 =new RestrictedTextField(txtnombre);
    limitar0.setLimit(11);
    
    
    RestrictedTextField limitar1 =new RestrictedTextField(txtprecio);
    limitar1.setLimit(11);
    
    }
    

    
    
     void Limpiar(){
        txtnombre.setText("");
        txtid.setText("");
        txtprecio.setText("");
        cmbcategoria.setSelectedIndex(0);
        cmbestado.setSelectedIndex(0);
        cmbusuario.setSelectedIndex(0);
        JOptionPane.showMessageDialog(null,"Casillas han sido borradas");  
    }
    
    void Habilitar(){
        txtnombre.setEditable(true);
        txtprecio.setEditable(true);
        txtnombre.requestFocus();
    }
    public void m(String valor){
    String[]  titulos={"ID","Nombre","Precio","Fecha de creación","Fecha de actualización","Categoría","Estado","Usuario"};

    String[] registros=new String[50];
    String sql="SELECT * FROM `productos` WHERE id_producto LIKE '%"+valor+"%' "
    +"OR nombre_producto LIKE '%"+valor+"%'";
            
    
    model= new DefaultTableModel(null,titulos);
   
    try{
        java.sql.Statement st = (java.sql.Statement) cn.createStatement();
        java.sql.ResultSet rs = st.executeQuery(sql);
        while(rs.next()){ 
            registros[0]=rs.getString("id_producto");
            registros[1]=rs.getString("nombre_producto");
            registros[2]=rs.getString("precio_producto");
            registros[3]=rs.getString("fecha_creacion");
            registros[4]=rs.getString("fecha_actualizacion");
            registros[5]=rs.getString("id_categoria_productos");
            registros[6]=rs.getString("estado_productos");
            registros[7]=rs.getString("id_usuario");
              model.addRow(registros);
        }
          tablaproductos.setModel(model);
    }catch(java.sql.SQLException ex){
       JOptionPane.showMessageDialog(null,ex);
        
    }
    
    }
    
    
        void Llenar(){
        try{
           
            String [] titulos={"ID","Nombre","Precio","Fecha de creacion","Fecha de actualizacion","Categoria","Estado","Usuario"};

            String sql="SELECT `id_producto`, `nombre_producto`, `precio_producto`, `fecha_creacion`, `fecha_actualizacion`, `id_usuario`, `estado_productos`, `id_categoria_productos` FROM `productos` WHERE 1";
            model=new DefaultTableModel(null, titulos);
            sent=cn.createStatement();
            java.sql.ResultSet rs=sent.executeQuery(sql);
            String fila []= new String [8];
            while(rs.next()){
            fila[0]=rs.getString("id_producto");
            fila[1]=rs.getString("nombre_producto");
            fila[2]=rs.getString("precio_producto");
            fila[3]=rs.getString("fecha_creacion");
            fila[4]=rs.getString("fecha_Actualizacion");
            fila[5]=rs.getString("id_categoria_productos");
            fila[6]=rs.getString("estado_productos");
            fila[7]=rs.getString("id_usuario");
               model.addRow(fila);
            }tablaproductos.setModel(model); 
        }catch(Exception e){
            e.printStackTrace();   
        }
    }
        
    public void m1(){
    String[]  titulos={"ID","Nombre","Precio","Fecha de creacion","Fecha de actualizacion","Categoria","Estado","Usuario"};

    String[] registros=new String[50];
    String sql="SELECT `id_producto`, `nombre_producto`, `precio_producto`, `fecha_creacion`, `fecha_actualizacion`, `id_usuario`, `estado_productos`, `id_categoria_productos` FROM `productos` WHERE 1";
            
    
    model= new DefaultTableModel(null,titulos);
   
    try{
        java.sql.Statement st = (java.sql.Statement) cn.createStatement();
        java.sql.ResultSet rs = st.executeQuery(sql);
        while(rs.next()){ 
            registros[0]=rs.getString("id_producto");
            registros[1]=rs.getString("nombre_producto");
            registros[2]=rs.getString("precio_producto");
            registros[3]=rs.getString("fecha_creacion");
            registros[4]=rs.getString("fecha_actualizacion");
            registros[5]=rs.getString("id_categoria_productos");
            registros[6]=rs.getString("estado_productos");
            registros[7]=rs.getString("id_usuario");
              model.addRow(registros);
        }
          tablaproductos.setModel(model);
    }catch(java.sql.SQLException ex){
       JOptionPane.showMessageDialog(null,ex);
        
    }}
    
     void bo(String dato){
   String cap1="";
        String sql="SELECT * FROM `usuariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo2(String dato){
   String cap1="";
        String sql="SELECT * FROM `proveedorrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.proveedores.setVisible(true);
            
            }
            else{
                panelcentral.proveedores.setVisible(false);
                panelcentral.jLabel2.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo3(String dato){
   String cap1="";
        String sql="SELECT * FROM `categoriarol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.categorias.setVisible(true);
            
            }
            else{
                panelcentral.categorias.setVisible(false);
                panelcentral.jLabel6.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo4(String dato){
   String cap1="";
        String sql="SELECT * FROM `bombasrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.bombas.setVisible(true);
            
            }
            else{
                panelcentral.jLabel5.setVisible(false);
                panelcentral.bombas.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo5(String dato){
   String cap1="";
        String sql="SELECT * FROM `productorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.productos.setVisible(true);
            
            }
            else{
                panelcentral.productos.setVisible(false);
                panelcentral.jLabel9.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo6(String dato){
   String cap1="";
        String sql="SELECT * FROM `seriedigitalrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario6.setVisible(true);
            
            }
            else{
                panelcentral.jLabel8.setVisible(false);
                panelcentral.usuario6.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo7(String dato){
   String cap1="";
        String sql="SELECT * FROM `inventariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario4.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo8(String dato){
   String cap1="";
        String sql="SELECT * FROM `preciorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.control.setVisible(true);
            
            }
            else{
                panelcentral.usuario4.setVisible(false);
                panelcentral.jLabel10.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtnombre = new javax.swing.JTextField();
        txtprecio = new javax.swing.JTextField();
        txtbuscar = new javax.swing.JTextField();
        cmbestado = new javax.swing.JComboBox<>();
        cmbusuario = new javax.swing.JComboBox<>();
        cmbcategoria = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaproductos = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        btnguardar = new javax.swing.JButton();
        btnmodificar = new javax.swing.JButton();
        btnnuevo = new javax.swing.JButton();
        txtid = new javax.swing.JLabel();
        leyenda1 = new javax.swing.JLabel();
        leyenda2 = new javax.swing.JLabel();
        btnatras = new javax.swing.JButton();
        validacion1 = new javax.swing.JLabel();
        validacion2 = new javax.swing.JLabel();
        txtactualizacion = new javax.swing.JLabel();
        txtcreacion = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        label_iconotecnogas = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        annu1 = new javax.swing.JLabel();
        annu = new javax.swing.JLabel();
        useProductos = new javax.swing.JLabel();
        fechaActual = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Nombre del producto:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 84, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Precio:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(368, 84, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Buscar:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 291, -1, -1));

        txtnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnombreActionPerformed(evt);
            }
        });
        txtnombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtnombreKeyTyped(evt);
            }
        });
        getContentPane().add(txtnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 105, 86, -1));

        txtprecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtprecioActionPerformed(evt);
            }
        });
        txtprecio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtprecioKeyTyped(evt);
            }
        });
        getContentPane().add(txtprecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(368, 105, 86, -1));

        txtbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbuscarActionPerformed(evt);
            }
        });
        txtbuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtbuscarKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtbuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 290, 114, -1));

        cmbestado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbestadoActionPerformed(evt);
            }
        });
        getContentPane().add(cmbestado, new org.netbeans.lib.awtextra.AbsoluteConstraints(199, 230, 160, 20));

        cmbusuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbusuarioActionPerformed(evt);
            }
        });
        getContentPane().add(cmbusuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(393, 230, 160, 20));

        cmbcategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbcategoriaActionPerformed(evt);
            }
        });
        getContentPane().add(cmbcategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 160, 20));

        tablaproductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Id de Producto", "Estado", "Categoria", "Precio", "Fecha de Creacion", "Fecha de Actualiacion ", "Usuario"
            }
        ));
        tablaproductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaproductosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaproductos);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 319, 820, 120));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("ID del producto:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 84, -1, -1));

        btnguardar.setText("Ingresar");
        btnguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnguardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(581, 229, 110, -1));

        btnmodificar.setText("Modificar");
        btnmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmodificarActionPerformed(evt);
            }
        });
        getContentPane().add(btnmodificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 457, 115, -1));

        btnnuevo.setText("Limpiar");
        btnnuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnuevoActionPerformed(evt);
            }
        });
        getContentPane().add(btnnuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(324, 457, 110, -1));
        getContentPane().add(txtid, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 105, 86, 19));

        leyenda1.setForeground(new java.awt.Color(255, 0, 51));
        leyenda1.setText(". . .");
        getContentPane().add(leyenda1, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 130, 86, -1));

        leyenda2.setForeground(new java.awt.Color(255, 0, 51));
        leyenda2.setText(". . .");
        getContentPane().add(leyenda2, new org.netbeans.lib.awtextra.AbsoluteConstraints(368, 130, -1, -1));

        btnatras.setText("Atrás");
        btnatras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnatrasActionPerformed(evt);
            }
        });
        getContentPane().add(btnatras, new org.netbeans.lib.awtextra.AbsoluteConstraints(59, 457, 110, -1));

        validacion1.setForeground(new java.awt.Color(255, 0, 51));
        validacion1.setText("*");
        getContentPane().add(validacion1, new org.netbeans.lib.awtextra.AbsoluteConstraints(259, 108, -1, -1));

        validacion2.setForeground(new java.awt.Color(255, 0, 51));
        validacion2.setText("*");
        getContentPane().add(validacion2, new org.netbeans.lib.awtextra.AbsoluteConstraints(458, 108, -1, -1));
        getContentPane().add(txtactualizacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(554, 39, -1, -1));
        getContentPane().add(txtcreacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(554, 45, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Categoría de producto");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 205, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("Estado de producto ");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(199, 205, -1, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("Usuarios");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(393, 205, -1, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(51, 153, 255));
        jLabel17.setText("Productos");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(331, 10, 171, -1));

        label_iconotecnogas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/logo_tecnogas_transp.png"))); // NOI18N
        label_iconotecnogas.setPreferredSize(new java.awt.Dimension(270, 134));
        getContentPane().add(label_iconotecnogas, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 80, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel9.setText("Fecha:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 40, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel10.setText("Usuario:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        annu1.setText("....");
        getContentPane().add(annu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 480, 120, -1));

        annu.setText("....");
        getContentPane().add(annu, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 253, 150, 20));

        useProductos.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        useProductos.setText("....");
        getContentPane().add(useProductos, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 60, -1));

        fechaActual.setText("....");
        getContentPane().add(fechaActual, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 60, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/fondo5.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 860, 540));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbestadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbestadoActionPerformed
       // TODO add your handling code here:
    }//GEN-LAST:event_cmbestadoActionPerformed

    private void cmbcategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbcategoriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbcategoriaActionPerformed

    private void tablaproductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaproductosMouseClicked
int row=tablaproductos.getSelectedRow();
txtid.setText(tablaproductos.getValueAt(row, 0).toString());   
txtnombre.setText(tablaproductos.getValueAt(row, 1).toString());
txtprecio.setText(tablaproductos.getValueAt(row, 2).toString());
txtcreacion.setText(tablaproductos.getValueAt(row, 3).toString());
txtactualizacion.setText(tablaproductos.getValueAt(row, 4).toString());
cmbcategoria.setSelectedItem(tablaproductos.getValueAt(row,5).toString());
cmbestado.setSelectedItem(tablaproductos.getValueAt(row,6).toString());
cmbusuario.setSelectedItem(tablaproductos.getValueAt(row,7).toString());
    }//GEN-LAST:event_tablaproductosMouseClicked

    private void btnguardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarActionPerformed
  
        String cap="";
         
        String sql="SELECT * FROM `productorol` WHERE `nombre` = '"+useProductos.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("insertar"); 
            }
            if(cap.equals("Activo"))
            {
             try{
         String sql1="INSERT INTO `productos`(`nombre_producto`,`id_producto`,`precio_producto`,`fecha_creacion`,`fecha_actualizacion`,`id_categoria_productos`,`estado_productos`,`id_usuario`) VALUES (?,NULL,?,SYSDATE(),SYSDATE(),?,?,?)"; 
         PreparedStatement ps=cn.prepareCall(sql1);
         
           if(txtnombre.getText().isEmpty()){
            validacion1.setVisible(true);
            leyenda1.setText("No puede estar vacio !!");
        }else{
            validacion1.setVisible(false);
            leyenda1.setText("...");
       ps.setString(1,txtnombre.getText());
         } 
        
        
         ps.setString(2,txtprecio.getText());

         ps.setString(3,cmbcategoria.getSelectedItem().toString());
         ps.setString(4,cmbestado.getSelectedItem().toString());
         ps.setString(5,cmbusuario.getSelectedItem().toString()); 
           
         
         
         int n=ps.executeUpdate();
         if(n>0)
             JOptionPane.showMessageDialog(null, "datos guardados");
          Limpiar(); 
          m("");
         
         
        }catch(Exception e){
            if (txtnombre.getText().isEmpty() ||txtprecio.getText().isEmpty() || cmbcategoria.getSelectedItem() == cmbcategoria.getItemAt(0)
                    ||cmbestado.getSelectedItem() == cmbestado.getItemAt(0)||cmbusuario.getSelectedItem() == cmbusuario.getItemAt(0)) {
              JOptionPane.showMessageDialog(rootPane, "No puede se permiten campos vacios!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
    
            }else{
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista el producto que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
  
            }
        }
       
            
            
        
        Llenar();
      
       
         if(txtprecio.getText().isEmpty()){
            validacion2.setVisible(true);
            leyenda2.setText("Error: Campo vacio");
        }else{
             validacion2.setVisible(false);
             leyenda2.setText("...");
        }
            }
            else{
            btnguardar.setEnabled(true);
            annu.setText("No tienes permiso");
            logger.info("El usuario "+useProductos.getText()+" agrego usuario. ");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.fatal("Error: "+ex);
            
        }  
        
        
    

      
        
    }//GEN-LAST:event_btnguardarActionPerformed

    private void btnatrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnatrasActionPerformed
       
       panelcentral ingresar = new panelcentral();
       ingresar.setVisible(true);   
       panelcentral.User.setText(useProductos.getText());
       this.dispose();
                            bo(useProductos.getText());
                     bo2(useProductos.getText());
                     bo3(useProductos.getText());
                     bo4(useProductos.getText());
                     bo5(useProductos.getText());
                     bo6(useProductos.getText());
                     bo7(useProductos.getText());
                     bo8(useProductos.getText());

    }//GEN-LAST:event_btnatrasActionPerformed

    private void btnmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmodificarActionPerformed

        String cap="";
         
        String sql="SELECT * FROM `productorol` WHERE `nombre` = '"+useProductos.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("modificar"); 
            }
            if(cap.equals("Activo"))
            {
             try{
        String sql1="UPDATE `productos` SET `nombre_producto`=?,`precio_producto`=?,`fecha_actualizacion`=SYSDATE(),`id_categoria_productos`=?,"
                + "`estado_productos`=?,`id_usuario`=? WHERE `id_producto`=?" ;
        int fila=tablaproductos.getSelectedRow();
        String dao=(String)tablaproductos.getValueAt(fila,0);
         PreparedStatement ps=cn.prepareStatement(sql1);
         
         ps.setString(1,txtnombre.getText());
         ps.setString(2,txtprecio.getText());
         
         ps.setString(3,cmbcategoria.getSelectedItem().toString());
         ps.setString(4,cmbestado.getSelectedItem().toString());
         ps.setString(5,cmbusuario.getSelectedItem().toString());
         
         ps.setString(6,dao);
         int n=ps.executeUpdate();
         if(n>0){
            
             Llenar();
             m("");
          JOptionPane.showMessageDialog(null,"datos modificados");
           Limpiar(); 
      }
         
    }catch(Exception e){
        if (txtnombre.getText().isEmpty() ||txtprecio.getText().isEmpty() || cmbcategoria.getSelectedItem() == cmbcategoria.getItemAt(0)
                    ||cmbestado.getSelectedItem() == cmbestado.getItemAt(0)||cmbusuario.getSelectedItem() == cmbusuario.getItemAt(0)) {
              JOptionPane.showMessageDialog(rootPane, "No puede se permiten campos vacios!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
    
            }else{
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista el producto que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
  
            }
    }
            }
            else{
            btnguardar.setEnabled(true);
            annu1.setText("No tienes permiso");
            logger.info("El usuario "+useProductos.getText()+" agrego usuario. ");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.fatal("Error: "+ex);
            
        }  

        
        
    }//GEN-LAST:event_btnmodificarActionPerformed

    private void btnnuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnuevoActionPerformed
         Limpiar();  
    }//GEN-LAST:event_btnnuevoActionPerformed

    private void txtprecioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtprecioKeyTyped
        char validar=evt.getKeyChar();
        if(Character.isLetter(validar)){
            getToolkit().beep();
            evt.consume();
            leyenda2.setText("Solo Numeros");
        }   
        
    if(!Character.isDigit(evt.getKeyChar())&& evt.getKeyChar()!='.' ){
            evt.consume();
  }        if(evt.getKeyChar()=='.'&&txtprecio.getText().contains(".")){
          evt.consume();
 }
    }//GEN-LAST:event_txtprecioKeyTyped

    private void txtbuscarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtbuscarKeyPressed
    
    
    
    }//GEN-LAST:event_txtbuscarKeyPressed

    private void txtbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbuscarActionPerformed
        // TODO add your handling code here:
        m(txtbuscar.getText());
    }//GEN-LAST:event_txtbuscarActionPerformed

    private void txtbuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtbuscarKeyReleased
        // TODO add your handling code here:
        m(txtbuscar.getText());
    }//GEN-LAST:event_txtbuscarKeyReleased

    private void txtnombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtnombreKeyTyped
        char validar=evt.getKeyChar();
        if(Character.isDigit(validar)){
            getToolkit().beep();
            evt.consume();
            leyenda1.setText("Solo Letras");
        }
        if (evt.getKeyChar()== 32) {
            evt.consume();
        }

        if(evt.getKeyChar()>=33 && evt.getKeyChar()<=64
            || evt.getKeyChar()>=91 && evt.getKeyChar()<=96
            || evt.getKeyChar()>=123 && evt.getKeyChar()<=208
            || evt.getKeyChar()>=210 && evt.getKeyChar()<=240
            || evt.getKeyChar()>=242 && evt.getKeyChar()<=255){
            evt.consume();
            leyenda1.setText("solo letras");
        }

        String nuestrotexto=txtnombre.getText();
        if (nuestrotexto.length()>0){
            char primeraletra=nuestrotexto.charAt(0);
            nuestrotexto=Character.toUpperCase(primeraletra)+nuestrotexto.substring(1,nuestrotexto.length());
            txtnombre.setText(nuestrotexto);
        }
    }//GEN-LAST:event_txtnombreKeyTyped

    private void txtnombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnombreActionPerformed

    private void txtprecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtprecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtprecioActionPerformed

    private void cmbusuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbusuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbusuarioActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Productos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Productos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Productos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Productos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Productos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel annu;
    private javax.swing.JLabel annu1;
    private javax.swing.JButton btnatras;
    private javax.swing.JButton btnguardar;
    private javax.swing.JButton btnmodificar;
    private javax.swing.JButton btnnuevo;
    private javax.swing.JComboBox<String> cmbcategoria;
    private javax.swing.JComboBox<String> cmbestado;
    private javax.swing.JComboBox<String> cmbusuario;
    private javax.swing.JLabel fechaActual;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_iconotecnogas;
    private javax.swing.JLabel leyenda1;
    private javax.swing.JLabel leyenda2;
    private javax.swing.JTable tablaproductos;
    private javax.swing.JLabel txtactualizacion;
    private javax.swing.JTextField txtbuscar;
    private javax.swing.JLabel txtcreacion;
    private javax.swing.JLabel txtid;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtprecio;
    public static javax.swing.JLabel useProductos;
    private javax.swing.JLabel validacion1;
    private javax.swing.JLabel validacion2;
    // End of variables declaration//GEN-END:variables
}
