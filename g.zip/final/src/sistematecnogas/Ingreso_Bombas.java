/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistematecnogas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import servicios.conexion;
import static sistematecnogas.Categoria.useCategoria;
import static sistematecnogas.Control_Combustible_Diario.logger;


/**
 *
 * @author Wilfredo Serrano
 */
public class Ingreso_Bombas extends javax.swing.JFrame {
final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(Ingreso_Bombas.class);
    conexion cc = new conexion();
    Connection cn = conexion.conexion();
    Statement sent;

    public static String fecha() {
        Date fecha = new Date();
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/YYYY");
        return formatoFecha.format(fecha);
    }
    public void limpiar(){
        txtIDbomba.setText("");
        txtNumBomba.setText("");
        txtBuscar.setText("");
        comboEstado.setSelectedIndex(0);
    }
    void cargar(String valor){
    /*String mostrar="SELECT * FROM `categoria` WHERE '%"+valor+"%'";*/
    String mostrar="SELECT `id_bombas`, `num_bomba`, `fecha_creacion_bomba`, `fecha_actualizacion_bomba`, `estado` FROM `bombas` WHERE `id_bombas` LIKE '%"+valor+"%'";
    String []titulos={"Id de categoria","Numero de categoria","Fecha de creacion","Fecha actualizacion","Estado"};
    String []Registros=new String[5];
    DefaultTableModel model = new DefaultTableModel(null,titulos);
  
        try {
              Statement st = cn.createStatement();
              java.sql.ResultSet rs = st.executeQuery(mostrar);
              while(rs.next())
              {
                  Registros[0]= rs.getString("id_bombas");
                  Registros[1]= rs.getString("num_bomba");
                  Registros[2]= rs.getString("fecha_creacion_bomba");
                  Registros[3]= rs.getString("fecha_actualizacion_bomba");
                  Registros[4]= rs.getString("estado");
               
                           
                  model.addRow(Registros);
              }
              tblBombas.setModel(model);
        } catch (java.sql.SQLException ex) {
            Logger.getLogger(Categoria.class.getName()).log(Level.SEVERE, null, ex);
        }
    
  }
    void cargar1(){
    String mostrar = "SELECT `id_bombas`, `num_bomba`, `fecha_creacion_bomba`, `fecha_actualizacion_bomba`, `estado_bomba` FROM `bombas` WHERE 1";
        String[] titulos = {"ID bomba", "Numero de bomba", "Fecha de creacion de la bomba", "Fecha de actualizacion de la bomba", "Estado de la bomba"};
        String[] Registros = new String[5];
        DefaultTableModel model = new DefaultTableModel(null, titulos);

        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(mostrar);
            while (rs.next()) {
                Registros[0] = rs.getString("id_bombas");
                Registros[1] = rs.getString("num_bomba");
                Registros[2] = rs.getString("fecha_creacion_bomba");
                Registros[3] = rs.getString("fecha_actualizacion_bomba");
                Registros[4] = rs.getString("estado_bomba");
                model.addRow(Registros);
            }
            tblBombas.setModel(model);
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista esa bomba que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Creates new form Ingreso_Bombas
     */
    
    public Ingreso_Bombas() {
        initComponents();
        cargar("");
        asterisco();
        setLocationRelativeTo(null);
        lblFecha.setText(fecha());
        setTitle("Bombas");
        estadoM();
        //setIconImage(new ImageIcon(getClass().getResource("/Imagen/logo_tecnogas_transp.png")).getImage());
        
    }
    public void estadoM(){
        try {
            sent = cn.createStatement();
            String sql = "SELECT * FROM `estado`";
            java.sql.Statement st = cn.createStatement();
            java.sql.ResultSet rs = sent.executeQuery(sql);
            comboEstado.addItem("seleccione estado");
            while (rs.next()) {

                this.comboEstado.addItem(rs.getString("estado"));
            }
        } catch (Exception e) {

        }
    }

    public void asterisco() {
        if (txtNumBomba.getText().isEmpty()) {
            asteriscoNumero.setText("*");
        } else {
            asteriscoNumero.setText(" ");
        }
        if (comboEstado.getSelectedItem() == comboEstado.getItemAt(0)) {
            asteriscoEstado.setText("*");
        } else {
            asteriscoEstado.setText(" ");
        }
    }
     void bo(String dato){
   String cap1="";
        String sql="SELECT * FROM `usuariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo2(String dato){
   String cap1="";
        String sql="SELECT * FROM `proveedorrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.proveedores.setVisible(true);
            
            }
            else{
                panelcentral.proveedores.setVisible(false);
                panelcentral.jLabel2.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo3(String dato){
   String cap1="";
        String sql="SELECT * FROM `categoriarol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.categorias.setVisible(true);
            
            }
            else{
                panelcentral.categorias.setVisible(false);
                panelcentral.jLabel6.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo4(String dato){
   String cap1="";
        String sql="SELECT * FROM `bombasrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.bombas.setVisible(true);
            
            }
            else{
                panelcentral.jLabel5.setVisible(false);
                panelcentral.bombas.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo5(String dato){
   String cap1="";
        String sql="SELECT * FROM `productorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.productos.setVisible(true);
            
            }
            else{
                panelcentral.productos.setVisible(false);
                panelcentral.jLabel9.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo6(String dato){
   String cap1="";
        String sql="SELECT * FROM `seriedigitalrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario6.setVisible(true);
            
            }
            else{
                panelcentral.jLabel8.setVisible(false);
                panelcentral.usuario6.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo7(String dato){
   String cap1="";
        String sql="SELECT * FROM `inventariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario4.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo8(String dato){
   String cap1="";
        String sql="SELECT * FROM `preciorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.control.setVisible(true);
            
            }
            else{
                panelcentral.usuario4.setVisible(false);
                panelcentral.jLabel10.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        textfield_id_bomba3 = new java.awt.TextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnAtras = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnIngresar = new javax.swing.JButton();
        annu = new javax.swing.JLabel();
        annu1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBombas = new javax.swing.JTable();
        txtIDbomba = new javax.swing.JTextField();
        txtNumBomba = new javax.swing.JTextField();
        comboEstado = new javax.swing.JComboBox<>();
        btnLimpiar = new javax.swing.JButton();
        lblFecha = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        asteriscoNumero = new javax.swing.JLabel();
        asteriscoEstado = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        label_iconotecnogas = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        useBomba = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        textfield_id_bomba3.setText("textField2");

        jLabel12.setText("jLabel12");

        jLabel18.setText("Fecha actual:");

        jLabel19.setText("Ingresar en estado:");

        jLabel20.setText("ID_Bomba:");

        jLabel21.setText("Numero de bomba:");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setText("ID Bomba:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, -1));

        jLabel3.setText("Numero de bomba:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 104, -1, -1));

        jLabel9.setText("Ingresar en estado:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 145, -1, -1));

        btnAtras.setText("Atrás");
        btnAtras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        btnAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasActionPerformed(evt);
            }
        });
        getContentPane().add(btnAtras, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 388, 130, -1));

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        getContentPane().add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(408, 388, 130, -1));

        btnIngresar.setText("Ingresar nueva bomba");
        btnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarActionPerformed(evt);
            }
        });
        getContentPane().add(btnIngresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 182, 168, 23));

        annu.setText("....");
        getContentPane().add(annu, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 220, 170, -1));

        annu1.setText("....");
        getContentPane().add(annu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 410, 130, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 216, 528, -1));

        tblBombas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tblBombas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBombasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblBombas);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 254, 522, 119));
        getContentPane().add(txtIDbomba, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, 109, -1));

        txtNumBomba.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNumBombaKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNumBombaKeyTyped(evt);
            }
        });
        getContentPane().add(txtNumBomba, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 101, 109, -1));

        comboEstado.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                comboEstadoKeyReleased(evt);
            }
        });
        getContentPane().add(comboEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 141, 109, -1));

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 390, 130, -1));

        lblFecha.setText("dd/MM/YYYY");
        getContentPane().add(lblFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel7.setText("Usuario:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setText("Fecha:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 40, -1));

        txtBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarActionPerformed(evt);
            }
        });
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBuscarKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 228, 109, -1));

        asteriscoNumero.setBackground(new java.awt.Color(255, 0, 0));
        asteriscoNumero.setForeground(new java.awt.Color(255, 0, 0));
        asteriscoNumero.setText("jLabel4");
        getContentPane().add(asteriscoNumero, new org.netbeans.lib.awtextra.AbsoluteConstraints(257, 104, -1, -1));

        asteriscoEstado.setBackground(new java.awt.Color(255, 0, 0));
        asteriscoEstado.setForeground(new java.awt.Color(255, 0, 0));
        asteriscoEstado.setText("jLabel5");
        getContentPane().add(asteriscoEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(257, 145, -1, -1));

        jLabel4.setText("Buscar:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 231, -1, -1));

        label_iconotecnogas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/logo_tecnogas_transp.png"))); // NOI18N
        label_iconotecnogas.setText("jLabel4");
        label_iconotecnogas.setPreferredSize(new java.awt.Dimension(270, 134));
        getContentPane().add(label_iconotecnogas, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 60, 230, 125));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 153, 255));
        jLabel13.setText("Bombas");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, 110, -1));

        useBomba.setFont(new java.awt.Font("Tahoma", 0, 11)); // NOI18N
        useBomba.setText("....");
        getContentPane().add(useBomba, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 60, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/fondo5.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 440));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarActionPerformed
       String cap="";
         
        String sql="SELECT * FROM `bombasrol` WHERE `nombre` = '"+useBomba.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("insertar"); 
            }
            if(cap.equals("Activo"))
            {
              try {
            
            String sql1="INSERT INTO `bombas` (`id_bombas`, `num_bomba`, `fecha_creacion_bomba`, `fecha_actualizacion_bomba`, `estado`) VALUES (NULL, ?, SYSDATE(), SYSDATE(), ?)";
            PreparedStatement pst  = cn.prepareStatement(sql1);
           
                
                pst.setString(1, txtNumBomba.getText());
                pst.setString(2, comboEstado.getSelectedItem().toString());
                if (txtNumBomba.getText().length() > 2) {
                        JOptionPane.showMessageDialog(null, "Los campos no pueden tener mas de 2 caracteres","Error",JOptionPane.ERROR_MESSAGE);
                }else{
                
                pst.executeUpdate();
                JOptionPane.showMessageDialog(null, "Registro Guardado con Exito");
                cargar("");
                limpiar();
                }
   
        
        } catch (java.sql.SQLException ex) {
            
            if (txtNumBomba.getText().isEmpty() || comboEstado.getSelectedItem() == comboEstado.getItemAt(0)) {
              JOptionPane.showMessageDialog(rootPane, "No puede se permiten campos vacios!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
    
            }else{
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista esa bomba que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
  
            }
            
        }
            }
            else{
            btnIngresar.setEnabled(true);
            annu.setText("No tienes permiso");
            logger.info("El usuario "+useBomba.getText()+" inserto categoria. ");
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.fatal("Error: "+ex);
            
        }  
        
       
    }//GEN-LAST:event_btnIngresarActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        panelcentral botonatras = new panelcentral();
        botonatras.setVisible(true);
        this.dispose();// TODO add your handling code here:
    }//GEN-LAST:event_jButton2MouseClicked

    private void btnAtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtrasActionPerformed
        // TODO add your handling code here:
        panelcentral ingresar = new panelcentral();
        ingresar.setVisible(true);   
        panelcentral.User.setText(useBomba.getText());
        this.dispose();
        bo(useBomba.getText());
                     bo2(useBomba.getText());
                     bo3(useBomba.getText());
                     bo4(useBomba.getText());
                     bo5(useBomba.getText());
                     bo6(useBomba.getText());
                     bo7(useBomba.getText());
                     bo8(useBomba.getText());
    }//GEN-LAST:event_btnAtrasActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        // TODO add your handling code here:
        
        String cap="";
         
        String sql="SELECT * FROM `bombasrol` WHERE `nombre` = '"+useBomba.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("modificar"); 
            }
            if(cap.equals("Activo"))
            {
              try {
       //String sql = "UPDATE `bombas` SET `num_bomba` = '" + txtNumBomba.getText() + "',`fecha_actualizacion_bomba` = SYSDATE(),`estado_bomba` = '" + comboEstado.getSelectedItem() + "' WHERE `bombas`.`id_bombas` = '" + txtIDbomba.getText() + "'";
       String sql1= "UPDATE `bombas` SET `num_bomba` = '"+txtNumBomba.getText()+"', `fecha_actualizacion_bomba` = SYSDATE(), `estado` = '"+comboEstado.getSelectedItem()+"' WHERE `bombas`.`id_bombas` = '"+txtIDbomba.getText()+"';";
            PreparedStatement pst = cn.prepareStatement(sql1);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "LOS DATOS HAN SIDO MODIFICADOS");
            cargar("");
            limpiar();
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Error introduzca bien los datos");

        }
            }
            else{
            btnModificar.setEnabled(true);
            annu1.setText("No tienes permiso");
            logger.info("El usuario "+useBomba.getText()+" inserto categoria. ");
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.fatal("Error: "+ex);
            
        }  
        
       
        
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        // TODO add your handling code here:
        limpiar();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void tblBombasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBombasMouseClicked
        // TODO add your handling code here:
        int seleccionar = tblBombas.rowAtPoint(evt.getPoint());
        txtIDbomba.setText(String.valueOf(tblBombas.getValueAt(seleccionar, 0)));
        txtNumBomba.setText(String.valueOf(tblBombas.getValueAt(seleccionar, 1)));
        comboEstado.setSelectedItem(String.valueOf(tblBombas.getValueAt(seleccionar, 4)));
    }//GEN-LAST:event_tblBombasMouseClicked

    private void cargar() {
        String mostrar = "SELECT `id_bombas`, `num_bomba`, `fecha_creacion_bomba`, `fecha_actualizacion_bomba`, `estado` FROM `bombas` WHERE `num_bomba` = '" + txtBuscar.getText() + "'" + "OR `id_bombas` LIKE '%" + txtBuscar.getText() + "%'";
        String[] titulos = {"ID bomba", "Numero de bomba", "Fecha de creacion de la bomba", "Fecha de actualizacion de la bomba", "Estado de la bomba"};
        String[] Registros = new String[5];
        DefaultTableModel model = new DefaultTableModel(null, titulos);

        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(mostrar);
            while (rs.next()) {
                Registros[0] = rs.getString("id_bombas");
                Registros[1] = rs.getString("num_bomba");
                Registros[2] = rs.getString("fecha_creacion_bomba");
                Registros[3] = rs.getString("fecha_actualizacion_bomba");
                Registros[4] = rs.getString("estado");
                model.addRow(Registros);
            }
            tblBombas.setModel(model);
        } catch (java.sql.SQLException ex) {
            Logger.getLogger(Categoria.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed
        // TODO add your handling code here:
        cargar(txtBuscar.getText());
    }//GEN-LAST:event_txtBuscarActionPerformed

    private void txtBuscarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyPressed
        // TODO add your handling code here:
        //cargar();
    }//GEN-LAST:event_txtBuscarKeyPressed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        // TODO add your handling code here:
        cargar(txtBuscar.getText());
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void txtNumBombaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumBombaKeyTyped
        // TODO add your handling code here:
        char validar =evt.getKeyChar();
        
        if(evt.getKeyChar()>=33 && evt.getKeyChar()<=47 || evt.getKeyChar()>=58 && evt.getKeyChar()<=255){
            evt.consume();
            JOptionPane.showMessageDialog(rootPane, "Solo se permiten numeros","Error",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_txtNumBombaKeyTyped

    private void txtNumBombaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumBombaKeyReleased
        // TODO add your handling code here:
        asterisco();
    }//GEN-LAST:event_txtNumBombaKeyReleased

    private void comboEstadoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_comboEstadoKeyReleased
        // TODO add your handling code here:
        asterisco();
    }//GEN-LAST:event_comboEstadoKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ingreso_Bombas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ingreso_Bombas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ingreso_Bombas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ingreso_Bombas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ingreso_Bombas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel annu;
    private javax.swing.JLabel annu1;
    private javax.swing.JLabel asteriscoEstado;
    private javax.swing.JLabel asteriscoNumero;
    private javax.swing.JButton btnAtras;
    private javax.swing.JButton btnIngresar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> comboEstado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel label_iconotecnogas;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JTable tblBombas;
    private java.awt.TextField textfield_id_bomba3;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtIDbomba;
    private javax.swing.JTextField txtNumBomba;
    public static javax.swing.JLabel useBomba;
    // End of variables declaration//GEN-END:variables
}
