/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistematecnogas;

import Atxy2k.CustomTextField.RestrictedTextField;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import servicios.conexion;
import static sistematecnogas.Categoria.fecha;
import static sistematecnogas.Control_Combustible_Diario.logger;
import static sistematecnogas.ingresarUsuario.use;

/**
 *
 * @author radioshack
 */
public final class Proveedores extends javax.swing.JFrame {

    conexion cc = new conexion();
    Connection cn = conexion.conexion();
    
    final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(Proveedores.class);
    public Proveedores() {
        initComponents();
        setLocationRelativeTo(null);
        cargar1("");
        fechaActual.setText(fecha());
        setTitle("Ingreso al sistema");
        setIconImage(new ImageIcon(getClass().getResource("/Imagen/image.png")).getImage());
        limitar();
        mostrartipoproducto();
    }
    
    
    
  public void limitar(){
  RestrictedTextField limitarr =new RestrictedTextField(descripcion);
  limitarr.setLimit(20);
  
  RestrictedTextField limitar1 =new RestrictedTextField(correo);
  limitar1.setLimit(20);
  RestrictedTextField limitar2 =new RestrictedTextField(telefono);
  limitar2.setLimit(8);
  RestrictedTextField limitar3 =new RestrictedTextField(direccion);
  limitar3.setLimit(45);
  
    
    }
    void cargar1(String valor){
    String consulta="SELECT `id_proveedores`, `nombre`, `telefono`, `direccion_correo`, `direccion`, `id_categoria_productos` FROM `proveedores` WHERE `id_proveedores` LIKE '%"+valor+"%' OR `nombre` LIKE '%"+valor+"%'";
    String []titulos={"ID proveedor","Nombre","Telefono","Correo","Direccion","ID productos"};
    String []Registros=new String[7];
    DefaultTableModel model = new DefaultTableModel(null,titulos);
  
        try {
              Statement st = cn.createStatement();
              ResultSet rs = st.executeQuery(consulta);
              
              while(rs.next())
              {
                  Registros[0]= rs.getString("id_proveedores");
                  Registros[1]= rs.getString("nombre");
                  Registros[2]= rs.getString("telefono");
                  Registros[3]= rs.getString("direccion_correo");
                  Registros[4]= rs.getString("direccion");
                  Registros[5]= rs.getString("id_categoria_productos");
           
                  model.addRow(Registros);
              }
              tbclientes.setModel(model);
        } catch (java.sql.SQLException ex) {
            Logger.getLogger(SerieMecanicas.class.getName()).log(Level.SEVERE, null, ex);
           
        }
    }
    public void Valida(){
        if (idproveedor.getText().isEmpty()) {
            error1.setText("*");
        } else {
            error1.setText(" ");
        }
        if (descripcion.getText().isEmpty()) {
            anudescri.setText("*");
        } else {
            anudescri.setText(" ");
        }
        
        if (telefono.getText().isEmpty()) {
            anutelefono1.setText("*");
        } else {
            anutelefono1.setText("");
        }
        if (direccion.getText().isEmpty()) {
            anudireccion.setText("*");
        } else {
            anudireccion.setText("");
        }
        
     
    }
  
     void bloquear(){
    idproveedor.setEnabled(false);
    descripcion.setEnabled(false);
 
    }
    void limpiar(){
    idproveedor.setText("");
    descripcion.setText("");
    correo.setText("");
    telefono.setText("");
    direccion.setText("");
    idcategoria.setSelectedIndex(0);
   
    }
    void mostrartipoproducto(){
       String sql="SELECT * FROM `categoria_productos` WHERE `estado` = 'activo'";
        
    try {
       
   //Establecemos conexión con la BD 
  Statement st = cn.createStatement();
  ResultSet rs = st.executeQuery(sql);
   
   
   while(rs.next()){
   
       idcategoria.addItem(rs.getString("categoria"));
   
   }
   
    
} catch (SQLException e) {

    JOptionPane.showMessageDialog(null, e);
    
}
       
}
    
     void bo(String dato){
   String cap1="";
        String sql="SELECT * FROM `usuariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo2(String dato){
   String cap1="";
        String sql="SELECT * FROM `proveedorrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.proveedores.setVisible(true);
            
            }
            else{
                panelcentral.proveedores.setVisible(false);
                panelcentral.jLabel2.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo3(String dato){
   String cap1="";
        String sql="SELECT * FROM `categoriarol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.categorias.setVisible(true);
            
            }
            else{
                panelcentral.categorias.setVisible(false);
                panelcentral.jLabel6.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo4(String dato){
   String cap1="";
        String sql="SELECT * FROM `bombasrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.bombas.setVisible(true);
            
            }
            else{
                panelcentral.jLabel5.setVisible(false);
                panelcentral.bombas.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo5(String dato){
   String cap1="";
        String sql="SELECT * FROM `productorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.productos.setVisible(true);
            
            }
            else{
                panelcentral.productos.setVisible(false);
                panelcentral.jLabel9.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo6(String dato){
   String cap1="";
        String sql="SELECT * FROM `seriedigitalrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario6.setVisible(true);
            
            }
            else{
                panelcentral.jLabel8.setVisible(false);
                panelcentral.usuario6.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo7(String dato){
   String cap1="";
        String sql="SELECT * FROM `inventariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario4.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo8(String dato){
   String cap1="";
        String sql="SELECT * FROM `preciorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.control.setVisible(true);
            
            }
            else{
                panelcentral.usuario4.setVisible(false);
                panelcentral.jLabel10.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
    
   
    

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        limpiar = new javax.swing.JButton();
        modificar = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbclientes = new javax.swing.JTable();
        txtbuscar = new javax.swing.JTextField();
        descripcion = new javax.swing.JTextField();
        correo = new javax.swing.JTextField();
        telefono = new javax.swing.JTextField();
        direccion = new javax.swing.JTextField();
        anuproveedor = new javax.swing.JLabel();
        anudireccion = new javax.swing.JLabel();
        anutelefono1 = new javax.swing.JLabel();
        anucategoria = new javax.swing.JLabel();
        anudescri = new javax.swing.JLabel();
        idcategoria = new javax.swing.JComboBox();
        idproveedor = new javax.swing.JLabel();
        error1 = new javax.swing.JLabel();
        error2 = new javax.swing.JLabel();
        error3 = new javax.swing.JLabel();
        error4 = new javax.swing.JLabel();
        error5 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        label_iconotecnogas = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        prove = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        fechaActual = new javax.swing.JLabel();
        annu = new javax.swing.JLabel();
        annu1 = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        jLabel4.setText("ID Proveedor");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 74, 109, 23));

        jLabel6.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        jLabel6.setText("Correo");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(548, 66, 141, 21));

        jLabel5.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        jLabel5.setText("Telefono");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(97, 154, 141, 21));

        jButton2.setText("Ingresar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(548, 196, 141, -1));

        jLabel1.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        jLabel1.setText("Dirección");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 246, 141, 21));

        jLabel2.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        jLabel2.setText("Descripción de proveedor");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 66, 156, 21));

        jLabel7.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        jLabel7.setText("Categoría de producto");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 154, 141, 21));

        jButton3.setText("Atrás");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(97, 562, 130, -1));

        limpiar.setText("Limpiar");
        limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limpiarActionPerformed(evt);
            }
        });
        getContentPane().add(limpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(406, 562, 130, -1));

        modificar.setText("Modificar");
        modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarActionPerformed(evt);
            }
        });
        getContentPane().add(modificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(711, 562, 130, -1));

        jLabel13.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        jLabel13.setText("Buscar:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 401, -1, 21));

        tbclientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tbclientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbclientesMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbclientes);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 440, 909, 112));

        txtbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbuscarActionPerformed(evt);
            }
        });
        txtbuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtbuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(64, 402, 109, -1));

        descripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                descripcionActionPerformed(evt);
            }
        });
        descripcion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                descripcionKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                descripcionKeyTyped(evt);
            }
        });
        getContentPane().add(descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 109, 141, -1));

        correo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                correoActionPerformed(evt);
            }
        });
        correo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                correoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                correoKeyTyped(evt);
            }
        });
        getContentPane().add(correo, new org.netbeans.lib.awtextra.AbsoluteConstraints(548, 109, 141, -1));

        telefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                telefonoActionPerformed(evt);
            }
        });
        telefono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                telefonoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                telefonoKeyTyped(evt);
            }
        });
        getContentPane().add(telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 197, 109, -1));

        direccion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                direccionKeyReleased(evt);
            }
        });
        getContentPane().add(direccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 277, 547, -1));
        getContentPane().add(anuproveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(244, 154, 109, -1));

        anudireccion.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        anudireccion.setForeground(new java.awt.Color(254, 0, 51));
        anudireccion.setText("...");
        getContentPane().add(anudireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(653, 273, 19, 21));

        anutelefono1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        anutelefono1.setForeground(new java.awt.Color(254, 0, 51));
        anutelefono1.setText("jLabel3");
        getContentPane().add(anutelefono1, new org.netbeans.lib.awtextra.AbsoluteConstraints(215, 193, 19, 21));

        anucategoria.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        anucategoria.setForeground(new java.awt.Color(254, 0, 51));
        anucategoria.setText("jLabel3");
        getContentPane().add(anucategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(731, 107, 19, 21));

        anudescri.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        anudescri.setForeground(new java.awt.Color(254, 0, 51));
        anudescri.setText("jLabel3");
        getContentPane().add(anudescri, new org.netbeans.lib.awtextra.AbsoluteConstraints(472, 105, 19, 21));

        idcategoria.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Seleccione.." }));
        idcategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idcategoriaActionPerformed(evt);
            }
        });
        idcategoria.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                idcategoriaKeyPressed(evt);
            }
        });
        getContentPane().add(idcategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 193, 141, -1));

        idproveedor.setText("...");
        getContentPane().add(idproveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 107, 69, 21));

        error1.setForeground(new java.awt.Color(255, 0, 51));
        error1.setText("...");
        getContentPane().add(error1, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 134, 141, -1));

        error2.setForeground(new java.awt.Color(255, 0, 51));
        error2.setText("...");
        getContentPane().add(error2, new org.netbeans.lib.awtextra.AbsoluteConstraints(548, 134, 320, -1));

        error3.setForeground(new java.awt.Color(255, 0, 51));
        error3.setText("...");
        getContentPane().add(error3, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 223, 175, -1));

        error4.setForeground(new java.awt.Color(255, 0, 51));
        error4.setText("...");
        getContentPane().add(error4, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 302, 547, -1));

        error5.setForeground(new java.awt.Color(255, 0, 51));
        error5.setText("...");
        getContentPane().add(error5, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 223, 141, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(51, 153, 255));
        jLabel17.setText("Proveedores");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(329, 19, 171, -1));

        label_iconotecnogas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/logo_tecnogas_transp.png"))); // NOI18N
        label_iconotecnogas.setPreferredSize(new java.awt.Dimension(270, 134));
        getContentPane().add(label_iconotecnogas, new org.netbeans.lib.awtextra.AbsoluteConstraints(649, 302, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel8.setText("Fecha:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 40, -1));

        prove.setText("...");
        getContentPane().add(prove, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 50, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel9.setText("Usuario:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        fechaActual.setText("...");
        getContentPane().add(fechaActual, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, 80, -1));

        annu.setText("....");
        getContentPane().add(annu, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 220, 140, -1));

        annu1.setText("....");
        getContentPane().add(annu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 590, 140, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/fondo5.jpg"))); // NOI18N
        fondo.setText("jLabel4");
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 610));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limpiarActionPerformed
        // TODO add your handling code here:

        limpiar();
         JOptionPane.showMessageDialog(rootPane, "LOS DATOS FUERON BORRADOS");

    }//GEN-LAST:event_limpiarActionPerformed

    private void modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarActionPerformed
        
        String cap="";
         
        String sql="SELECT * FROM `proveedorrol` WHERE `nombre` = '"+prove.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("modificar"); 
            }
            if(cap.equals("Activo"))
            {
              try {
            
            String sql1="UPDATE `proveedores` SET `nombre` = ?, `telefono` = ?, `direccion_correo` = ?, `direccion` = ?, `id_categoria_productos` = ? WHERE `proveedores`.`id_proveedores` = '"+idproveedor.getText()+"'";
            PreparedStatement pst  = cn.prepareStatement(sql1);
           Valida();
            
            
               
            if (20>descripcion.getText().length() && descripcion.getText().length()>3) {
                 pst.setString(1, descripcion.getText());
                error1.setText("...");
                    
            }else{
                error1.setText("Minimo 3 y maximo 20 caracteres!!");
            }
                  
           
            if (8>telefono.getText().length() && telefono.getText().length()>7) {
                error3.setText("No puede ser menor a 8 numeros");         
            }else if(telefono.getText().startsWith("2")||
                        telefono.getText().startsWith("3")||
                        telefono.getText().startsWith("8")||
                        telefono.getText().startsWith("9")){
                 pst.setString(2, telefono.getText());       
                 error3.setText("...");
                
            }
            else {
                 error3.setText("Numero no valido");
                
                
               
            }
         
    
            if (correo.getText().isEmpty()) {
            anucategoria.setText("*");
            error2.setText("correo vacio!");}
            else if(!correo.getText().contains("@")||!correo.getText().contains(".")) {
            error2.setText("correo invalido");
            }else{
            pst.setString(3, correo.getText());
            error2.setText("...");}
            
            
            if (45>direccion.getText().length() && direccion.getText().length()>8) {
            pst.setString(4, direccion.getText());
            error4.setText("...");   
            }else{  
               error4.setText("Minimo 8 y maximo 45 caracteres!!");
            }
           
            
            if (idcategoria.getSelectedItem().equals(0)){
                error5.setText("Seleccione uno !!");
            }else{
                pst.setString(5, idcategoria.getSelectedItem().toString());
                
            }
            
            
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "LOS DATOS HAN SIDO MODIFICADOS");
            logger.info("El usuario "+prove.getText()+" modifico usuario. ");
            cargar1("");
            limpiar();
                
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Revise que no se dupliquen datos","Error: Ingrese los datos correctamente",JOptionPane.ERROR_MESSAGE);//"INGRESA TODOS LOS VALORES CORRECTAMENTE","Error",JOptionPane.ERROR_MESSAGE);
        
        
        }
            }
            else{
            jButton2.setEnabled(true);
            annu1.setText("No tienes permiso");
            logger.info("El usuario "+prove.getText()+" no modifico usuario. ");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.fatal("Error: "+ex);
            
        }  
        
       
    }//GEN-LAST:event_modificarActionPerformed

    private void txtbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbuscarActionPerformed
        //metodo para buscar en la tabla
        cargar1(txtbuscar.getText());
    }//GEN-LAST:event_txtbuscarActionPerformed

    private void txtbuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtbuscarKeyReleased
        //metodo para buscar en la tabla
        cargar1(txtbuscar.getText());
    }//GEN-LAST:event_txtbuscarKeyReleased

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        //Insertar datos en la tabla
        String cap="";
         
        String sql="SELECT * FROM `proveedorrol` WHERE `nombre` = '"+prove.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("insertar"); 
            }
            if(cap.equals("Activo"))
            {
             
                try {
            //String sql="INSERT INTO `proveedores`(`id_proveedores`,`nombre`, `telefono`, `direccion_correo`, `direccion`, `id_categoria_productos`) VALUES (?,?,?,?,?,?)";
            String slq1="INSERT INTO `proveedores` (`id_proveedores`, `nombre`, `telefono`, `direccion_correo`, `direccion`, `id_categoria_productos`) VALUES (NULL, ?, ?, ?, ?, ?)";
            PreparedStatement pst  = cn.prepareStatement(slq1);
            
            Valida();
            
            
               
                if (20>descripcion.getText().length() && descripcion.getText().length()>3) {
                 pst.setString(1, descripcion.getText());
                error1.setText("...");
                    
                }else{
                error1.setText("Minimo 3 y maximo 20 caracteres!!");
                }
                    
           
            if (8>telefono.getText().length() && telefono.getText().length()>7) {
                error3.setText("No puede ser menor a 8 numeros");         
            }else if(telefono.getText().startsWith("2")||
                        telefono.getText().startsWith("3")||
                        telefono.getText().startsWith("8")||
                        telefono.getText().startsWith("9")){
                 pst.setString(2, telefono.getText());       
                 error3.setText("...");
                
            }
            else {
                 error3.setText("Numero no valido");
                
                
               
            }
         
    
            if (correo.getText().isEmpty()) {
            anucategoria.setText("*");
            error2.setText("correo vacio!");}
            else if(!correo.getText().contains("@")||!correo.getText().contains(".")) {
            error2.setText("correo invalido");
            }else{
            pst.setString(3, correo.getText());
            error2.setText("...");}
            
            
            if (45>direccion.getText().length() && direccion.getText().length()>8) {
            pst.setString(4, direccion.getText());
            error4.setText("...");   
            }else{  
               error4.setText("Minimo 8 y maximo 45 caracteres!!");
            }
           
            
            if (idcategoria.getSelectedItem().equals(0)){
                error5.setText("Seleccione uno !!");
            }else{
                pst.setString(5, idcategoria.getSelectedItem().toString());
                
            }
            
 
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Registro Guardado con Exito");
            cargar1("");
            limpiar();
            
           
        } catch (java.sql.SQLException ex) {

          JOptionPane.showMessageDialog(rootPane, "Revise que no se dupliquen datos","Error: Ingrese los datos correctamente",JOptionPane.ERROR_MESSAGE);//"INGRESA TODOS LOS VALORES CORRECTAMENTE","Error",JOptionPane.ERROR_MESSAGE);
        
        }
                
            }
            else{
            jButton2.setEnabled(true);
            annu.setText("No tienes permiso");
            logger.info("El usuario "+prove.getText()+" agrego proveedor. ");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.fatal("Error: "+ex);
            
        }  
        
        
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void telefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_telefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_telefonoActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        panelcentral ingresar = new panelcentral();
        ingresar.setVisible(true);   
        panelcentral.User.setText(prove.getText());
        this.dispose();
        bo(prove.getText());
                     bo2(prove.getText());
                     bo3(prove.getText());
                     bo4(prove.getText());
                     bo5(prove.getText());
                     bo6(prove.getText());
                     bo7(prove.getText());
                     bo8(prove.getText());
    }//GEN-LAST:event_jButton3ActionPerformed

    private void descripcionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_descripcionKeyTyped
        // TODO add your handling code here:
        char validar =evt.getKeyChar();
        if(Character.isDigit(validar)){
        getToolkit().beep();
        evt.consume();
        JOptionPane.showMessageDialog(rootPane, "INGRESA SOLO LETRAS");
        
        }
    }//GEN-LAST:event_descripcionKeyTyped

    private void telefonoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_telefonoKeyTyped
        // TODO add your handling code here:
        char validar =evt.getKeyChar();
        
        if(Character.isLetter(validar)){
        getToolkit().beep();
        evt.consume();
        JOptionPane.showMessageDialog(rootPane, "INGRESA SOLO NUMEROS");
        }
    }//GEN-LAST:event_telefonoKeyTyped

    private void correoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_correoActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_correoActionPerformed

    private void correoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_correoKeyReleased
        // TODO add your handling code here:
        Valida();
    }//GEN-LAST:event_correoKeyReleased

    private void descripcionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_descripcionKeyReleased
        // TODO add your handling code here:
        Valida();
    }//GEN-LAST:event_descripcionKeyReleased

    private void telefonoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_telefonoKeyReleased
        // TODO add your handling code here:
        Valida();
    }//GEN-LAST:event_telefonoKeyReleased

    private void direccionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_direccionKeyReleased
        // TODO add your handling code here:
        Valida();
    }//GEN-LAST:event_direccionKeyReleased

    private void idcategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idcategoriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idcategoriaActionPerformed

    private void idcategoriaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_idcategoriaKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_idcategoriaKeyPressed

    private void tbclientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbclientesMouseClicked
        int seleccionar = tbclientes.rowAtPoint(evt.getPoint());
        idproveedor.setText(String.valueOf(tbclientes.getValueAt(seleccionar, 0)));
        descripcion.setText(String.valueOf(tbclientes.getValueAt(seleccionar, 1)));
        telefono.setText(String.valueOf(tbclientes.getValueAt(seleccionar, 2)));
        correo.setText(String.valueOf(tbclientes.getValueAt(seleccionar, 3)));
        direccion.setText(String.valueOf(tbclientes.getValueAt(seleccionar, 4)));
        idcategoria.setSelectedItem(String.valueOf(tbclientes.getValueAt(seleccionar, 5))); 
    }//GEN-LAST:event_tbclientesMouseClicked

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
         
    }//GEN-LAST:event_jButton3MouseClicked

    private void descripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_descripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_descripcionActionPerformed

    private void correoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_correoKeyTyped
        // TODO add your handling code here:
         char validar =evt.getKeyChar();
        
        if(evt.getKeyChar()>=32&&evt.getKeyChar()<=45||evt.getKeyChar()>=58&&evt.getKeyChar()<=63||
                evt.getKeyChar()>=91&&evt.getKeyChar()<=96||
                evt.getKeyChar()>=123&&evt.getKeyChar()<=255){
             getToolkit().beep();
             evt.consume();
             error2.setText("INGRESA SOLO LETRAS Y NUMEROS!!");}
    }//GEN-LAST:event_correoKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Proveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(() -> {
            new Proveedores().setVisible(true);
        });
    }
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel annu;
    private javax.swing.JLabel annu1;
    private javax.swing.JLabel anucategoria;
    private javax.swing.JLabel anudescri;
    private javax.swing.JLabel anudireccion;
    private javax.swing.JLabel anuproveedor;
    private javax.swing.JLabel anutelefono1;
    private javax.swing.JTextField correo;
    private javax.swing.JTextField descripcion;
    private javax.swing.JTextField direccion;
    private javax.swing.JLabel error1;
    private javax.swing.JLabel error2;
    private javax.swing.JLabel error3;
    private javax.swing.JLabel error4;
    private javax.swing.JLabel error5;
    private javax.swing.JLabel fechaActual;
    private javax.swing.JLabel fondo;
    private javax.swing.JComboBox idcategoria;
    private javax.swing.JLabel idproveedor;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel label_iconotecnogas;
    private javax.swing.JButton limpiar;
    private javax.swing.JButton modificar;
    public static javax.swing.JLabel prove;
    private javax.swing.JTable tbclientes;
    private javax.swing.JTextField telefono;
    private javax.swing.JTextField txtbuscar;
    // End of variables declaration//GEN-END:variables

    
}
