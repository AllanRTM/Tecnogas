/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistematecnogas;

import Atxy2k.CustomTextField.RestrictedTextField;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.apache.log4j.PropertyConfigurator;

import servicios.conexion;
import static sistematecnogas.permisos.usePermiso;

/**
 *
 * @author radioshack
 */
public final class Categoria extends javax.swing.JFrame {

    
    final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(Categoria.class);
    
    static void addItem(String seleccione_una_opción) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * Creates new form Categoria
     */
    public Categoria() {
        initComponents();
        setLocationRelativeTo(null);
        cargar("");
        PropertyConfigurator.configure("log4j.properties");
        limita();
        lblFechaCreacion.setText(fecha());
        setTitle("Ingreso al sistema");
        mostrartipoproducto();
        setIconImage(new ImageIcon(getClass().getResource("/Imagen/image.png")).getImage());
    }
    public void limita(){
    RestrictedTextField limitarr =new RestrictedTextField(nombrecategoria);
    limitarr.setLimit(14);
    
    //nombrecategoria.setDocument(new limitar(nombrecategoria,3,12));
    
    }
    
     public static String fecha(){
    Date fecha = new Date();
    SimpleDateFormat formatofecha = new SimpleDateFormat("dd/MM/YYYY");
    return formatofecha.format(fecha);
    }
    
    void bloquear(){
    
    nombrecategoria.setEnabled(false);
    categoriabox.setEnabled(false);
    
    
    }
    void mostrartipoproducto(){
       String sql="SELECT * FROM `estado`";
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                categoriabox.addItem(rs.getString("estado"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Proveedores.class.getName()).log(Level.SEVERE, null, ex);
        }
       
   }
    void limpiar(){
    idcategoria.setText("");
    nombrecategoria.setText("");
    txtbuscar.setText("");
    categoriabox.setSelectedIndex(0);

    }
    void cargar(String valor){
    /*String mostrar="SELECT * FROM `categoria` WHERE '%"+valor+"%'";*/
    String mostrar="SELECT `id_categoria_productos`, `categoria`, `estado` FROM `categoria_productos` WHERE `categoria` LIKE '%"+valor+"%' OR `id_categoria_productos` LIKE '%"+valor+"%'";
    String []titulos={"Id de categoria","Nombre de categoria","Estado"};
    String []Registros=new String[4];
    DefaultTableModel model = new DefaultTableModel(null,titulos);
  
        try {
              Statement st = cn.createStatement();
              ResultSet rs = st.executeQuery(mostrar);
              while(rs.next())
              {
                  Registros[0]= rs.getString("id_categoria_productos");
                  Registros[1]= rs.getString("categoria");
                  Registros[2]= rs.getString("estado");
               
                           
                  model.addRow(Registros);
              }
              tbclientes.setModel(model);
        } catch (SQLException ex) {
            Logger.getLogger(Categoria.class.getName()).log(Level.SEVERE, null, ex);
        }
    
  }
    void bo(String dato){
   String cap1="";
        String sql="SELECT * FROM `usuariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo2(String dato){
   String cap1="";
        String sql="SELECT * FROM `proveedorrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.proveedores.setVisible(true);
            
            }
            else{
                panelcentral.proveedores.setVisible(false);
                panelcentral.jLabel2.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo3(String dato){
   String cap1="";
        String sql="SELECT * FROM `categoriarol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.categorias.setVisible(true);
            
            }
            else{
                panelcentral.categorias.setVisible(false);
                panelcentral.jLabel6.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo4(String dato){
   String cap1="";
        String sql="SELECT * FROM `bombasrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.bombas.setVisible(true);
            
            }
            else{
                panelcentral.jLabel5.setVisible(false);
                panelcentral.bombas.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo5(String dato){
   String cap1="";
        String sql="SELECT * FROM `productorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.productos.setVisible(true);
            
            }
            else{
                panelcentral.productos.setVisible(false);
                panelcentral.jLabel9.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo6(String dato){
   String cap1="";
        String sql="SELECT * FROM `seriedigitalrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario6.setVisible(true);
            
            }
            else{
                panelcentral.jLabel8.setVisible(false);
                panelcentral.usuario6.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo7(String dato){
   String cap1="";
        String sql="SELECT * FROM `inventariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario4.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo8(String dato){
   String cap1="";
        String sql="SELECT * FROM `preciorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.control.setVisible(true);
            
            }
            else{
                panelcentral.usuario4.setVisible(false);
                panelcentral.jLabel10.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        modificar = new javax.swing.JButton();
        limpiar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        label_iconotecnogas3 = new javax.swing.JLabel();
        nombrecategoria = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbclientes = new javax.swing.JTable();
        txtbuscar = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        categoriabox = new javax.swing.JComboBox<>();
        lblFechaCreacion = new javax.swing.JLabel();
        error1 = new javax.swing.JLabel();
        idcategoria = new javax.swing.JLabel();
        useCategoria = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        annu = new javax.swing.JLabel();
        annu1 = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        jMenu1.setText("jMenu1");

        jMenu2.setText("jMenu2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setText("Ingresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 170, 106, -1));

        jButton2.setText("Atrás");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, 111, -1));

        modificar.setText("Modificar");
        modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarActionPerformed(evt);
            }
        });
        getContentPane().add(modificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 420, 110, -1));

        limpiar.setText("Limpiar");
        limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limpiarActionPerformed(evt);
            }
        });
        getContentPane().add(limpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 420, 109, -1));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(785, 113, 31, -1));

        jLabel9.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        jLabel9.setText("Nombre de categoria");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 120, 132, 21));

        jLabel10.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel10.setText("ID Categoria");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 119, 109, 21));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(51, 153, 255));
        jLabel11.setText("Categorías");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(325, 27, 184, -1));

        label_iconotecnogas3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/logo_tecnogas_transp.png"))); // NOI18N
        label_iconotecnogas3.setText("jLabel4");
        label_iconotecnogas3.setPreferredSize(new java.awt.Dimension(270, 134));
        getContentPane().add(label_iconotecnogas3, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 40, 230, 125));

        nombrecategoria.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nombrecategoriaKeyTyped(evt);
            }
        });
        getContentPane().add(nombrecategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 170, 118, -1));

        tbclientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tbclientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbclientesMouseClicked(evt);
            }
        });
        tbclientes.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbclientesKeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(tbclientes);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 277, 760, 112));

        txtbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbuscarActionPerformed(evt);
            }
        });
        txtbuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtbuscarKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtbuscarKeyTyped(evt);
            }
        });
        getContentPane().add(txtbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(166, 239, 109, -1));

        jLabel13.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        jLabel13.setText("Buscar:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 238, -1, 21));

        jLabel12.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel12.setText("Estado");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 120, 54, 21));

        categoriabox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione" }));
        getContentPane().add(categoriabox, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 170, 122, -1));

        lblFechaCreacion.setText("dd/MM/YYYY");
        getContentPane().add(lblFechaCreacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, -1, -1));

        error1.setForeground(new java.awt.Color(255, 0, 0));
        error1.setText("...");
        getContentPane().add(error1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 200, 118, -1));

        idcategoria.setText("...");
        getContentPane().add(idcategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 176, 97, -1));

        useCategoria.setText("...");
        getContentPane().add(useCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 40, 70, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel7.setText("Usuario:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setText("Fecha:");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 40, -1));

        annu.setText("....");
        getContentPane().add(annu, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 450, 110, -1));

        annu1.setText("....");
        getContentPane().add(annu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 200, 110, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/fondo5.jpg"))); // NOI18N
        fondo.setText("jLabel4");
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 490));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        String cap="";
         
        String sql="SELECT * FROM `categoriarol` WHERE `nombre` = '"+useCategoria.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("insertar"); 
            }
            if(cap.equals("Activo"))
            {
             try {
 
            String sql1="INSERT INTO `categoria_productos` (`id_categoria_productos`, `categoria`, `estado`) VALUES (NULL, ?, ?)";
            PreparedStatement pst  = cn.prepareStatement(sql1);
            
            if (15>nombrecategoria.getText().length()&&nombrecategoria.getText().length()>3) {
            pst.setString(1, nombrecategoria.getText());  
            error1.setText("...");
            }else{
            logger.info("Minimo 3 y maximo 20 caracteres!!");
            error1.setText("Minimo 3 y maximo 20 caracteres!!");   
            }
            pst.setString(2, (String) categoriabox.getSelectedItem());  
           
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro Guardado con Exito");
            limita();
            logger.info("Hizo un insert en categoria el usuario: " +useCategoria.getText());
            cargar("");
            limpiar();
        
        } catch (SQLException ex) {
            logger.fatal(ex);
            logger.info(ex);
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista esa categoria que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
        }
            }
            else{
            jButton1.setEnabled(true);
            annu1.setText("No tienes permiso");
            logger.info("El usuario "+useCategoria.getText()+" inserto categoria. ");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.fatal("Error: "+ex);
            
        }  
              
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbuscarActionPerformed
        // TODO add your handling code here:
        cargar(txtbuscar.getText());
    }//GEN-LAST:event_txtbuscarActionPerformed

    private void txtbuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtbuscarKeyReleased
        // TODO add your handling code here:
        cargar(txtbuscar.getText());
        
    }//GEN-LAST:event_txtbuscarKeyReleased

    private void limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limpiarActionPerformed
        // TODO add your handling code here:
     
     limpiar();
    
    
     
    }//GEN-LAST:event_limpiarActionPerformed

    private void ModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificarActionPerformed
 
    }//GEN-LAST:event_ModificarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        panelcentral ingresar = new panelcentral();
        ingresar.setVisible(true);   
        panelcentral.User.setText(useCategoria.getText());
        this.dispose();
                     bo(useCategoria.getText());
                     bo2(useCategoria.getText());
                     bo3(useCategoria.getText());
                     bo4(useCategoria.getText());
                     bo5(useCategoria.getText());
                     bo6(useCategoria.getText());
                     bo7(useCategoria.getText());
                     bo8(useCategoria.getText());
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtbuscarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtbuscarKeyTyped
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txtbuscarKeyTyped

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked

        panelcentral botonatras = new panelcentral();
        botonatras.setVisible(true);
        this.dispose();       
        
    }//GEN-LAST:event_jButton2MouseClicked

    private void tbclientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbclientesMouseClicked
        
        int seleccionar = tbclientes.rowAtPoint(evt.getPoint());
        idcategoria.setText(String.valueOf(tbclientes.getValueAt(seleccionar, 0)));
        nombrecategoria.setText(String.valueOf(tbclientes.getValueAt(seleccionar, 1)));
        categoriabox.setSelectedItem(String.valueOf(tbclientes.getValueAt(seleccionar, 2)));
        
    }//GEN-LAST:event_tbclientesMouseClicked

    private void nombrecategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombrecategoriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombrecategoriaActionPerformed

    private void nombrecategoriaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nombrecategoriaKeyTyped
       
        char validar =evt.getKeyChar();
        
        if(evt.getKeyChar()>=32&&evt.getKeyChar()<=64||
                evt.getKeyChar()>=91&&evt.getKeyChar()<=96||
                evt.getKeyChar()>=123&&evt.getKeyChar()<=255){
             getToolkit().beep();
             evt.consume();
             error1.setText("INGRESA SOLO LETRAS !!");
        }
       
             
        
    }//GEN-LAST:event_nombrecategoriaKeyTyped

    private void categoriaboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_categoriaboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_categoriaboxActionPerformed

    private void nombrecategoriaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nombrecategoriaKeyReleased
        // TODO add your handling code here:
        if (!nombrecategoria.getText().isEmpty()) {
            error1.setText("");
            
        }
    }//GEN-LAST:event_nombrecategoriaKeyReleased

    private void tbclientesKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbclientesKeyPressed
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_tbclientesKeyPressed

    private void modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarActionPerformed

        String cap="";
         
        String sql="SELECT * FROM `categoriarol` WHERE `nombre` = '"+useCategoria.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("insertar"); 
            }
            if(cap.equals("Activo"))
            {
             
              try {
        PreparedStatement pst = cn.prepareStatement("UPDATE `categoria_productos` SET `Id_categoria_productos`= '"+idcategoria.getText()+"',`categoria`= ?, `estado`= ? WHERE `Id_categoria_productos`='"+idcategoria.getText()+"'");
        
        if (15>nombrecategoria.getText().length()&&nombrecategoria.getText().length()>3) {
            pst.setString(1, nombrecategoria.getText());  
            error1.setText("...");
            }else{
            logger.info("Se equivoco al introducir nombre de categoria al actualizar el usuario: " +useCategoria.getText());
            error1.setText("Minimo 3 y maximo 20 caracteres!!");   
        }
        pst.setString(2, (String) categoriabox.getSelectedItem());
        pst.executeUpdate();
        limita(); 
        
        logger.info("Actualizo datos en categoria el dato: "+nombrecategoria.getText()+" el usuario: " +useCategoria.getText());
        
        JOptionPane.showMessageDialog(null, "Datos actualizados","ERROR",JOptionPane.INFORMATION_MESSAGE);
        
        limpiar();
        cargar("");
    } catch (Exception e) {
       logger.fatal("Error fatal en categoria el usuario: " +useCategoria.getText()+" Error :"+e);
       JOptionPane.showMessageDialog(rootPane, "Revise que no exista esa categoria que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
       
    }  
                
            }
            else{
            jButton1.setEnabled(true);
            annu.setText("No tienes permiso");
            logger.info("El usuario "+useCategoria.getText()+" inserto categoria. ");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.fatal("Error: "+ex);
            
        }  
        
        
    }//GEN-LAST:event_modificarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Categoria.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Categoria.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Categoria.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Categoria.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Categoria().setVisible(true);
        });
    }
    conexion cc = new conexion();
    Connection cn = conexion.conexion();

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel annu;
    private javax.swing.JLabel annu1;
    private javax.swing.JComboBox<String> categoriabox;
    private javax.swing.JLabel error1;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel idcategoria;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel label_iconotecnogas3;
    private javax.swing.JLabel lblFechaCreacion;
    private javax.swing.JButton limpiar;
    private javax.swing.JButton modificar;
    private javax.swing.JTextField nombrecategoria;
    private javax.swing.JTable tbclientes;
    private javax.swing.JTextField txtbuscar;
    public static javax.swing.JLabel useCategoria;
    // End of variables declaration//GEN-END:variables
}
