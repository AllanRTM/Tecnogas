/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistematecnogas;

import Atxy2k.CustomTextField.RestrictedTextField;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.util.Date;
import java.text.SimpleDateFormat;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

//import Atxy2k.CustomTextField.RestrictedTextField;
import javax.swing.table.DefaultTableModel;
import servicios.conexion;
import static sistematecnogas.Control_Combustible_Diario.logger;
import static sistematecnogas.Ingreso_Bombas.useBomba;
import static sistematecnogas.panelcentral.User;
import static sistematecnogas.panelcentral.logger;


/**
 *
 * @author radioshack
 */
public class ingresarUsuario extends javax.swing.JFrame {

    Statement sent;
final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(Proveedores.class);
    public static String fecha() {
        Date fecha = new Date();
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/YYYY");
        return formatoFecha.format(fecha);
        
    }
    public void limita(){
    RestrictedTextField limitarr =new RestrictedTextField(txtNombre);
    limitarr.setLimit(20);
    RestrictedTextField limitarr1 =new RestrictedTextField(txtPassword);
    limitarr1.setLimit(20);
   
    
    //nombrecategoria.setDocument(new limitar(nombrecategoria,3,12));
    
    }
    /*public void cargar(){
    String mostrar = "SELECT `id_usuario`, `nombre`, `contraseña`, `tipo_usuario`, `estado_usuario`, `fecha_ingreso`, `fecha_actualizacion` FROM `usuarios` WHERE 1";
        String[] titulos = {"id_usuario", "Nombre", "Contraseña", "Tipo de usuario", "Estado", "Fecha de ingreso","Fecha de actualizacion"};
        String[] Registros = new String[8];
        DefaultTableModel model = new DefaultTableModel(null, titulos);

        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(mostrar);
            while (rs.next()) {
                Registros[0] = rs.getString("id_usuario");
                Registros[1] = rs.getString("nombre");
                Registros[2] = rs.getString("contraseña");
                Registros[3] = rs.getString("tipo_usuario");
                Registros[4] = rs.getString("estado_usuario");
                Registros[5] = rs.getString("fecha_ingreso");
                Registros[6] = rs.getString("fecha_actualizacion");
                
           
                model.addRow(Registros);
            }
            tblUsuario.setModel(model);
        } catch (java.sql.SQLException ex) {
            Logger.getLogger(Categoria.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/
    void cargar1(String dato){
    String mostrar = "SELECT `id_usuario`, `nombre`, `contraseña`, `tipo_usuario`, `estado_usuario`, `fecha_ingreso`, `fecha_actualizacion` FROM `usuarios` WHERE  `id_usuario` LIKE '%"+dato+"%' OR `nombre` LIKE '%"+dato+"%'";
        String[] titulos = {"id_usuario", "Nombre", "Contraseña", "Tipo de usuario", "Estado", "Fecha de ingreso","Fecha de actualizacion"};
        String[] Registros = new String[8];
        DefaultTableModel model = new DefaultTableModel(null, titulos);

        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(mostrar);
            while (rs.next()) {
                Registros[0] = rs.getString("id_usuario");
                Registros[1] = rs.getString("nombre");
                Registros[2] = rs.getString("contraseña");
                Registros[3] = rs.getString("tipo_usuario");
                Registros[4] = rs.getString("estado_usuario");
                Registros[5] = rs.getString("fecha_ingreso");
                Registros[6] = rs.getString("fecha_actualizacion");
                
           
                model.addRow(Registros);
            }
            tblUsuario.setModel(model);
            
        } catch (java.sql.SQLException ex) {
            Logger.getLogger(Categoria.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public void clear(){
        txtID.setText("");
        txtNombre.setText("");
        txtPassword.setText("");
        txtBuscar.setText("");
        comboEstado.setSelectedIndex(0);
        comboTipo.setSelectedIndex(0);
        
    }

    public ingresarUsuario() {
        initComponents();
        asterisco();
        setLocationRelativeTo(null);
        limita();
        setIconImage(new ImageIcon(getClass().getResource("/Imagen/image.png")).getImage());
        txtID.setEnabled(false);
        lblFechaCreacion.setText(fecha());
        
        cargar1("");
      
        try {
            sent = cn.createStatement();
            String sql = "SELECT * FROM `estado` ";
            java.sql.Statement st = cn.createStatement();
            java.sql.ResultSet rs = sent.executeQuery(sql);
            comboEstado.addItem("seleccione estado");
            while (rs.next()) {

                this.comboEstado.addItem(rs.getString("estado"));
            }
        } catch (java.sql.SQLException e) {

        }

        try {
            sent = cn.createStatement();
            String sql = "SELECT * FROM `tipo_usuario` ";
            java.sql.Statement st = cn.createStatement();
            java.sql.ResultSet rs = sent.executeQuery(sql);
            comboTipo.addItem("seleccione tipo");
            while (rs.next()) {

                this.comboTipo.addItem(rs.getString("tipo_usuario"));
            }
        } catch (java.sql.SQLException e) {

        }
    }

    public void asterisco() {
        if (txtNombre.getText().isEmpty()) {
            asteriscoNombre.setText("*");
        } else {
            asteriscoNombre.setText(" ");
        }
        if (txtPassword.getText().isEmpty()) {
            asteriscoPassword.setText("*");
        } else {
            asteriscoPassword.setText(" ");
        }

        if (comboEstado.getSelectedItem() == comboEstado.getItemAt(0)) {
            asteriscoEstado.setText("*");
        } else {
            asteriscoEstado.setText("");
        }
        if (comboTipo.getSelectedItem() == comboTipo.getItemAt(0)) {
            asteriscoTipo.setText("*");
        } else {
            asteriscoTipo.setText("");
        }

    }
     void bo(String dato){
   String cap1="";
        String sql="SELECT * FROM `usuariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo2(String dato){
   String cap1="";
        String sql="SELECT * FROM `proveedorrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.proveedores.setVisible(true);
            
            }
            else{
                panelcentral.proveedores.setVisible(false);
                panelcentral.jLabel2.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo3(String dato){
   String cap1="";
        String sql="SELECT * FROM `categoriarol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.categorias.setVisible(true);
            
            }
            else{
                panelcentral.categorias.setVisible(false);
                panelcentral.jLabel6.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo4(String dato){
   String cap1="";
        String sql="SELECT * FROM `bombasrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.bombas.setVisible(true);
            
            }
            else{
                panelcentral.jLabel5.setVisible(false);
                panelcentral.bombas.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo5(String dato){
   String cap1="";
        String sql="SELECT * FROM `productorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.productos.setVisible(true);
            
            }
            else{
                panelcentral.productos.setVisible(false);
                panelcentral.jLabel9.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo6(String dato){
   String cap1="";
        String sql="SELECT * FROM `seriedigitalrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario6.setVisible(true);
            
            }
            else{
                panelcentral.jLabel8.setVisible(false);
                panelcentral.usuario6.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo7(String dato){
   String cap1="";
        String sql="SELECT * FROM `inventariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario4.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo8(String dato){
   String cap1="";
        String sql="SELECT * FROM `preciorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.control.setVisible(true);
            
            }
            else{
                panelcentral.usuario4.setVisible(false);
                panelcentral.jLabel10.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        txtNombre = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        txtID = new javax.swing.JTextField();
        lblFechaCreacion = new javax.swing.JLabel();
        comboTipo = new javax.swing.JComboBox<>();
        comboEstado = new javax.swing.JComboBox<>();
        InseP = new javax.swing.JLabel();
        btnAtras = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblUsuario = new javax.swing.JTable();
        use = new javax.swing.JLabel();
        btnModificar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        txtBuscar = new javax.swing.JTextField();
        asteriscoNombre = new javax.swing.JLabel();
        asteriscoPassword = new javax.swing.JLabel();
        asteriscoTipo = new javax.swing.JLabel();
        asteriscoEstado = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        label_iconotecnogas = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(650, 640));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombreKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });
        getContentPane().add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 150, -1));

        txtPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPasswordActionPerformed(evt);
            }
        });
        txtPassword.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPasswordKeyReleased(evt);
            }
        });
        getContentPane().add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, 150, -1));

        jButton1.setText("Registrar Usuario");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(415, 296, -1, -1));
        getContentPane().add(txtID, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 70, 150, -1));

        lblFechaCreacion.setText("dd/MM/YYYY");
        getContentPane().add(lblFechaCreacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, -1, -1));

        comboTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboTipoActionPerformed(evt);
            }
        });
        comboTipo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                comboTipoKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                comboTipoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                comboTipoKeyTyped(evt);
            }
        });
        getContentPane().add(comboTipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 210, 150, -1));

        comboEstado.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                comboEstadoKeyReleased(evt);
            }
        });
        getContentPane().add(comboEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 270, 149, -1));

        InseP.setText("....");
        getContentPane().add(InseP, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 330, 110, -1));

        btnAtras.setText("Atrás");
        btnAtras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAtrasMouseClicked(evt);
            }
        });
        btnAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasActionPerformed(evt);
            }
        });
        getContentPane().add(btnAtras, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 502, 110, -1));

        tblUsuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tblUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblUsuarioMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblUsuario);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 383, 609, 109));

        use.setText("jLabel2");
        getContentPane().add(use, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, -1, -1));

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        getContentPane().add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(509, 502, 110, -1));

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(275, 502, 110, -1));

        txtBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarActionPerformed(evt);
            }
        });
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBuscarKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 348, 150, -1));

        asteriscoNombre.setBackground(new java.awt.Color(255, 0, 0));
        asteriscoNombre.setForeground(new java.awt.Color(255, 0, 0));
        asteriscoNombre.setText("jlabel");
        getContentPane().add(asteriscoNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(146, 137, 150, -1));

        asteriscoPassword.setBackground(new java.awt.Color(255, 0, 0));
        asteriscoPassword.setForeground(new java.awt.Color(255, 0, 0));
        asteriscoPassword.setText("jLabel7");
        getContentPane().add(asteriscoPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(146, 188, 150, -1));

        asteriscoTipo.setBackground(new java.awt.Color(255, 0, 0));
        asteriscoTipo.setForeground(new java.awt.Color(255, 0, 0));
        asteriscoTipo.setText("jLabel9");
        getContentPane().add(asteriscoTipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 240, 186, -1));

        asteriscoEstado.setBackground(new java.awt.Color(255, 0, 0));
        asteriscoEstado.setForeground(new java.awt.Color(255, 0, 0));
        asteriscoEstado.setText("jLabel0");
        getContentPane().add(asteriscoEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 300, -1, -1));

        jLabel6.setText("Buscar:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 351, -1, -1));

        label_iconotecnogas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/logo_tecnogas_transp.png"))); // NOI18N
        label_iconotecnogas.setPreferredSize(new java.awt.Dimension(650, 600));
        getContentPane().add(label_iconotecnogas, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 90, 226, 152));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("ID de usuario:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("Nombre:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 114, 79, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Tipo de usuario:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 209, 110, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("Contraseña:");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 161, 102, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("Estado de usuario:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, -1, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(51, 153, 255));
        jLabel17.setText("Registro de usuarios");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 20, -1, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel14.setText("Fecha:");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 50, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel7.setText("Usuario:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/fondo5.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-40, -220, 680, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        //metodo de seguridad
        
        String cap="";
         
        String sql="SELECT * FROM `usuariorol` WHERE `nombre` = '"+User.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("insertar"); 
            }
            if(cap.equals("Activo"))
            {
             
            try {
            
            
            String sql1= "INSERT INTO `usuarios` (`id_usuario`, `nombre`, `contraseña`, `tipo_usuario`, `estado_usuario`, `fecha_ingreso`, `fecha_actualizacion`) VALUES (NULL, ?, MD5(?), ?, ?, SYSDATE(), SYSDATE())";
            PreparedStatement pst = cn.prepareStatement(sql1);

            if (txtNombre.getText().isEmpty() || txtPassword.getText().isEmpty() || (comboEstado.getSelectedItem()==comboEstado.getItemAt(0)) || (comboTipo.getSelectedItem()==comboEstado.getItemAt(0))) {
                asteriscoEstado.setText("No puede estar vacio");
                asteriscoNombre.setText("No puede estar vacio");
                asteriscoPassword.setText("No puede estar vacio");
                asteriscoTipo.setText("No puede estar vacio");
                
            }else if (txtNombre.getText().length() < 3 || txtPassword.getText().length() < 6) {
            asteriscoNombre.setText("Minimo 3 caracteres");
            asteriscoPassword.setText("Minimo 6 caracteres");
            } 
            else if (txtNombre.getText().length() > 20 || txtPassword.getText().length() > 20) {
                 JOptionPane.showMessageDialog(null, "Los campos no pueden tener mas de 20 caracteres","Error",JOptionPane.ERROR_MESSAGE);
                    
            } else {
                pst.setString(1, txtNombre.getText());
                pst.setString(2, txtPassword.getText());
                String value = comboTipo.getSelectedItem().toString();
                pst.setString(3, value);
                String value1 = comboEstado.getSelectedItem().toString();
                pst.setString(4, value1);
                
                String consulta2 = "INSERT INTO `usuariorol` (`id`, `nombre`, `insertar`, `modificar`, `ver`) VALUES (NULL, '"+txtNombre.getText()+"', 'inactivo', 'inactivo', 'inactivo')";
                PreparedStatement ps1 = cn.prepareStatement(consulta2);
                ps1.execute();
                
                String consulta3 = "INSERT INTO `categoriarol` (`id`, `nombre`, `insertar`, `modificar`, `ver`) VALUES (NULL, '"+txtNombre.getText()+"', 'inactivo', 'inactivo', 'inactivo')";
                PreparedStatement ps2 = cn.prepareStatement(consulta3);
                ps2.execute();
                
                String consulta4 = "INSERT INTO `controldiariorol` (`id`, `nombre`, `insertar`, `modificar`, `ver`) VALUES (NULL, '"+txtNombre.getText()+"', 'inactivo', 'inactivo', 'inactivo')";
                PreparedStatement ps3 = cn.prepareStatement(consulta4);
                ps3.execute();
                
                String consulta5 = "INSERT INTO `inventariorol` (`id`, `nombre`, `insertar`, `modificar`, `ver`) VALUES (NULL, '"+txtNombre.getText()+"', 'inactivo', 'inactivo', 'inactivo')";
                PreparedStatement ps4 = cn.prepareStatement(consulta5);
                ps4.execute();
                
                String consulta6 = "INSERT INTO `preciorol` (`id`, `nombre`, `insertar`, `modificar`, `ver`) VALUES (NULL, '"+txtNombre.getText()+"', 'inactivo', 'inactivo', 'inactivo')";
                PreparedStatement ps5 = cn.prepareStatement(consulta6);
                ps5.execute();
                
                String consulta7 = "INSERT INTO `productorol` (`id`, `nombre`, `insertar`, `modificar`, `ver`) VALUES (NULL, '"+txtNombre.getText()+"', 'inactivo', 'inactivo', 'inactivo')";
                PreparedStatement ps6 = cn.prepareStatement(consulta7);
                ps6.execute();
                
                String consulta8 = "INSERT INTO `proveedorrol` (`id`, `nombre`, `insertar`, `modificar`, `ver`) VALUES (NULL, '"+txtNombre.getText()+"', 'inactivo', 'inactivo', 'inactivo')";
                PreparedStatement ps7 = cn.prepareStatement(consulta8);
                ps7.execute();
                
                String consulta9 = "INSERT INTO `seriedigitalrol` (`id`, `nombre`, `insertar`, `modificar`, `ver`) VALUES (NULL, '"+txtNombre.getText()+"', 'inactivo', 'inactivo', 'inactivo')";
                PreparedStatement ps8 = cn.prepareStatement(consulta9);
                ps8.execute();
                
                String consulta10 = "INSERT INTO `bombasrol` (`id`, `nombre`, `insertar`, `modificar`, `ver`) VALUES (NULL, '"+txtNombre.getText()+"', 'inactivo', 'inactivo', 'inactivo')";
                PreparedStatement ps9 = cn.prepareStatement(consulta10);
                ps9.execute();
                
                
            }
                
            
          
            
                
            int n = pst.executeUpdate();
            if (n > 0) {
            JOptionPane.showMessageDialog(null, "datos guardados");
            cargar1("");
            clear();
            }
            
                
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Ingresa todos los datos correctamente","Error: ",JOptionPane.ERROR_MESSAGE);//"INGRESA TODOS LOS VALORES CORRECTAMENTE","Error",JOptionPane.ERROR_MESSAGE);
        }    
                
             logger.info("El usuario "+User.getText()+" agrego usuario. ");
                
            }
            else{
            jButton1.setEnabled(true);
            InseP.setText("No tienes permiso");
            logger.info("El usuario "+User.getText()+" agrego usuario. ");
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.fatal("Error: "+ex);
            
        }  

        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnAtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtrasActionPerformed
        // TODO add your handling code here:
        panelcentral ingresar = new panelcentral();
        ingresar.setVisible(true);   
        panelcentral.User.setText(use.getText());
        this.dispose();
        bo(use.getText());
                     bo2(use.getText());
                     bo3(use.getText());
                     bo4(use.getText());
                     bo5(use.getText());
                     bo6(use.getText());
                     bo7(use.getText());
                     bo8(use.getText());
    }//GEN-LAST:event_btnAtrasActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        // TODO add your handling code here:
        
        String cap="";
         
        String sql="SELECT * FROM `usuariorol` WHERE `nombre` = '"+User.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("modificar"); 
            }
            if(cap.equals("Activo"))
            {
             try {
            
            String sql1=("UPDATE `usuarios` SET `nombre` = ?, `contraseña` = MD5(?), `tipo_usuario` = ?, `estado_usuario` = ?, `fecha_actualizacion` = SYSDATE() WHERE `usuarios`.`id_usuario` = '"+txtID.getText()+"'");
            PreparedStatement pst = cn.prepareStatement(sql1);
            
            if (txtNombre.getText().isEmpty() || txtPassword.getText().isEmpty() || (comboEstado.getSelectedItem()==comboEstado.getItemAt(0)) || (comboTipo.getSelectedItem()==comboEstado.getItemAt(0))) {
                
                asteriscoEstado.setText("No puede estar vacio");
                asteriscoNombre.setText("No puede estar vacio");
                asteriscoPassword.setText("No puede estar vacio");
                asteriscoTipo.setText("No puede estar vacio");
                
            }else if (txtNombre.getText().length() < 3 || txtPassword.getText().length() < 6) {
            asteriscoNombre.setText("Minimo 3 caracteres");
            asteriscoPassword.setText("Minimo 6 caracteres");
            } 
            else if (txtNombre.getText().length() > 20 || txtPassword.getText().length() > 20) {
                 JOptionPane.showMessageDialog(null, "Los campos no pueden tener mas de 20 caracteres","Error",JOptionPane.ERROR_MESSAGE);
                    
            } else {
                pst.setString(1, txtNombre.getText());
                pst.setString(2, txtPassword.getText());
                String value = comboTipo.getSelectedItem().toString();
                pst.setString(3, value);
                String value1 = comboEstado.getSelectedItem().toString();
                pst.setString(4, value1);
                
                //creacion de permisos por defecto.
                
                String consulta2 = "UPDATE `usuariorol` SET `nombre` = '"+txtNombre.getText()+"' WHERE `usuariorol`.`id` = '"+txtID.getText()+"'";
                PreparedStatement ps1 = cn.prepareStatement(consulta2);
                ps1.execute();
                
                String consulta3 = "UPDATE `categoriarol` SET `nombre` = '"+txtNombre.getText()+"' WHERE `categoriarol`.`id` = '"+txtID.getText()+"'";
                PreparedStatement ps2 = cn.prepareStatement(consulta3);
                ps2.execute();
                
                String consulta4 = "UPDATE `controldiariorol` SET `nombre` = '"+txtNombre.getText()+"' WHERE `controldiariorol`.`id` = '"+txtID.getText()+"'";
                PreparedStatement ps3 = cn.prepareStatement(consulta4);
                ps3.execute();
                
                String consulta5 = "UPDATE `inventariorol` SET `nombre` = '"+txtNombre.getText()+"' WHERE `inventariorol`.`id` = '"+txtID.getText()+"'";
                PreparedStatement ps4 = cn.prepareStatement(consulta5);
                ps4.execute();
                
                String consulta6 = "UPDATE `preciorol` SET `nombre` = '"+txtNombre.getText()+"' WHERE `preciorol`.`id` = '"+txtID.getText()+"'";
                PreparedStatement ps5 = cn.prepareStatement(consulta6);
                ps5.execute();
                
                String consulta7 = "UPDATE `productorol` SET `nombre` = '"+txtNombre.getText()+"' WHERE `productorol`.`id` = '"+txtID.getText()+"'";
                PreparedStatement ps6 = cn.prepareStatement(consulta7);
                ps6.execute();
                
                String consulta8 = "UPDATE `proveedorrol` SET `nombre` = '"+txtNombre.getText()+"' WHERE `proveedorrol`.`id` = '"+txtID.getText()+"'";
                PreparedStatement ps7 = cn.prepareStatement(consulta8);
                ps7.execute();
                
                String consulta9 = "UPDATE `seriedigitalrol` SET `nombre` = '"+txtNombre.getText()+"' WHERE `seriedigitalrol`.`id` = '"+txtID.getText()+"'";
                PreparedStatement ps8 = cn.prepareStatement(consulta9);
                ps8.execute();
                
                String consulta10 = "UPDATE `bombasrol` SET `nombre` = '"+txtNombre.getText()+"' WHERE `bombasrol`.`id` = '"+txtID.getText()+"'";
                PreparedStatement ps9 = cn.prepareStatement(consulta10);
                ps9.execute();
                
                
            }
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "LOS DATOS HAN SIDO MODIFICADOS");
            clear();
            cargar1("");
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "INGRESA TODOS LOS DATOS CORRECTAMENTE","Error",JOptionPane.ERROR_MESSAGE);
        }
            }
            else{
            jButton1.setEnabled(true);
            InseP.setText("No tienes permiso");
            logger.info("El usuario "+User.getText()+" agrego usuario. ");
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.fatal("Error: "+ex);
            
        }  
        
        
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        // TODO add your handling code here:
        clear();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void tblUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblUsuarioMouseClicked
        // TODO add your handling code here:
        int seleccionar = tblUsuario.rowAtPoint(evt.getPoint());
        txtID.setText(String.valueOf(tblUsuario.getValueAt(seleccionar, 0)));
        txtNombre.setText(String.valueOf(tblUsuario.getValueAt(seleccionar, 1)));
        txtPassword.setText(String.valueOf(tblUsuario.getValueAt(seleccionar, 2)));
        comboTipo.setSelectedItem(String.valueOf(tblUsuario.getValueAt(seleccionar, 3)));
        comboEstado.setSelectedItem(String.valueOf(tblUsuario.getValueAt(seleccionar, 4)));
    }//GEN-LAST:event_tblUsuarioMouseClicked

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    
    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed
        // TODO add your handling code here:
        cargar1(txtBuscar.getText());
    }//GEN-LAST:event_txtBuscarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        // TODO add your handling code here:
        cargar1(txtBuscar.getText());
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void txtBuscarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyPressed
        // TODO add your handling code here:
        // cargar(txtBuscar.getText());
    }//GEN-LAST:event_txtBuscarKeyPressed

    private void txtNombreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyReleased
        // TODO add your handling code here:
        asterisco();
    }//GEN-LAST:event_txtNombreKeyReleased

    private void comboTipoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_comboTipoKeyReleased
        asterisco();        // TODO add your handling code here:
       
    }//GEN-LAST:event_comboTipoKeyReleased

    private void txtPasswordKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPasswordKeyReleased
        // TODO add your handling code here:
        asterisco();
    }//GEN-LAST:event_txtPasswordKeyReleased

    private void comboEstadoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_comboEstadoKeyReleased
        // TODO add your handling code here:
        asterisco();
    }//GEN-LAST:event_comboEstadoKeyReleased

    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped
        // TODO add your handling code here:
        char validar = evt.getKeyChar();
     
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 64
                || evt.getKeyChar() >= 91 && evt.getKeyChar() <= 96
                || evt.getKeyChar() >= 123 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(rootPane, "Solo se permiten letras");
        }
    }//GEN-LAST:event_txtNombreKeyTyped

    private void comboTipoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_comboTipoKeyPressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_comboTipoKeyPressed

    private void comboTipoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_comboTipoKeyTyped
        // TODO add your handling code here:
        
    }//GEN-LAST:event_comboTipoKeyTyped

    private void comboTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboTipoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboTipoActionPerformed

    private void txtPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPasswordActionPerformed

    private void btnAtrasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAtrasMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btnAtrasMouseClicked
    /**
     *
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ingresarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ingresarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ingresarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ingresarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new ingresarUsuario().setVisible(true);
        });
    }

    conexion cc = new conexion();
    Connection cn = conexion.conexion();

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel InseP;
    private javax.swing.JLabel asteriscoEstado;
    private javax.swing.JLabel asteriscoNombre;
    private javax.swing.JLabel asteriscoPassword;
    private javax.swing.JLabel asteriscoTipo;
    private javax.swing.JButton btnAtras;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> comboEstado;
    private javax.swing.JComboBox<String> comboTipo;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_iconotecnogas;
    private javax.swing.JLabel lblFechaCreacion;
    private javax.swing.JTable tblUsuario;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JPasswordField txtPassword;
    public static javax.swing.JLabel use;
    // End of variables declaration//GEN-END:variables

    
}
