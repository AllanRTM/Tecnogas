/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistematecnogas;


import javax.swing.JTextField;

import javax.swing.text.PlainDocument;

/**
 *
 * @author radioshack
 */
public class limitar extends PlainDocument{
    private final JTextField editor;
    private final int max;
    private final int min;
    
    
 

    public limitar(JTextField editor, int max,int min) {
        this.editor = editor;
        this.max = max;
        this.min= min;
       
        
    }
   public static boolean limitar(String in,int max,int min){
    
        return max>in.length()&& in.length()>min;
    }

    
    

    
    /*public void insertString(int arg0,String arg1,AttributeSet arg2)throws BadLocationException {
        if (editor.getText().length()+arg1.length()>this.max ||editor.getText().length()+arg1.length()>this.min) {
            
                return;
            
        }
        super.insertString(arg0, arg1, arg2);
        
    }*/

    

   
     
    
}
