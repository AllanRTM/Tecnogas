/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistematecnogas;

import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;
import servicios.conexion;
import static sistematecnogas.Categoria.fecha;
import static sistematecnogas.Categoria.logger;
import static sistematecnogas.SerieDigital.useDigital;
import static sistematecnogas.panelcentral.User;

/**
 *
 * @author radioshack
 */
public class Serie extends javax.swing.JFrame {

    /**
     * Creates new form Serie
     */
    conexion cc = new conexion();
    Connection cn = conexion.conexion();
    public Serie() {
        initComponents();
        setLocationRelativeTo(null);
        fechaActual.setText(fecha());
    }
    void bo(String dato){
   String cap1="";
        String sql="SELECT * FROM `usuariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo2(String dato){
   String cap1="";
        String sql="SELECT * FROM `proveedorrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.proveedores.setVisible(true);
            
            }
            else{
                panelcentral.proveedores.setVisible(false);
                panelcentral.jLabel2.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo3(String dato){
   String cap1="";
        String sql="SELECT * FROM `categoriarol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.categorias.setVisible(true);
            
            }
            else{
                panelcentral.categorias.setVisible(false);
                panelcentral.jLabel6.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo4(String dato){
   String cap1="";
        String sql="SELECT * FROM `bombasrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.bombas.setVisible(true);
            
            }
            else{
                panelcentral.jLabel5.setVisible(false);
                panelcentral.bombas.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo5(String dato){
   String cap1="";
        String sql="SELECT * FROM `productorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.productos.setVisible(true);
            
            }
            else{
                panelcentral.productos.setVisible(false);
                panelcentral.jLabel9.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo6(String dato){
   String cap1="";
        String sql="SELECT * FROM `seriedigitalrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario6.setVisible(true);
            
            }
            else{
                panelcentral.jLabel8.setVisible(false);
                panelcentral.usuario6.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo7(String dato){
   String cap1="";
        String sql="SELECT * FROM `inventariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario4.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo8(String dato){
   String cap1="";
        String sql="SELECT * FROM `preciorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.control.setVisible(true);
            
            }
            else{
                panelcentral.usuario4.setVisible(false);
                panelcentral.jLabel10.setVisible(false);
 
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        usuario4 = new javax.swing.JButton();
        usuario3 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        usuSerie = new javax.swing.JLabel();
        a = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        fechaActual = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        jLabel5.setText("Serie mecanica");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(239, 111, 110, 23));

        jLabel4.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        jLabel4.setText("Serie digital");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 111, 110, 23));

        usuario4.setBackground(new java.awt.Color(204, 204, 204));
        usuario4.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        usuario4.setText("Ingresar");
        usuario4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usuario4MouseClicked(evt);
            }
        });
        usuario4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usuario4ActionPerformed(evt);
            }
        });
        getContentPane().add(usuario4, new org.netbeans.lib.awtextra.AbsoluteConstraints(239, 144, 110, -1));

        usuario3.setBackground(new java.awt.Color(204, 204, 204));
        usuario3.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        usuario3.setText("Ingresar");
        usuario3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usuario3MouseClicked(evt);
            }
        });
        usuario3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usuario3ActionPerformed(evt);
            }
        });
        getContentPane().add(usuario3, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 144, 110, -1));

        jButton3.setText("Atrás");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 250, 109, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(51, 153, 255));
        jLabel17.setText("Series");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 50, -1, -1));

        usuSerie.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        usuSerie.setText("....");
        getContentPane().add(usuSerie, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 40, 50, -1));

        a.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        a.setText("Fecha:");
        getContentPane().add(a, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 40, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel2.setText("Usuario:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        fechaActual.setText("....");
        getContentPane().add(fechaActual, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, 70, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/fondo5.jpg"))); // NOI18N
        fondo.setText("jLabel4");
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, 320));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void usuario4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usuario4MouseClicked

    }//GEN-LAST:event_usuario4MouseClicked

    private void usuario4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usuario4ActionPerformed
        // TODO add your handling code here:
        SerieMecanicas entrar = new SerieMecanicas();
        entrar.setVisible(true); 
        SerieMecanicas.useMecanica.setText(usuSerie.getText());
        this.dispose();
    }//GEN-LAST:event_usuario4ActionPerformed

    private void usuario3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usuario3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_usuario3MouseClicked

    private void usuario3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usuario3ActionPerformed
        // TODO add your handling code here:
        SerieDigital entrar = new SerieDigital();
        entrar.setVisible(true); 
        SerieDigital.useDigital.setText(usuSerie.getText());
        this.dispose();
    }//GEN-LAST:event_usuario3ActionPerformed

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
             // TODO add your handling code here:
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        panelcentral botonatras = new panelcentral();
        botonatras.setVisible(true);
        panelcentral.User.setText(usuSerie.getText());
        this.dispose();  
        bo(usuSerie.getText());
                     bo2(usuSerie.getText());
                     bo3(usuSerie.getText());
                     bo4(usuSerie.getText());
                     bo5(usuSerie.getText());
                     bo6(usuSerie.getText());
                     bo7(usuSerie.getText());
                     bo8(usuSerie.getText());
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Serie.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Serie.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Serie.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Serie.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Serie().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel a;
    private javax.swing.JLabel fechaActual;
    private javax.swing.JLabel fondo;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    public static javax.swing.JLabel usuSerie;
    private javax.swing.JButton usuario3;
    private javax.swing.JButton usuario4;
    // End of variables declaration//GEN-END:variables
}
