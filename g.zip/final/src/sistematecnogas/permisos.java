/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistematecnogas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import servicios.conexion;
import static sistematecnogas.Categoria.logger;

/**
 *
 * @author radioshack
 */
public class permisos extends javax.swing.JFrame {

    /**
     * Creates new form permisos
     */
    conexion cc = new conexion();
    Connection cn = conexion.conexion();
    public permisos() {
        initComponents();
        setLocationRelativeTo(null);
         mInsertar();
         mModificar();
         mVer();
         mUsuario();
         
    }
    void limpiar(){
    user.setSelectedIndex(0);
    insertar.setSelectedIndex(0);
    modificar.setSelectedIndex(0);
    ver.setSelectedIndex(0);
    
    user1.setSelectedIndex(0);
    insertar1.setSelectedIndex(0);
    modificar1.setSelectedIndex(0);
    ver1.setSelectedIndex(0);
    
    user2.setSelectedIndex(0);
    insertar2.setSelectedIndex(0);
    modificar2.setSelectedIndex(0);
    ver2.setSelectedIndex(0);
    
    user3.setSelectedIndex(0);
    insertar3.setSelectedIndex(0);
    modificar3.setSelectedIndex(0);
    ver3.setSelectedIndex(0);
    
    user4.setSelectedIndex(0);
    insertar4.setSelectedIndex(0);
    modificar4.setSelectedIndex(0);
    ver4.setSelectedIndex(0);
    
    user5.setSelectedIndex(0);
    insertar5.setSelectedIndex(0);
    modificar5.setSelectedIndex(0);
    ver5.setSelectedIndex(0);
    
    user6.setSelectedIndex(0);
    insertar6.setSelectedIndex(0);
    modificar6.setSelectedIndex(0);
    ver6.setSelectedIndex(0);
    
    user7.setSelectedIndex(0);
    insertar7.setSelectedIndex(0);
    modificar7.setSelectedIndex(0);
    ver7.setSelectedIndex(0);
    
    user8.setSelectedIndex(0);
    insertar8.setSelectedIndex(0);
    modificar8.setSelectedIndex(0);
    ver8.setSelectedIndex(0);
    }
    void mInsertar(){
       String sql="SELECT * FROM `estado`";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                insertar.addItem(rs.getString("estado"));
                insertar1.addItem(rs.getString("estado"));
                insertar2.addItem(rs.getString("estado"));
                insertar3.addItem(rs.getString("estado"));
                insertar4.addItem(rs.getString("estado"));
                insertar5.addItem(rs.getString("estado"));
                insertar6.addItem(rs.getString("estado"));
                insertar7.addItem(rs.getString("estado"));
                insertar8.addItem(rs.getString("estado"));
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Proveedores.class.getName()).log(Level.SEVERE, null, ex);
        }
       
   }
    void mModificar(){
       String sql="SELECT * FROM `estado`";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                modificar.addItem(rs.getString("estado"));
                modificar1.addItem(rs.getString("estado"));
                modificar2.addItem(rs.getString("estado"));
                modificar3.addItem(rs.getString("estado"));
                modificar4.addItem(rs.getString("estado"));
                modificar5.addItem(rs.getString("estado"));
                modificar6.addItem(rs.getString("estado"));
                modificar7.addItem(rs.getString("estado"));
                modificar8.addItem(rs.getString("estado"));
               
            }
        } catch (SQLException ex) {
            Logger.getLogger(Proveedores.class.getName()).log(Level.SEVERE, null, ex);
        }
       
   }
    void mVer(){
       String sql="SELECT * FROM `estado`";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                ver.addItem(rs.getString("estado"));
                ver1.addItem(rs.getString("estado"));
                ver2.addItem(rs.getString("estado"));
                ver3.addItem(rs.getString("estado"));
                ver4.addItem(rs.getString("estado"));
                ver5.addItem(rs.getString("estado"));
                ver6.addItem(rs.getString("estado"));
                ver7.addItem(rs.getString("estado"));
                ver8.addItem(rs.getString("estado"));
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Proveedores.class.getName()).log(Level.SEVERE, null, ex);
        }
       
   }
    
    void mUsuario(){
       String sql="SELECT * FROM `usuarios` WHERE `id_usuario` != '1' ";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                user.addItem(rs.getString("nombre"));
                user1.addItem(rs.getString("nombre"));
                user2.addItem(rs.getString("nombre"));
                user3.addItem(rs.getString("nombre"));
                user4.addItem(rs.getString("nombre"));
                user5.addItem(rs.getString("nombre"));
                user6.addItem(rs.getString("nombre"));
                user7.addItem(rs.getString("nombre"));
                user8.addItem(rs.getString("nombre"));
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Proveedores.class.getName()).log(Level.SEVERE, null, ex);
        }
       
   }
    
    
    void bo(String dato){
   String cap1="";
        String sql="SELECT * FROM `usuariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo2(String dato){
   String cap1="";
        String sql="SELECT * FROM `proveedorrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.proveedores.setVisible(true);
            
            }
            else{
                panelcentral.proveedores.setVisible(false);
                panelcentral.jLabel2.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo3(String dato){
   String cap1="";
        String sql="SELECT * FROM `categoriarol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.categorias.setVisible(true);
            
            }
            else{
                panelcentral.categorias.setVisible(false);
                panelcentral.jLabel6.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo4(String dato){
   String cap1="";
        String sql="SELECT * FROM `bombasrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.bombas.setVisible(true);
            
            }
            else{
                panelcentral.jLabel5.setVisible(false);
                panelcentral.bombas.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo5(String dato){
   String cap1="";
        String sql="SELECT * FROM `productorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.productos.setVisible(true);
            
            }
            else{
                panelcentral.productos.setVisible(false);
                panelcentral.jLabel9.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo6(String dato){
   String cap1="";
        String sql="SELECT * FROM `seriedigitalrol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario6.setVisible(true);
            
            }
            else{
                panelcentral.jLabel8.setVisible(false);
                panelcentral.usuario6.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo7(String dato){
   String cap1="";
        String sql="SELECT * FROM `inventariorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.usuario4.setVisible(true);
            
            }
            else{
                panelcentral.jLabel1.setVisible(false);
                panelcentral.control.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }
   void bo8(String dato){
   String cap1="";
        String sql="SELECT * FROM `preciorol` WHERE `nombre` = '"+dato+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap1=rs.getString("ver"); 
            }
            if(cap1.equals("Activo"))
            {
                  
              panelcentral.control.setVisible(true);
            
            }
            else{
                panelcentral.usuario4.setVisible(false);
                panelcentral.jLabel10.setVisible(false);
 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
            logger.debug("Error: "+ex);
            
        }  
   }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ver3 = new javax.swing.JComboBox<>();
        user3 = new javax.swing.JComboBox<>();
        bomba3 = new javax.swing.JButton();
        insertar3 = new javax.swing.JComboBox<>();
        modificar3 = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        insertar = new javax.swing.JComboBox<>();
        modificar = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        ver = new javax.swing.JComboBox<>();
        user = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        bomba1 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel14 = new javax.swing.JLabel();
        insertar1 = new javax.swing.JComboBox<>();
        modificar1 = new javax.swing.JComboBox<>();
        ver1 = new javax.swing.JComboBox<>();
        user1 = new javax.swing.JComboBox<>();
        bomba2 = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        insertar2 = new javax.swing.JComboBox<>();
        modificar2 = new javax.swing.JComboBox<>();
        ver2 = new javax.swing.JComboBox<>();
        user2 = new javax.swing.JComboBox<>();
        bomba4 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        insertar4 = new javax.swing.JComboBox<>();
        modificar4 = new javax.swing.JComboBox<>();
        ver4 = new javax.swing.JComboBox<>();
        user4 = new javax.swing.JComboBox<>();
        bomba5 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        insertar5 = new javax.swing.JComboBox<>();
        modificar5 = new javax.swing.JComboBox<>();
        ver5 = new javax.swing.JComboBox<>();
        user5 = new javax.swing.JComboBox<>();
        bomba6 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        insertar6 = new javax.swing.JComboBox<>();
        modificar6 = new javax.swing.JComboBox<>();
        ver6 = new javax.swing.JComboBox<>();
        user6 = new javax.swing.JComboBox<>();
        bomba7 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        insertar7 = new javax.swing.JComboBox<>();
        modificar7 = new javax.swing.JComboBox<>();
        ver7 = new javax.swing.JComboBox<>();
        user7 = new javax.swing.JComboBox<>();
        bomba8 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jSeparator7 = new javax.swing.JSeparator();
        insertar8 = new javax.swing.JComboBox<>();
        modificar8 = new javax.swing.JComboBox<>();
        ver8 = new javax.swing.JComboBox<>();
        user8 = new javax.swing.JComboBox<>();
        bomba9 = new javax.swing.JButton();
        annu2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        usePermiso = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        annu3 = new javax.swing.JLabel();
        annu4 = new javax.swing.JLabel();
        annu5 = new javax.swing.JLabel();
        annu6 = new javax.swing.JLabel();
        annu7 = new javax.swing.JLabel();
        annu8 = new javax.swing.JLabel();
        annu9 = new javax.swing.JLabel();
        annu10 = new javax.swing.JLabel();
        annu11 = new javax.swing.JLabel();
        annu12 = new javax.swing.JLabel();
        annu13 = new javax.swing.JLabel();
        annu14 = new javax.swing.JLabel();
        annu15 = new javax.swing.JLabel();
        annu16 = new javax.swing.JLabel();
        annu17 = new javax.swing.JLabel();
        annu18 = new javax.swing.JLabel();
        annu19 = new javax.swing.JLabel();
        annu20 = new javax.swing.JLabel();
        annu21 = new javax.swing.JLabel();
        annu22 = new javax.swing.JLabel();
        annu23 = new javax.swing.JLabel();
        annu24 = new javax.swing.JLabel();
        annu25 = new javax.swing.JLabel();
        annu26 = new javax.swing.JLabel();
        annu27 = new javax.swing.JLabel();
        annu28 = new javax.swing.JLabel();
        annu29 = new javax.swing.JLabel();
        annu30 = new javax.swing.JLabel();
        annu31 = new javax.swing.JLabel();
        annu32 = new javax.swing.JLabel();
        annu33 = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        ver3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de ver" }));
        ver3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ver3ActionPerformed(evt);
            }
        });

        user3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona Usuario" }));

        bomba3.setText("Actualizar");
        bomba3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bomba3ActionPerformed(evt);
            }
        });

        insertar3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de insertar" }));

        modificar3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de modificar" }));

        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel4.setText("Proveedores:");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        insertar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de insertar" }));
        getContentPane().add(insertar, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 110, 115, -1));

        modificar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de modificar" }));
        getContentPane().add(modificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 110, 123, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel1.setText("Permiso para entrar  a la pantalla");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 70, 200, -1));

        ver.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de ver" }));
        ver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verActionPerformed(evt);
            }
        });
        getContentPane().add(ver, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 110, 123, -1));

        user.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona Usuario" }));
        user.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                userMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                userMousePressed(evt);
            }
        });
        user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userActionPerformed(evt);
            }
        });
        user.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                userKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                userKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                userKeyTyped(evt);
            }
        });
        getContentPane().add(user, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 110, 121, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(51, 153, 255));
        jLabel17.setText("Permisos para usuarios");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 0, -1, -1));

        bomba1.setText("Actualizar");
        bomba1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bomba1ActionPerformed(evt);
            }
        });
        getContentPane().add(bomba1, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 110, 123, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel11.setText("Ingreso de usuarios:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, 150, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel12.setText("Nombre de Usuario");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 70, 120, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel13.setText("Permiso para insertar");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 70, 120, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, 1050, 20));

        jLabel14.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel14.setText("Permiso para modificar");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 70, 130, -1));

        insertar1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de insertar" }));
        getContentPane().add(insertar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 170, 115, -1));

        modificar1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de modificar" }));
        getContentPane().add(modificar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 170, 123, -1));

        ver1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de ver" }));
        ver1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ver1ActionPerformed(evt);
            }
        });
        getContentPane().add(ver1, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 170, 123, -1));

        user1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona Usuario" }));
        getContentPane().add(user1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 170, 121, -1));

        bomba2.setText("Actualizar");
        bomba2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bomba2ActionPerformed(evt);
            }
        });
        getContentPane().add(bomba2, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 170, 123, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel15.setText("Ingreso de proveedores:");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, 190, -1));
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 1050, 20));

        insertar2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de insertar" }));
        getContentPane().add(insertar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 230, 115, -1));

        modificar2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de modificar" }));
        getContentPane().add(modificar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 230, 123, -1));

        ver2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de ver" }));
        ver2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ver2ActionPerformed(evt);
            }
        });
        getContentPane().add(ver2, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 230, 123, -1));

        user2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona Usuario" }));
        getContentPane().add(user2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 230, 121, -1));

        bomba4.setText("Actualizar");
        bomba4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bomba4ActionPerformed(evt);
            }
        });
        getContentPane().add(bomba4, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 230, 123, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel16.setText("Ingreso de categorias:");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 150, -1));
        getContentPane().add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 1050, 20));

        insertar4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de insertar" }));
        getContentPane().add(insertar4, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 290, 115, -1));

        modificar4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de modificar" }));
        getContentPane().add(modificar4, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 290, 123, -1));

        ver4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de ver" }));
        ver4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ver4ActionPerformed(evt);
            }
        });
        getContentPane().add(ver4, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 290, 123, -1));

        user4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona Usuario" }));
        getContentPane().add(user4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 290, 121, -1));

        bomba5.setText("Actualizar");
        bomba5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bomba5ActionPerformed(evt);
            }
        });
        getContentPane().add(bomba5, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 290, 123, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel18.setText("Ingreso de bombas:");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, 150, -1));
        getContentPane().add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 1050, 20));

        insertar5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de insertar" }));
        getContentPane().add(insertar5, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 350, 111, -1));

        modificar5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de modificar" }));
        getContentPane().add(modificar5, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 350, 123, -1));

        ver5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de ver" }));
        ver5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ver5ActionPerformed(evt);
            }
        });
        getContentPane().add(ver5, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 350, 123, -1));

        user5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona Usuario" }));
        getContentPane().add(user5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 350, 121, -1));

        bomba6.setText("Actualizar");
        bomba6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bomba6ActionPerformed(evt);
            }
        });
        getContentPane().add(bomba6, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 350, 123, -1));

        jLabel19.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel19.setText("Ingreso de productos:");
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 350, 190, -1));
        getContentPane().add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 1050, 20));

        insertar6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de insertar" }));
        getContentPane().add(insertar6, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 410, 111, -1));

        modificar6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de modificar" }));
        getContentPane().add(modificar6, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 410, 123, -1));

        ver6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de ver" }));
        ver6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ver6ActionPerformed(evt);
            }
        });
        getContentPane().add(ver6, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 410, 123, -1));

        user6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona Usuario" }));
        getContentPane().add(user6, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 410, 121, -1));

        bomba7.setText("Actualizar");
        bomba7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bomba7ActionPerformed(evt);
            }
        });
        getContentPane().add(bomba7, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 410, 123, -1));

        jLabel20.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel20.setText("Serie mecanica y digital:");
        getContentPane().add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 410, 190, -1));
        jLabel20.getAccessibleContext().setAccessibleName("Ingreso de totalidad:");

        getContentPane().add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 450, 1050, 20));

        insertar7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de insertar" }));
        getContentPane().add(insertar7, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 470, 111, -1));

        modificar7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de modificar" }));
        getContentPane().add(modificar7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 470, 123, -1));

        ver7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de ver" }));
        ver7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ver7ActionPerformed(evt);
            }
        });
        getContentPane().add(ver7, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 470, 123, -1));

        user7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona Usuario" }));
        getContentPane().add(user7, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 470, 121, -1));

        bomba8.setText("Actualizar");
        bomba8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bomba8ActionPerformed(evt);
            }
        });
        getContentPane().add(bomba8, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 470, 123, -1));

        jLabel21.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel21.setText("Precio actual de gasolina:");
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 470, 160, -1));
        getContentPane().add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 510, 1050, 20));

        insertar8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de insertar" }));
        getContentPane().add(insertar8, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 530, 111, -1));

        modificar8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de modificar" }));
        getContentPane().add(modificar8, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 530, 123, -1));

        ver8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado de ver" }));
        ver8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ver8ActionPerformed(evt);
            }
        });
        getContentPane().add(ver8, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 530, 123, -1));

        user8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona Usuario" }));
        getContentPane().add(user8, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 530, 121, -1));

        bomba9.setText("Actualizar");
        bomba9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bomba9ActionPerformed(evt);
            }
        });
        getContentPane().add(bomba9, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 530, 123, -1));

        annu2.setForeground(new java.awt.Color(255, 0, 51));
        annu2.setText("...");
        getContentPane().add(annu2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 130, 120, 20));

        jButton2.setText("Atrás");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 570, 111, 20));

        jLabel22.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel22.setText("Control diario de combustible:");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 530, 200, -1));

        usePermiso.setText("....");
        getContentPane().add(usePermiso, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, 90, -1));

        jLabel2.setText("Usuario:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 50, -1, -1));

        jLabel3.setText("Fecha:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 40, -1));

        annu3.setForeground(new java.awt.Color(255, 0, 51));
        annu3.setText("...");
        getContentPane().add(annu3, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 130, 120, 20));

        annu4.setForeground(new java.awt.Color(255, 0, 51));
        annu4.setText("...");
        getContentPane().add(annu4, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 130, 120, 20));

        annu5.setForeground(new java.awt.Color(255, 0, 51));
        annu5.setText("...");
        getContentPane().add(annu5, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 130, 120, 20));

        annu6.setForeground(new java.awt.Color(255, 0, 51));
        annu6.setText("...");
        getContentPane().add(annu6, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 190, 120, 20));

        annu7.setForeground(new java.awt.Color(255, 0, 51));
        annu7.setText("...");
        getContentPane().add(annu7, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 190, 120, 20));

        annu8.setForeground(new java.awt.Color(255, 0, 51));
        annu8.setText("...");
        getContentPane().add(annu8, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 190, 120, 20));

        annu9.setForeground(new java.awt.Color(255, 0, 51));
        annu9.setText("...");
        getContentPane().add(annu9, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 190, 120, 20));

        annu10.setForeground(new java.awt.Color(255, 0, 51));
        annu10.setText("...");
        getContentPane().add(annu10, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 250, 120, 20));

        annu11.setForeground(new java.awt.Color(255, 0, 51));
        annu11.setText("...");
        getContentPane().add(annu11, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 250, 120, 20));

        annu12.setForeground(new java.awt.Color(255, 0, 51));
        annu12.setText("...");
        getContentPane().add(annu12, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 250, 120, 20));

        annu13.setForeground(new java.awt.Color(255, 0, 51));
        annu13.setText("...");
        getContentPane().add(annu13, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 250, 120, 20));

        annu14.setForeground(new java.awt.Color(255, 0, 51));
        annu14.setText("...");
        getContentPane().add(annu14, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 310, 120, 20));

        annu15.setForeground(new java.awt.Color(255, 0, 51));
        annu15.setText("...");
        getContentPane().add(annu15, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 310, 120, 20));

        annu16.setForeground(new java.awt.Color(255, 0, 51));
        annu16.setText("...");
        getContentPane().add(annu16, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 310, 120, 20));

        annu17.setForeground(new java.awt.Color(255, 0, 51));
        annu17.setText("...");
        getContentPane().add(annu17, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 310, 120, 20));

        annu18.setForeground(new java.awt.Color(255, 0, 51));
        annu18.setText("...");
        getContentPane().add(annu18, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 370, 120, 20));

        annu19.setForeground(new java.awt.Color(255, 0, 51));
        annu19.setText("...");
        getContentPane().add(annu19, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 370, 120, 20));

        annu20.setForeground(new java.awt.Color(255, 0, 51));
        annu20.setText("...");
        getContentPane().add(annu20, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 370, 120, 20));

        annu21.setForeground(new java.awt.Color(255, 0, 51));
        annu21.setText("...");
        getContentPane().add(annu21, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 370, 120, 20));

        annu22.setForeground(new java.awt.Color(255, 0, 51));
        annu22.setText("...");
        getContentPane().add(annu22, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 430, 120, 20));

        annu23.setForeground(new java.awt.Color(255, 0, 51));
        annu23.setText("...");
        getContentPane().add(annu23, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 430, 120, 20));

        annu24.setForeground(new java.awt.Color(255, 0, 51));
        annu24.setText("...");
        getContentPane().add(annu24, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 430, 120, 20));

        annu25.setForeground(new java.awt.Color(255, 0, 51));
        annu25.setText("...");
        getContentPane().add(annu25, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 430, 120, 20));

        annu26.setForeground(new java.awt.Color(255, 0, 51));
        annu26.setText("...");
        getContentPane().add(annu26, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 490, 120, 20));

        annu27.setForeground(new java.awt.Color(255, 0, 51));
        annu27.setText("...");
        getContentPane().add(annu27, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 490, 120, 20));

        annu28.setForeground(new java.awt.Color(255, 0, 51));
        annu28.setText("...");
        getContentPane().add(annu28, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 490, 120, 20));

        annu29.setForeground(new java.awt.Color(255, 0, 51));
        annu29.setText("...");
        getContentPane().add(annu29, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 490, 120, 20));

        annu30.setForeground(new java.awt.Color(255, 0, 51));
        annu30.setText("...");
        getContentPane().add(annu30, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 550, 120, 20));

        annu31.setForeground(new java.awt.Color(255, 0, 51));
        annu31.setText("...");
        getContentPane().add(annu31, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 550, 120, 20));

        annu32.setForeground(new java.awt.Color(255, 0, 51));
        annu32.setText("...");
        getContentPane().add(annu32, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 550, 120, 20));

        annu33.setForeground(new java.awt.Color(255, 0, 51));
        annu33.setText("...");
        getContentPane().add(annu33, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 550, 120, 20));

        fondo.setBackground(new java.awt.Color(255, 102, 51));
        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/fondo5.jpg"))); // NOI18N
        fondo.setText("jLabel4");
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 610));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void verActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_verActionPerformed

    private void bomba1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bomba1ActionPerformed
        // TODO add your handling code here:
        try {
            
            
            String con ="UPDATE `usuariorol` SET `insertar` = ?, `modificar` = ?, `ver` = ? WHERE `usuariorol`.`nombre` = '"+user.getSelectedItem()+"';";
            
            PreparedStatement pst  = cn.prepareStatement(con);
            
            if (user.getSelectedItem()==user.getItemAt(0)) {
                annu2.setText("Escoge uno!!");
                annu5.setText("");
                annu3.setText("");
                annu4.setText("");

            }
            else if (insertar.getSelectedItem()==insertar.getItemAt(0)) {
              annu3.setText("Escoge uno!!");
              annu2.setText("");
              annu5.setText(""); 
              annu4.setText("");
            }else if (modificar.getSelectedItem()==modificar.getItemAt(0)) {
              annu4.setText("Escoge uno!!");
              annu5.setText("");
              annu2.setText("");
              annu3.setText("");
            }
            else if (ver.getSelectedItem()==ver.getItemAt(0)) {
              annu5.setText("Escoge uno!!");
              annu2.setText("");
              annu3.setText("");
              annu4.setText("");
              
            }
            else{
            pst.setString(1, insertar.getSelectedItem().toString());  
            
            pst.setString(2, modificar.getSelectedItem().toString());
            
            pst.setString(3, ver.getSelectedItem().toString());
                annu2.setText("");
                annu5.setText("");
                annu3.setText("");
                annu4.setText("");
                limpiar();
            
            }
            
           
            
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro Guardado con Exito");
            
        
        } catch (SQLException ex) {
            logger.debug(ex);
            logger.info(ex);
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista esa categoria que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bomba1ActionPerformed

    private void ver3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ver3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ver3ActionPerformed

    private void bomba3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bomba3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bomba3ActionPerformed

    private void ver1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ver1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ver1ActionPerformed

    private void bomba2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bomba2ActionPerformed
        
        try {
              
            String con ="UPDATE `proveedorrol` SET `insertar` = ?, `modificar` = ?, `ver` = ? WHERE `proveedorrol`.`nombre` = '"+user1.getSelectedItem()+"';";
            
            PreparedStatement pst  = cn.prepareStatement(con);
            
            if (user1.getSelectedItem()==user1.getItemAt(0)) {
                annu6.setText("Escoge uno!!");
                annu7.setText("");
                annu8.setText("");
                annu9.setText("");

            }
            else if (insertar1.getSelectedItem()==insertar1.getItemAt(0)) {
              annu7.setText("Escoge uno!!");
              annu6.setText("");
              annu8.setText(""); 
              annu9.setText("");
            }else if (modificar1.getSelectedItem()==modificar1.getItemAt(0)) {
              annu8.setText("Escoge uno!!");
              annu6.setText("");
              annu7.setText("");
              annu9.setText("");
            }
            else if (ver1.getSelectedItem()==ver1.getItemAt(0)) {
              annu9.setText("Escoge uno!!");
              annu6.setText("");
              annu7.setText("");
              annu8.setText("");
              
            }
            else{
            pst.setString(1, insertar1.getSelectedItem().toString());  
            
            pst.setString(2, modificar1.getSelectedItem().toString());
            
            pst.setString(3, ver1.getSelectedItem().toString());
              annu9.setText("");
              annu6.setText("");
              annu7.setText("");
              annu8.setText("");
              limpiar();
            
            }
            
            
           
            
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro Guardado con Exito");
            
            logger.info("Actualizo datos del usuario: "+user.getSelectedItem());
        
        } catch (SQLException ex) {
            logger.fatal("Error : "+ex);
            
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista esa categoria que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bomba2ActionPerformed

    private void ver2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ver2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ver2ActionPerformed

    private void bomba4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bomba4ActionPerformed
        // TODO add your handling code here:
        try {
            
            String con ="UPDATE `categoriarol` SET `insertar` = ?, `modificar` = ?, `ver` = ? WHERE `categoriarol`.`nombre` = '"+user2.getSelectedItem()+"';";
            
            PreparedStatement pst  = cn.prepareStatement(con);
            
           if (user2.getSelectedItem()==user2.getItemAt(0)) {
                annu10.setText("Escoge uno!!");
                annu11.setText("");
                annu12.setText("");
                annu13.setText("");

            }
            else if (insertar2.getSelectedItem()==insertar2.getItemAt(0)) {
              annu11.setText("Escoge uno!!");
              annu12.setText("");
              annu10.setText(""); 
              annu13.setText("");
            }else if (modificar2.getSelectedItem()==modificar2.getItemAt(0)) {
              annu12.setText("Escoge uno!!");
              annu10.setText("");
              annu11.setText("");
              annu13.setText("");
            }
            else if (ver2.getSelectedItem()==ver2.getItemAt(0)) {
              annu13.setText("Escoge uno!!");
              annu10.setText("");
              annu11.setText("");
              annu12.setText("");
              
            }
            else{
            pst.setString(1, insertar2.getSelectedItem().toString());  
            
            pst.setString(2, modificar2.getSelectedItem().toString());
            
            pst.setString(3, ver2.getSelectedItem().toString());
              annu10.setText("");
              annu11.setText("");
              annu12.setText("");
              annu13.setText("");
              limpiar();
            
            }
           
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro actualizado con Exito");
            
            logger.info("Actualizo datos del usuario: "+user.getSelectedItem());
        
        } catch (SQLException ex) {
            logger.fatal("Error : "+ex);
            
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista esa categoria que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bomba4ActionPerformed

    private void ver4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ver4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ver4ActionPerformed

    private void bomba5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bomba5ActionPerformed
        // TODO add your handling code here:
        try {
            
            String con ="UPDATE `bombasrol` SET `insertar` = ?, `modificar` = ?, `ver` = ? WHERE `bombasrol`.`nombre` = '"+user4.getSelectedItem()+"';";
            
            PreparedStatement pst  = cn.prepareStatement(con);
            
            if (user4.getSelectedItem()==user4.getItemAt(0)) {
                annu14.setText("Escoge uno!!");
                annu15.setText("");
                annu16.setText("");
                annu17.setText("");

            }
            else if (insertar4.getSelectedItem()==insertar4.getItemAt(0)) {
                annu14.setText("");
                annu15.setText("Escoge uno!!");
                annu16.setText("");
                annu17.setText("");
            }else if (modificar4.getSelectedItem()==modificar4.getItemAt(0)) {
                annu14.setText("");
                annu15.setText("");
                annu16.setText("Escoge uno!!");
                annu17.setText("");
            }
            else if (ver4.getSelectedItem()==ver4.getItemAt(0)) {
                annu14.setText("");
                annu15.setText("");
                annu16.setText("");
                annu17.setText("Escoge uno!!");
              
            }
            else{
            pst.setString(1, insertar4.getSelectedItem().toString());  
            
            pst.setString(2, modificar4.getSelectedItem().toString());
            
            pst.setString(3, ver4.getSelectedItem().toString());
                annu14.setText("");
                annu15.setText("");
                annu16.setText("");
                annu17.setText("");;
              limpiar();
            
            }
           
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro actualizado con Exito");
            
            logger.info("Actualizo datos del usuario: "+user.getSelectedItem());
        
        } catch (SQLException ex) {
            logger.fatal("Error : "+ex);
            
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista esa categoria que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bomba5ActionPerformed

    private void ver5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ver5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ver5ActionPerformed

    private void bomba6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bomba6ActionPerformed
        // TODO add your handling code here:
        try {
            
            String con ="UPDATE `productorol` SET `insertar` = ?, `modificar` = ?, `ver` = ? WHERE `productorol`.`nombre` = '"+user5.getSelectedItem()+"';";
            
            PreparedStatement pst  = cn.prepareStatement(con);
            
            if (user5.getSelectedItem()==user5.getItemAt(0)) {
                annu18.setText("Escoge uno!!");
                annu19.setText("");
                annu20.setText("");
                annu21.setText("");

            }
            else if (insertar5.getSelectedItem()==insertar5.getItemAt(0)) {
                annu18.setText("");
                annu19.setText("Escoge uno!!");
                annu20.setText("");
                annu21.setText("");
            }else if (modificar5.getSelectedItem()==modificar5.getItemAt(0)) {
                annu18.setText("");
                annu19.setText("");
                annu20.setText("Escoge uno!!");
                annu21.setText("");
            }
            else if (ver5.getSelectedItem()==ver5.getItemAt(0)) {
                annu18.setText("");
                annu19.setText("");
                annu20.setText("");
                annu21.setText("Escoge uno!!");
              
            }
            else{
            pst.setString(1, insertar5.getSelectedItem().toString());  
            
            pst.setString(2, modificar5.getSelectedItem().toString());
            
            pst.setString(3, ver5.getSelectedItem().toString());
                annu18.setText("");
                annu19.setText("");
                annu20.setText("");
                annu21.setText("");
              limpiar();
            
            }
           
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro actualizado con Exito");
            
            logger.info("Actualizo datos del usuario: "+user5.getSelectedItem());
        
        } catch (SQLException ex) {
            logger.fatal("Error : "+ex);
            
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista esa categoria que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bomba6ActionPerformed

    private void ver6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ver6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ver6ActionPerformed

    private void bomba7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bomba7ActionPerformed
        // TODO add your handling code here:
        try {
            
            String con ="UPDATE `seriedigitalrol` SET `insertar` = ?, `modificar` = ?, `ver` = ? WHERE `seriedigitalrol`.`nombre` = '"+user6.getSelectedItem()+"';";
            
            PreparedStatement pst  = cn.prepareStatement(con);
            
            if (user6.getSelectedItem()==user6.getItemAt(0)) {
                annu22.setText("Escoge uno!!");
                annu23.setText("");
                annu24.setText("");
                annu25.setText("");

            }
            else if (insertar6.getSelectedItem()==insertar6.getItemAt(0)) {
                annu22.setText("");
                annu23.setText("Escoge uno!!");
                annu24.setText("");
                annu25.setText("");
            }else if (modificar6.getSelectedItem()==modificar6.getItemAt(0)) {
                annu22.setText("");
                annu23.setText("");
                annu24.setText("Escoge uno!!");
                annu25.setText("");
            }
            else if (ver6.getSelectedItem()==ver6.getItemAt(0)) {
                annu22.setText("");
                annu23.setText("");
                annu24.setText("");
                annu25.setText("Escoge uno!!");
              
            }
            else{
            pst.setString(1, insertar6.getSelectedItem().toString());  
            
            pst.setString(2, modificar6.getSelectedItem().toString());
            
            pst.setString(3, ver6.getSelectedItem().toString());
                annu22.setText("");
                annu23.setText("");
                annu24.setText("");
                annu25.setText("");
              limpiar();
            
            }
           
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro actualizado con Exito");
            
            logger.info("Actualizo datos del usuario: "+user6.getSelectedItem());
        
        } catch (SQLException ex) {
            logger.fatal("Error : "+ex);
            
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista esa categoria que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bomba7ActionPerformed

    private void ver7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ver7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ver7ActionPerformed

    private void bomba8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bomba8ActionPerformed
        // TODO add your handling code here:
        try {
            
            String con ="UPDATE `preciorol` SET `insertar` = ?, `modificar` = ?, `ver` = ? WHERE `preciorol`.`nombre` = '"+user7.getSelectedItem()+"';";
            
            PreparedStatement pst  = cn.prepareStatement(con);
            
            if (user7.getSelectedItem()==user7.getItemAt(0)) {
                annu26.setText("Escoge uno!!");
                annu27.setText("");
                annu28.setText("");
                annu29.setText("");

            }
            else if (insertar7.getSelectedItem()==insertar7.getItemAt(0)) {
                annu26.setText(" ");
                annu27.setText("Escoge uno!!");
                annu28.setText("");
                annu29.setText("");
            }else if (modificar7.getSelectedItem()==modificar7.getItemAt(0)) {
                annu26.setText(" ");
                annu27.setText("");
                annu28.setText("Escoge uno!!");
                annu29.setText("");
            }
            else if (ver7.getSelectedItem()==ver7.getItemAt(0)) {
                annu26.setText("");
                annu27.setText("");
                annu28.setText("");
                annu29.setText("Escoge uno!!");
              
            }
            else{
            pst.setString(1, insertar7.getSelectedItem().toString());  
            
            pst.setString(2, modificar7.getSelectedItem().toString());
            
            pst.setString(3, ver7.getSelectedItem().toString());
                annu26.setText("");
                annu27.setText("");
                annu28.setText("");
                annu29.setText("");
              limpiar();
            
            }
           
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro actualizado con Exito");
            
            logger.info("Actualizo datos del usuario: "+user7.getSelectedItem());
        
        } catch (SQLException ex) {
            logger.fatal("Error : "+ex);
            
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista esa categoria que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_bomba8ActionPerformed

    private void ver8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ver8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ver8ActionPerformed

    private void bomba9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bomba9ActionPerformed
        // TODO add your handling code here:
         try {
            
            String con ="UPDATE `inventariorol` SET `insertar` = ?, `modificar` = ?, `ver` = ? WHERE `inventariorol`.`nombre` = '"+user8.getSelectedItem()+"';";
            
            PreparedStatement pst  = cn.prepareStatement(con);
            
            if (user8.getSelectedItem()==user8.getItemAt(0)) {
                annu30.setText("Escoge uno!!");
                annu31.setText("");
                annu32.setText("");
                annu33.setText("");

            }
            else if (insertar8.getSelectedItem()==insertar8.getItemAt(0)) {
                annu30.setText(" ");
                annu31.setText("Escoge uno!!");
                annu32.setText("");
                annu33.setText("");
            }else if (modificar8.getSelectedItem()==modificar8.getItemAt(0)) {
                annu30.setText(" ");
                annu31.setText("");
                annu32.setText("Escoge uno!!");
                annu33.setText("");
            }
            else if (ver8.getSelectedItem()==ver8.getItemAt(0)) {
                annu30.setText(" ");
                annu31.setText("");
                annu32.setText("");
                annu33.setText("Escoge uno!!");
              
            }
            else{
            pst.setString(1, insertar8.getSelectedItem().toString());  
            
            pst.setString(2, modificar8.getSelectedItem().toString());
            
            pst.setString(3, ver8.getSelectedItem().toString());
                annu30.setText(" ");
                annu31.setText("");
                annu32.setText("");
                annu33.setText("");
              limpiar();
            
            }
           
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro actualizado con Exito");
            
            logger.info("Actualizo datos del usuario: "+user8.getSelectedItem());
        
        } catch (SQLException ex) {
            logger.fatal("Error : "+ex);
            
            JOptionPane.showMessageDialog(rootPane, "Revise que no exista esa categoria que esta ingresando!!","ERROR: Revise que los datos esten correctos",JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_bomba9ActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked

        panelcentral botonatras = new panelcentral();
        botonatras.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        panelcentral ingresar = new panelcentral();
        ingresar.setVisible(true);
        panelcentral.User.setText(usePermiso.getText());
        this.dispose();
        
                     bo(usePermiso.getText());
                     bo2(usePermiso.getText());
                     bo3(usePermiso.getText());
                     bo4(usePermiso.getText());
                     bo5(usePermiso.getText());
                     bo6(usePermiso.getText());
                     bo7(usePermiso.getText());
                     bo8(usePermiso.getText());
        
        

    }//GEN-LAST:event_jButton2ActionPerformed

    private void userMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userMouseClicked
        // TODO add your handling code here:
        
      
       
   
        
    }//GEN-LAST:event_userMouseClicked

    private void userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_userActionPerformed

    private void userKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_userKeyReleased
        // TODO add your handling code here:
        
    }//GEN-LAST:event_userKeyReleased

    private void userKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_userKeyPressed
        // TODO add your handling code here:
     
    }//GEN-LAST:event_userKeyPressed

    private void userKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_userKeyTyped
        // TODO add your handling code here:
        
    }//GEN-LAST:event_userKeyTyped

    private void userMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userMousePressed
        // TODO add your handling code here:
       
   
    }//GEN-LAST:event_userMousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(permisos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(permisos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(permisos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(permisos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new permisos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel annu10;
    private javax.swing.JLabel annu11;
    private javax.swing.JLabel annu12;
    private javax.swing.JLabel annu13;
    private javax.swing.JLabel annu14;
    private javax.swing.JLabel annu15;
    private javax.swing.JLabel annu16;
    private javax.swing.JLabel annu17;
    private javax.swing.JLabel annu18;
    private javax.swing.JLabel annu19;
    private javax.swing.JLabel annu2;
    private javax.swing.JLabel annu20;
    private javax.swing.JLabel annu21;
    private javax.swing.JLabel annu22;
    private javax.swing.JLabel annu23;
    private javax.swing.JLabel annu24;
    private javax.swing.JLabel annu25;
    private javax.swing.JLabel annu26;
    private javax.swing.JLabel annu27;
    private javax.swing.JLabel annu28;
    private javax.swing.JLabel annu29;
    private javax.swing.JLabel annu3;
    private javax.swing.JLabel annu30;
    private javax.swing.JLabel annu31;
    private javax.swing.JLabel annu32;
    private javax.swing.JLabel annu33;
    private javax.swing.JLabel annu4;
    private javax.swing.JLabel annu5;
    private javax.swing.JLabel annu6;
    private javax.swing.JLabel annu7;
    private javax.swing.JLabel annu8;
    private javax.swing.JLabel annu9;
    private javax.swing.JButton bomba1;
    private javax.swing.JButton bomba2;
    private javax.swing.JButton bomba3;
    private javax.swing.JButton bomba4;
    private javax.swing.JButton bomba5;
    private javax.swing.JButton bomba6;
    private javax.swing.JButton bomba7;
    private javax.swing.JButton bomba8;
    private javax.swing.JButton bomba9;
    private javax.swing.JLabel fondo;
    private javax.swing.JComboBox<String> insertar;
    private javax.swing.JComboBox<String> insertar1;
    private javax.swing.JComboBox<String> insertar2;
    private javax.swing.JComboBox<String> insertar3;
    private javax.swing.JComboBox<String> insertar4;
    private javax.swing.JComboBox<String> insertar5;
    private javax.swing.JComboBox<String> insertar6;
    private javax.swing.JComboBox<String> insertar7;
    private javax.swing.JComboBox<String> insertar8;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JComboBox<String> modificar;
    private javax.swing.JComboBox<String> modificar1;
    private javax.swing.JComboBox<String> modificar2;
    private javax.swing.JComboBox<String> modificar3;
    private javax.swing.JComboBox<String> modificar4;
    private javax.swing.JComboBox<String> modificar5;
    private javax.swing.JComboBox<String> modificar6;
    private javax.swing.JComboBox<String> modificar7;
    private javax.swing.JComboBox<String> modificar8;
    public static javax.swing.JLabel usePermiso;
    private javax.swing.JComboBox<String> user;
    private javax.swing.JComboBox<String> user1;
    private javax.swing.JComboBox<String> user2;
    private javax.swing.JComboBox<String> user3;
    private javax.swing.JComboBox<String> user4;
    private javax.swing.JComboBox<String> user5;
    private javax.swing.JComboBox<String> user6;
    private javax.swing.JComboBox<String> user7;
    private javax.swing.JComboBox<String> user8;
    private javax.swing.JComboBox<String> ver;
    private javax.swing.JComboBox<String> ver1;
    private javax.swing.JComboBox<String> ver2;
    private javax.swing.JComboBox<String> ver3;
    private javax.swing.JComboBox<String> ver4;
    private javax.swing.JComboBox<String> ver5;
    private javax.swing.JComboBox<String> ver6;
    private javax.swing.JComboBox<String> ver7;
    private javax.swing.JComboBox<String> ver8;
    // End of variables declaration//GEN-END:variables
}
