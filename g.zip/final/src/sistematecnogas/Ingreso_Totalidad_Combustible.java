/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistematecnogas;

import Atxy2k.CustomTextField.RestrictedTextField;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import servicios.conexion;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import static sistematecnogas.panelcentral.fecha;

/**
 *
 * @author Wilfredo Serrano
 */
public class Ingreso_Totalidad_Combustible extends javax.swing.JFrame {

    /**
     * Creates new form Ingreso_Totalidad_Combustible
     */
    conexion cc = new conexion();
    Connection cn = conexion.conexion();
    public Ingreso_Totalidad_Combustible() {
        initComponents();
        cargar("");
        cargar1();
        setLocationRelativeTo(null);
        comboc();
        limita();
        fecha_pantalla1.setText(fecha());
        setTitle("Total de combustible diario");
        setIconImage(new ImageIcon(getClass().getResource("/Imagen/image.png")).getImage());
    }
    void limpiar(){
    creditopagado.setText("");
    consumo.setText("");
    bono.setText("");
    total.setText("");
    useTotal.setText("");
    
    combo1.setSelectedIndex(0);
    credito.setText("");
    JOptionPane.showMessageDialog(rootPane, "Datos limpiados correctamente.","ERROR",JOptionPane.INFORMATION_MESSAGE);
                

    }
    public void limita(){
    RestrictedTextField limitarr =new RestrictedTextField(credito);
    limitarr.setLimit(8);
    RestrictedTextField limitarr0 =new RestrictedTextField(consumo);
    limitarr0.setLimit(8);
    RestrictedTextField limitarr1 =new RestrictedTextField(bono);
    limitarr1.setLimit(8);
    RestrictedTextField limitarr2 =new RestrictedTextField(total);
    limitarr2.setLimit(8);
    RestrictedTextField limitarr3 =new RestrictedTextField(creditopagado);
    limitarr3.setLimit(8);
    
    //nombrecategoria.setDocument(new limitar(nombrecategoria,3,12));
    
    }
    void cargar(String valor){
    /*String mostrar="SELECT * FROM `categoria` WHERE '%"+valor+"%'";*/
    String mostrar="SELECT `id_cierre_caja`, `consumo_diario`, `bonos`, `inventario_total_combustible`, `total_cierre`, `fecha_cierre`, `creditos_pagados`, `id_precio_combustible` FROM `cierre_caja` WHERE `id_cierre_caja` LIKE  '%"+valor+"%'";
    String []titulos={" Creditos","Consumo diario","Bonos","Inventario total","Total cierre","Fecha cierre","creditos_pagados","id_precio_combustible"};
    String []Registros=new String[9];
    DefaultTableModel model = new DefaultTableModel(null,titulos);
  
        try {
              Statement st = cn.createStatement();
              java.sql.ResultSet rs = st.executeQuery(mostrar);
              while(rs.next())
              {
                  Registros[0]= rs.getString("id_cierre_caja");
                  Registros[1]= rs.getString("consumo_diario");
                  Registros[2]= rs.getString("bonos");
                  Registros[3]= rs.getString("inventario_total_combustible");
                  Registros[4]= rs.getString("total_cierre");
                  Registros[5]= rs.getString("fecha_cierre");
                  Registros[6]= rs.getString("creditos_pagados");
                  Registros[7]= rs.getString("id_precio_combustible");
                  
               
                           
                  model.addRow(Registros);
              }
              tabla.setModel(model);
        } catch (java.sql.SQLException ex) {
            Logger.getLogger(Categoria.class.getName()).log(Level.SEVERE, null, ex);
        }
    
  }
    public void comboc(){
    try {
            
            String sql = "SELECT * FROM `precio_combustible` ";
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            combo1.addItem("seleccione estado");
            while (rs.next()) {

                this.combo1.addItem(rs.getString("precio"));
            }
        } catch (Exception e) {

        }
    }
    
    void cargar1(){
    
    String mostrar="SELECT `id_cierre_caja`, `consumo_diario`, `bonos`, `inventario_total_combustible`, `total_cierre`, `fecha_cierre`, `creditos_pagados`, `id_precio_combustible` FROM `cierre_caja` WHERE 1";
    String []titulos={"Creditos","Consumo diario","Bonos","Inventario total","Total cierre","Fecha cierre","creditos_pagados","id_precio_combustible"};
    String []Registros=new String[9];
    DefaultTableModel model = new DefaultTableModel(null,titulos);
  
        try {
              Statement st = cn.createStatement();
              java.sql.ResultSet rs = st.executeQuery(mostrar);
              while(rs.next())
              {
                  Registros[0]= rs.getString("id_cierre_caja");
                  Registros[1]= rs.getString("consumo_diario");
                  Registros[2]= rs.getString("bonos");
                  Registros[3]= rs.getString("inventario_total_combustible");
                  Registros[4]= rs.getString("total_cierre");
                  Registros[5]= rs.getString("fecha_cierre");
                  Registros[6]= rs.getString("creditos_pagados");
                  Registros[7]= rs.getString("id_precio_combustible");
                  
               
                           
                  model.addRow(Registros);
              }
              tabla.setModel(model);
        } catch (java.sql.SQLException ex) {
            Logger.getLogger(Categoria.class.getName()).log(Level.SEVERE, null, ex);
        }
    
  }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        creditopagado = new javax.swing.JTextField();
        consumo = new javax.swing.JTextField();
        bono = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        total = new javax.swing.JTextField();
        fecha_pantalla1 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        error1 = new javax.swing.JLabel();
        error2 = new javax.swing.JLabel();
        error4 = new javax.swing.JLabel();
        error6 = new javax.swing.JLabel();
        error7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jLabel15 = new javax.swing.JLabel();
        buscar = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        useTotal = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        label_iconotecnogas = new javax.swing.JLabel();
        combo1 = new javax.swing.JComboBox<>();
        credito = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        error3 = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        creditopagado.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                creditopagadoKeyTyped(evt);
            }
        });
        getContentPane().add(creditopagado, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 284, 201, -1));

        consumo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                consumoKeyTyped(evt);
            }
        });
        getContentPane().add(consumo, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 103, 201, -1));

        bono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                bonoKeyTyped(evt);
            }
        });
        getContentPane().add(bono, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 140, 201, -1));

        jButton1.setText("Ingresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 257, 176, 23));

        jButton2.setText("Limpiar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 492, 176, 23));

        jButton3.setText("Modificar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 493, 176, 20));

        jButton5.setText("Atrás");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 492, 171, 23));

        total.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                totalKeyTyped(evt);
            }
        });
        getContentPane().add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 187, 201, -1));

        fecha_pantalla1.setText("dd-MM-YYYY");
        getContentPane().add(fecha_pantalla1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, -1, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel13.setText("Fecha:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("Total cierre: ");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 63, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("Consumo del día:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 105, -1, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setText("Bonos:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 142, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setText("Inventario total de combustible: ");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 187, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel12.setText("Precio actual de gasolina:");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 241, -1, -1));

        error1.setForeground(new java.awt.Color(255, 0, 51));
        error1.setText("...");
        getContentPane().add(error1, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 85, 201, -1));

        error2.setForeground(new java.awt.Color(255, 0, 51));
        error2.setText("...");
        getContentPane().add(error2, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 124, 201, -1));

        error4.setForeground(new java.awt.Color(255, 0, 51));
        error4.setText("...");
        getContentPane().add(error4, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 164, 201, -1));

        error6.setForeground(new java.awt.Color(255, 0, 51));
        error6.setText("...");
        getContentPane().add(error6, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 212, 201, -1));

        error7.setForeground(new java.awt.Color(255, 0, 51));
        error7.setText("...");
        getContentPane().add(error7, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 261, 201, -1));

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabla);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 776, 112));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setText("Buscar:");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 335, -1, -1));

        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });
        buscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buscarKeyReleased(evt);
            }
        });
        getContentPane().add(buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(56, 333, 176, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel16.setText("Usuario:");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        useTotal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        useTotal.setText("...");
        getContentPane().add(useTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 90, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(51, 153, 255));
        jLabel17.setText("Total de Combustible diario");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(205, 8, 366, -1));

        label_iconotecnogas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/logo_tecnogas_transp.png"))); // NOI18N
        label_iconotecnogas.setPreferredSize(new java.awt.Dimension(270, 134));
        getContentPane().add(label_iconotecnogas, new org.netbeans.lib.awtextra.AbsoluteConstraints(516, 82, -1, -1));

        getContentPane().add(combo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 231, 201, -1));

        credito.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                creditoKeyTyped(evt);
            }
        });
        getContentPane().add(credito, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 60, 201, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setText("Créditos pagados: ");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 286, -1, -1));

        error3.setForeground(new java.awt.Color(255, 0, 51));
        error3.setText("...");
        getContentPane().add(error3, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 313, 201, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/fondo5.jpg"))); // NOI18N
        fondo.setText("jLabel4");
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, 610));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        try {
             String sql="INSERT INTO `cierre_caja`(`id_cierre_caja`, `consumo_diario`, `bonos`, `inventario_total_combustible`, `total_cierre`, `fecha_cierre`, `creditos_pagados`, `id_precio_combustible`) VALUES (NULL, ?, ?, ?, ?, SYSDATE(), ?, ?)";
   
            
            PreparedStatement pst  = cn.prepareStatement(sql);
           
            if (credito.getText().isEmpty()) {
                 error1.setText("No puede estar vacio !!"); 
            }else if (20>credito.getText().length()&&credito.getText().length()>3) {
                pst.setString(1, credito.getText());
                error1.setText("...");
            }else{
                error1.setText("Minimo 3 y maximo 20 caracteres!!");
            } 
                
            if (consumo.getText().isEmpty()) {
                error2.setText("No puede estar vacio !!");   
            }
            else if (20>consumo.getText().length()&&consumo.getText().length()>3) {
                pst.setString(2, consumo.getText());
                error2.setText("...");
            }else{
                error2.setText("Minimo 3 y maximo 20 caracteres!!");
            } 
            
            if (bono.getText().isEmpty()) {
                error4.setText("No puede estar vacio !!");  
            }
            else if (20>bono.getText().length()&&bono.getText().length()>3) {
                pst.setString(3, bono.getText());
                error4.setText("...");
            }else{
                error4.setText("Minimo 3 y maximo 20 caracteres!!");
            }
                
            if (total.getText().isEmpty()) {   
                error6.setText("No puede estar vacio !!");
            }
            else if (20>total.getText().length()&&total.getText().length()>3) {
                pst.setString(4, total.getText());
                error6.setText("...");
                }else{
                error6.setText("Minimo 3 y maximo 20 caracteres!!");
            }
      
            if (creditopagado.getText().isEmpty()) {
                error3.setText("No puede estar vacio !!");   
            }
                else if (20>creditopagado.getText().length()&&creditopagado.getText().length()>3) {
                pst.setString(5, creditopagado.getText());
                error3.setText("...");
                }else{
                error3.setText("Minimo 3 y maximo 20 caracteres!!");
            }
            pst.setInt(6, combo1.getSelectedIndex());
            
                pst.executeUpdate();
                JOptionPane.showMessageDialog(rootPane, "Insertados correctamente","ERROR",JOptionPane.INFORMATION_MESSAGE);
                limpiar();
                cargar("");
             
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
        }
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
    Control_Combustible_Diario botonatras = new Control_Combustible_Diario ();
    botonatras.setVisible(true);         
    }//GEN-LAST:event_jButton5MouseClicked

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        Control_Combustible_Diario ingresar = new Control_Combustible_Diario();
        ingresar.setVisible(true);   
        Control_Combustible_Diario.useC.setText(useTotal.getText());
        this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void pl3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pl3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pl3ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
         try {
       //String sql = "UPDATE `bombas` SET `num_bomba` = '" + txtNumBomba.getText() + "',`fecha_actualizacion_bomba` = SYSDATE(),`estado_bomba` = '" + comboEstado.getSelectedItem() + "' WHERE `bombas`.`id_bombas` = '" + txtIDbomba.getText() + "'";
       String sql1= "UPDATE `cierre_caja` SET `consumo_diario` = ?, `bonos` = ?, `inventario_total_combustible` = ?, `total_cierre` = ?, `fecha_cierre` = SYSDATE(), `creditos_pagados` = ?, `id_precio_combustible` = ? WHERE `cierre_caja`.`id_cierre_caja` = '"+useTotal.getText()+"'";
       PreparedStatement pst = cn.prepareStatement(sql1);
            
            if (credito.getText().isEmpty()) {
                 error1.setText("No puede estar vacio !!"); 
            }else if (20>credito.getText().length()&&credito.getText().length()>3) {
                pst.setString(1, credito.getText());
                error1.setText("...");
            }else{
                error1.setText("Minimo 3 y maximo 20 caracteres!!");
            } 
                
            if (consumo.getText().isEmpty()) {
                error2.setText("No puede estar vacio !!");   
            }
            else if (20>consumo.getText().length()&&consumo.getText().length()>3) {
                pst.setString(2, consumo.getText());
                error2.setText("...");
            }else{
                error2.setText("Minimo 3 y maximo 20 caracteres!!");
            } 
            
            if (bono.getText().isEmpty()) {
                error4.setText("No puede estar vacio !!");  
            }
            else if (20>bono.getText().length()&&bono.getText().length()>3) {
                pst.setString(3, bono.getText());
                error4.setText("...");
            }else{
                error4.setText("Minimo 3 y maximo 20 caracteres!!");
            }
                
            if (total.getText().isEmpty()) {   
                error6.setText("No puede estar vacio !!");
            }
            else if (20>total.getText().length()&&total.getText().length()>3) {
                pst.setString(4, total.getText());
                error6.setText("...");
                }else{
                error6.setText("Minimo 3 y maximo 20 caracteres!!");
            }
  
            if (creditopagado.getText().isEmpty()) {
                error3.setText("No puede estar vacio !!");   
            }
                else if (20>creditopagado.getText().length()&&creditopagado.getText().length()>3) {
                pst.setString(5, creditopagado.getText());
                error3.setText("...");
                }else{
                error3.setText("Minimo 3 y maximo 20 caracteres!!");
            }
            pst.setInt(6, combo1.getSelectedIndex());
               

            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "LOS DATOS HAN SIDO MODIFICADOS");
            cargar("");
             limpiar();
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Error introduzca bien los datos");

        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        limpiar();
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
        // TODO add your handling code here:
        int seleccionar = tabla.rowAtPoint(evt.getPoint());
       creditopagado.setText(String.valueOf(tabla.getValueAt(seleccionar, 6)));
       credito.setText(String.valueOf(tabla.getValueAt(seleccionar, 4)));
       consumo.setText(String.valueOf(tabla.getValueAt(seleccionar, 1)));
       bono.setText(String.valueOf(tabla.getValueAt(seleccionar, 2)));
       total.setText(String.valueOf(tabla.getValueAt(seleccionar, 3)));
       //diario.setText(String.valueOf(tabla.getValueAt(seleccionar, 4)));
       fecha_pantalla1.setText(String.valueOf(tabla.getValueAt(seleccionar, 5)));
       useTotal.setText(String.valueOf(tabla.getValueAt(seleccionar, 0)));
       combo1.setSelectedItem(String.valueOf(tabla.getValueAt(seleccionar, 7)));
    

    }//GEN-LAST:event_tablaMouseClicked

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        // TODO add your handling code here:
        cargar(buscar.getText());
    }//GEN-LAST:event_buscarActionPerformed

    private void buscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_buscarKeyReleased
        // TODO add your handling code here:
        cargar(buscar.getText());
    }//GEN-LAST:event_buscarKeyReleased

    private void creditopagadoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_creditopagadoKeyTyped
        // TODO add your handling code here:
        char validar =evt.getKeyChar();
        
        if(Character.isSpaceChar(validar) ||Character.isLetter(validar)){
        getToolkit().beep();
        evt.consume();
        JOptionPane.showMessageDialog(rootPane, "INGRESA SOLO NUMEROS SIN ESPACIOS","Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_creditopagadoKeyTyped

    private void consumoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_consumoKeyTyped
        // TODO add your handling code here:
        char validar =evt.getKeyChar();
        
        if(Character.isSpaceChar(validar) ||Character.isLetter(validar)){
        getToolkit().beep();
        evt.consume();
        JOptionPane.showMessageDialog(rootPane, "INGRESA SOLO NUMEROS SIN ESPACIOS","Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_consumoKeyTyped

    private void bonoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bonoKeyTyped
        // TODO add your handling code here:
        char validar =evt.getKeyChar();
        
        if(Character.isSpaceChar(validar) ||Character.isLetter(validar)){
        getToolkit().beep();
        evt.consume();
        JOptionPane.showMessageDialog(rootPane, "INGRESA SOLO NUMEROS SIN ESPACIOS","Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_bonoKeyTyped

    private void totalKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_totalKeyTyped
        // TODO add your handling code here:
        char validar =evt.getKeyChar();
        
        if(Character.isSpaceChar(validar) ||Character.isLetter(validar)){
        getToolkit().beep();
        evt.consume();
        JOptionPane.showMessageDialog(rootPane, "INGRESA SOLO NUMEROS SIN ESPACIOS","Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_totalKeyTyped

    private void pl3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pl3KeyTyped
        // TODO add your handling code here:
        char validar =evt.getKeyChar();
        
        if(Character.isSpaceChar(validar) ||Character.isLetter(validar)){
        getToolkit().beep();
        evt.consume();
        JOptionPane.showMessageDialog(rootPane, "INGRESA SOLO NUMEROS SIN ESPACIOS","Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_pl3KeyTyped

    private void creditoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_creditoKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_creditoKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ingreso_Totalidad_Combustible.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ingreso_Totalidad_Combustible.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ingreso_Totalidad_Combustible.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ingreso_Totalidad_Combustible.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ingreso_Totalidad_Combustible().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bono;
    private javax.swing.JTextField buscar;
    private javax.swing.JComboBox<String> combo1;
    private javax.swing.JTextField consumo;
    private javax.swing.JTextField credito;
    private javax.swing.JTextField creditopagado;
    private javax.swing.JLabel error1;
    private javax.swing.JLabel error2;
    private javax.swing.JLabel error3;
    private javax.swing.JLabel error4;
    private javax.swing.JLabel error6;
    private javax.swing.JLabel error7;
    private javax.swing.JLabel fecha_pantalla1;
    private javax.swing.JLabel fondo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel label_iconotecnogas;
    private javax.swing.JTable tabla;
    private javax.swing.JTextField total;
    public static javax.swing.JLabel useTotal;
    // End of variables declaration//GEN-END:variables
}
