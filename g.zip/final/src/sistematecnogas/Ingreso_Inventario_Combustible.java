/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistematecnogas;

import Atxy2k.CustomTextField.RestrictedTextField;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import servicios.conexion;

/**
 *
 * @author Wilfredo Serrano
 */
public class Ingreso_Inventario_Combustible extends javax.swing.JFrame {

   String oll="";
   
     conexion cc = new conexion();
     Connection cn = conexion.conexion();
        
    
    //valores_conection
     public void limitar(){
    
    RestrictedTextField limitar1 =new RestrictedTextField(caja_recibido_diesel);
    limitar1.setLimit(18);
    RestrictedTextField limitar2 =new RestrictedTextField(inv_inicial);
    limitar2.setLimit(18);
    RestrictedTextField limitar3 =new RestrictedTextField(caja_despa_diesel);
    limitar3.setLimit(18);
    RestrictedTextField limitar4 =new RestrictedTextField(inv_final);
    limitar4.setLimit(18);
    RestrictedTextField limitar5 =new RestrictedTextField(caja_litfaltantes_diesel);
    limitar5.setLimit(18);
    
    }
    public void Valida(){
        if (caja_recibido_diesel.getText().isEmpty()) {
            error11.setText("*");
        } else {
            error1.setText("");
        }
        if (inv_inicial.getText().isEmpty()) {
            error12.setText("*");
        } else {
            error12.setText("");
        }
        
        if (caja_despa_diesel.getText().isEmpty()) {
            error13.setText("*");
        } else {
            error13.setText("");
        }
        if (inv_final.getText().isEmpty()) {
            error14.setText("*");
        } else {
            error14.setText("");
        }
        if (caja_litfaltantes_diesel.getText().isEmpty()) {
            error15.setText("*");
        } else {
            error15.setText("");
        }
    } 
     void mostrartipoproducto(){
       String sql="SELECT * FROM `tipo_combustible`";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                iidtipocomb.addItem(rs.getString("id_tipo_combustible"));
            }
        } catch (java.sql.SQLException ex) {
            Logger.getLogger(Proveedores.class.getName()).log(Level.SEVERE, null, ex);
        }
       
   }
    
   
    public Connection con;
    
    PreparedStatement ps;
    ResultSet rs;
    void cargar(String valor){
    /*String mostrar="SELECT * FROM `categoria` WHERE '%"+valor+"%'";*/
    String mostrar="SELECT `id_inventario`, `recibido`, `recibido_plg3`, `inventario_inicial`, `inventario_inicial_plg3`, `litros_faltantes`, `litros_faltantes_plg3`, `despacho`, `despacho_plg3`, `inventario_final`, `inventario_final_plg3`, `id_usuario`, `id_tipo_combustible` FROM `inventario_combustible` WHERE `id_inventario` LIKE '%"+valor+"%'";
    String []titulos={"Id de inventario","Recibido","Pulgadas cubicas","Inventario inicial","Pulgas cubicas iniciales","Litros faltantes","Litros faltantes cubicas","Despacho","Inventario final","Inventario final cubico","Inventario final cubica","ID tabla","ID combustible"};
    String []Registros=new String[14];
    DefaultTableModel model = new DefaultTableModel(null,titulos);
  
        try {
              Statement st = cn.createStatement();
              java.sql.ResultSet rs = st.executeQuery(mostrar);
              
              while(rs.next())
              {
                  Registros[0]= rs.getString("id_inventario");
                  Registros[1]= rs.getString("recibido");
                  Registros[2]= rs.getString("recibido_plg3");
                  Registros[3]= rs.getString("inventario_inicial");
                  Registros[4]= rs.getString("inventario_inicial_plg3");
                  Registros[5]= rs.getString("litros_faltantes");
                  Registros[6]= rs.getString("litros_faltantes_plg3");
                  Registros[7]= rs.getString("despacho");
                  Registros[8]= rs.getString("despacho_plg3");
                  Registros[9]= rs.getString("inventario_final");
                  Registros[10]= rs.getString("inventario_final_plg3");
                  Registros[11]= rs.getString("id_usuario");
                  Registros[12]= rs.getString("id_tipo_combustible");
                  
                           
                  model.addRow(Registros);
              }
              tabla_inventario.setModel(model);
        } catch (java.sql.SQLException ex) {
            Logger.getLogger(Proveedores.class.getName()).log(Level.SEVERE, null, ex);
        }
    
  }
    
   
    
    public void limpiarcajas1(){
    //limpiar cajas diesel
    caja_recibido_diesel.setText(null);
    inv_inicial.setText(null);
    caja_despa_diesel.setText(null);
    inv_final.setText(null);
    caja_litfaltantes_diesel.setText(null);
    recibido_litro_diesel.setText(null);
    invinicial_litro_diesel.setText(null);
    despachado_litro_diesel.setText(null);
    invfinal_litro_diesel.setText(null);
    litfaltantes_litro_diesel.setText(null);
    caja_plg_recibido.setText(null);
    caja_plg_invinicial.setText(null);
    caja_plg_despachado.setText(null);
    caja_plg_invfinal.setText(null);
    caja_plg_litfaltantes.setText(null);
    iidtipocomb.setSelectedIndex(0);
    id.setText(null);
    tipocom.setText(null);
    idcom.setText(null);
    };
    
    
    
    
    /**
     * Creates new form Ingreso_Inventario_Combustible
     */
    public Ingreso_Inventario_Combustible() {
        initComponents();
         setLocationRelativeTo(null);
         mostrartipoproducto();
        setTitle("Inventario de combustible");
        limitar();
        Valida();
        cargar("");
        //setIconImage(new ImageIcon(getClass().getResource("/Imagen/logo_tecnogas_transp.png")).getImage());
        fecha_pantalla1.setText(fecha());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        textField31 = new java.awt.TextField();
        jLabel12 = new javax.swing.JLabel();
        fecha_pantalla = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        modificar_insert = new java.awt.Button();
        ingresar_diesel = new java.awt.Button();
        atras = new java.awt.Button();
        Conversion_button = new java.awt.Button();
        jLabel13 = new javax.swing.JLabel();
        fecha_pantalla1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla_inventario = new javax.swing.JTable();
        Limpiar = new java.awt.Button();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        id = new javax.swing.JLabel();
        tipocom = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        idcom = new javax.swing.JLabel();
        iidtipocomb = new javax.swing.JComboBox();
        error1 = new javax.swing.JLabel();
        error2 = new javax.swing.JLabel();
        error3 = new javax.swing.JLabel();
        error4 = new javax.swing.JLabel();
        error5 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        caja_plg_recibido = new javax.swing.JLabel();
        recibido_litro_diesel = new javax.swing.JLabel();
        invinicial_litro_diesel = new javax.swing.JLabel();
        caja_plg_invinicial = new javax.swing.JLabel();
        despachado_litro_diesel = new javax.swing.JLabel();
        caja_plg_despachado = new javax.swing.JLabel();
        litfaltantes_litro_diesel = new javax.swing.JLabel();
        caja_plg_invfinal = new javax.swing.JLabel();
        invfinal_litro_diesel = new javax.swing.JLabel();
        caja_plg_litfaltantes = new javax.swing.JLabel();
        caja_recibido_diesel = new javax.swing.JTextField();
        inv_inicial = new javax.swing.JTextField();
        caja_despa_diesel = new javax.swing.JTextField();
        inv_final = new javax.swing.JTextField();
        caja_litfaltantes_diesel = new javax.swing.JTextField();
        error11 = new javax.swing.JLabel();
        error15 = new javax.swing.JLabel();
        error12 = new javax.swing.JLabel();
        error13 = new javax.swing.JLabel();
        error14 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        buscar = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        label_iconotecnogas = new javax.swing.JLabel();
        useInventario = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        textField31.setText("textField31");

        jLabel12.setText("Fecha:");

        fecha_pantalla.setText("dd-MM-YYYY");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Galon");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 59, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Litros");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(273, 59, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Pulgadas cubicas");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(354, 59, -1, -1));

        jLabel6.setText("Inv. Inicial");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 155, -1, -1));

        jLabel7.setText("Despachado");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, -1, 21));

        jLabel9.setText("Recibido     ");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 98, -1, -1));

        jLabel8.setText("Lts. Faltantes");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 328, -1, -1));

        jLabel10.setText("Inv. Final");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 273, -1, 14));

        modificar_insert.setLabel("Modificar");
        modificar_insert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificar_insertActionPerformed(evt);
            }
        });
        getContentPane().add(modificar_insert, new org.netbeans.lib.awtextra.AbsoluteConstraints(829, 557, 130, -1));

        ingresar_diesel.setLabel("Ingresar");
        ingresar_diesel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ingresar_dieselActionPerformed(evt);
            }
        });
        getContentPane().add(ingresar_diesel, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 389, 111, -1));

        atras.setLabel("Atras");
        atras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                atrasMouseClicked(evt);
            }
        });
        atras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atrasActionPerformed(evt);
            }
        });
        getContentPane().add(atras, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 557, 130, -1));

        Conversion_button.setLabel("Conversion");
        Conversion_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Conversion_buttonActionPerformed(evt);
            }
        });
        getContentPane().add(Conversion_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 320, 111, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel13.setText("Fecha:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        fecha_pantalla1.setText("dd-MM-YYYY");
        getContentPane().add(fecha_pantalla1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, -1, -1));

        tabla_inventario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Galones Recibidos", "Recibidos in³", "Inventario Inicial", "Inventario Inicial in³", "Litros Faltantes", "Litros Faltantes in³", "Despachado", "Despachado in³", "Inventario Final", "Inventario Final in³", "ID Usuario", "Tipo Combustible"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, true, true, false, false, false, false, true, true, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabla_inventario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabla_inventarioMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla_inventario);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 435, 949, 92));

        Limpiar.setActionCommand("Limpiar");
        Limpiar.setLabel("Limpiar");
        Limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(Limpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(402, 557, 130, -1));

        jLabel14.setText("ID  de usuario:");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 191, -1, -1));

        jLabel15.setText("Tipo de combustible: ");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 222, -1, -1));

        id.setText("...");
        getContentPane().add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(646, 191, 36, -1));

        tipocom.setText("...");
        getContentPane().add(tipocom, new org.netbeans.lib.awtextra.AbsoluteConstraints(646, 222, 36, -1));

        jLabel16.setText("ID combustible:");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 251, 99, -1));

        idcom.setText("...");
        getContentPane().add(idcom, new org.netbeans.lib.awtextra.AbsoluteConstraints(646, 251, 36, -1));

        iidtipocomb.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Seleccione.." }));
        iidtipocomb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iidtipocombActionPerformed(evt);
            }
        });
        iidtipocomb.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                iidtipocombKeyPressed(evt);
            }
        });
        getContentPane().add(iidtipocomb, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 100, 162, -1));

        error1.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        error1.setForeground(new java.awt.Color(255, 0, 51));
        error1.setText("...");
        getContentPane().add(error1, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 122, 207, -1));

        error2.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        error2.setForeground(new java.awt.Color(255, 0, 51));
        error2.setText("...");
        getContentPane().add(error2, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 178, 207, -1));

        error3.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        error3.setForeground(new java.awt.Color(255, 0, 51));
        error3.setText("...");
        getContentPane().add(error3, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 237, 207, -1));

        error4.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        error4.setForeground(new java.awt.Color(255, 0, 51));
        error4.setText("...");
        getContentPane().add(error4, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 296, 207, -1));

        error5.setFont(new java.awt.Font("Arial", 3, 12)); // NOI18N
        error5.setForeground(new java.awt.Color(255, 0, 51));
        error5.setText("...");
        getContentPane().add(error5, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 354, 207, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel17.setText("Tipo de combustible");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 59, -1, -1));

        caja_plg_recibido.setText("...");
        caja_plg_recibido.setPreferredSize(new java.awt.Dimension(10, 21));
        getContentPane().add(caja_plg_recibido, new org.netbeans.lib.awtextra.AbsoluteConstraints(354, 99, 60, -1));

        recibido_litro_diesel.setText("...");
        recibido_litro_diesel.setPreferredSize(new java.awt.Dimension(10, 21));
        getContentPane().add(recibido_litro_diesel, new org.netbeans.lib.awtextra.AbsoluteConstraints(276, 99, 53, -1));

        invinicial_litro_diesel.setText("...");
        getContentPane().add(invinicial_litro_diesel, new org.netbeans.lib.awtextra.AbsoluteConstraints(276, 151, 60, 21));

        caja_plg_invinicial.setText("...");
        getContentPane().add(caja_plg_invinicial, new org.netbeans.lib.awtextra.AbsoluteConstraints(354, 151, 59, 21));

        despachado_litro_diesel.setText("...");
        getContentPane().add(despachado_litro_diesel, new org.netbeans.lib.awtextra.AbsoluteConstraints(276, 211, 60, 19));

        caja_plg_despachado.setText("...");
        getContentPane().add(caja_plg_despachado, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 211, 60, 18));

        litfaltantes_litro_diesel.setText("...");
        getContentPane().add(litfaltantes_litro_diesel, new org.netbeans.lib.awtextra.AbsoluteConstraints(276, 270, 57, 20));

        caja_plg_invfinal.setText("...");
        getContentPane().add(caja_plg_invfinal, new org.netbeans.lib.awtextra.AbsoluteConstraints(351, 274, 59, -1));

        invfinal_litro_diesel.setText("...");
        getContentPane().add(invfinal_litro_diesel, new org.netbeans.lib.awtextra.AbsoluteConstraints(276, 324, 57, 20));

        caja_plg_litfaltantes.setText("...");
        getContentPane().add(caja_plg_litfaltantes, new org.netbeans.lib.awtextra.AbsoluteConstraints(351, 324, 63, 20));

        caja_recibido_diesel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                caja_recibido_dieselActionPerformed(evt);
            }
        });
        caja_recibido_diesel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                caja_recibido_dieselKeyTyped(evt);
            }
        });
        getContentPane().add(caja_recibido_diesel, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 100, 105, -1));

        inv_inicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inv_inicialActionPerformed(evt);
            }
        });
        inv_inicial.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                inv_inicialKeyTyped(evt);
            }
        });
        getContentPane().add(inv_inicial, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 152, 105, -1));

        caja_despa_diesel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                caja_despa_dieselActionPerformed(evt);
            }
        });
        caja_despa_diesel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                caja_despa_dieselKeyTyped(evt);
            }
        });
        getContentPane().add(caja_despa_diesel, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 211, 105, -1));

        inv_final.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                inv_finalKeyTyped(evt);
            }
        });
        getContentPane().add(inv_final, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 271, 105, -1));

        caja_litfaltantes_diesel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                caja_litfaltantes_dieselKeyTyped(evt);
            }
        });
        getContentPane().add(caja_litfaltantes_diesel, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 325, 105, -1));

        error11.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        error11.setForeground(new java.awt.Color(255, 0, 51));
        error11.setText("...");
        getContentPane().add(error11, new org.netbeans.lib.awtextra.AbsoluteConstraints(432, 100, 31, -1));

        error15.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        error15.setForeground(new java.awt.Color(255, 0, 51));
        error15.setText("...");
        getContentPane().add(error15, new org.netbeans.lib.awtextra.AbsoluteConstraints(432, 325, 31, -1));

        error12.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        error12.setForeground(new java.awt.Color(255, 0, 51));
        error12.setText("...");
        getContentPane().add(error12, new org.netbeans.lib.awtextra.AbsoluteConstraints(431, 152, 31, -1));

        error13.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        error13.setForeground(new java.awt.Color(255, 0, 51));
        error13.setText("...");
        getContentPane().add(error13, new org.netbeans.lib.awtextra.AbsoluteConstraints(432, 211, 31, -1));

        error14.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        error14.setForeground(new java.awt.Color(255, 0, 51));
        error14.setText("...");
        getContentPane().add(error14, new org.netbeans.lib.awtextra.AbsoluteConstraints(432, 271, 31, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel18.setText("1. Super");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 99, 78, -1));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel19.setText("2. Diesel");
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 115, 78, -1));

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel20.setText("Tipo");
        getContentPane().add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 59, 78, -1));

        buscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buscarKeyReleased(evt);
            }
        });
        getContentPane().add(buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(92, 394, 55, -1));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel21.setText("Buscar: ");
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 395, 64, -1));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(51, 153, 255));
        jLabel22.setText("Inventario");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(386, 12, 134, -1));

        label_iconotecnogas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/logo_tecnogas_transp.png"))); // NOI18N
        label_iconotecnogas.setText("jLabel4");
        label_iconotecnogas.setPreferredSize(new java.awt.Dimension(270, 134));
        getContentPane().add(label_iconotecnogas, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 185, 230, 125));

        useInventario.setText("....");
        getContentPane().add(useInventario, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 50, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel11.setText("Usuario:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/fondo5.jpg"))); // NOI18N
        fondo.setText("jLabel4");
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 990, 680));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static String fecha(){
    Date fecha = new Date();
    SimpleDateFormat formatofecha = new SimpleDateFormat("dd/MM/YYYY");
           return formatofecha.format(fecha);
    }
    
    private void ingresar_dieselActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ingresar_dieselActionPerformed

        Valida();
        limitar();
        
        conexion cc = new conexion();
        Connection cn = cc.conexion();
        
        
        
       try{
          
           String a = System.getProperty("user.name");
           String  consulta = "INSERT INTO `inventario_combustible` (`id_inventario`, `recibido`, `recibido_plg3`, `inventario_inicial`, `inventario_inicial_plg3`, `litros_faltantes`, `litros_faltantes_plg3`, `despacho`, `despacho_plg3`, `inventario_final`, `inventario_final_plg3`, `id_usuario`, `id_tipo_combustible`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
           ps = cn.prepareStatement(consulta);
          
           ps.setString(1, caja_recibido_diesel.getText()); //1-
           ps.setString(2, caja_plg_recibido.getText()); //3-
           ps.setString(3, inv_inicial.getText()); //4-
           
           String suma  = inv_inicial.getText() + inv_final.getText();
           ps.setString(5, caja_litfaltantes_diesel.getText()); // 6-
           ps.setString(6, caja_plg_litfaltantes.getText()); // 7-
           ps.setString(7, suma ); // 8-
           
           ps.setString(8, caja_plg_despachado.getText()); // 9-
           
           
           ps.setString(10, caja_plg_invfinal.getText());
           ps.setString(11, "1"); 
           ps.setInt(12, iidtipocomb.getSelectedIndex());

       
   
    if (Double.parseDouble(inv_inicial.getText())<=Double.parseDouble(inv_final.getText())||Double.parseDouble(inv_inicial.getText())==0||Double.parseDouble(inv_final.getText())==0) {
             JOptionPane.showMessageDialog(null, "El inventario inicial no puede ser menor que el inventario final", "Error", JOptionPane.ERROR_MESSAGE);
        }else{
       ps.setString(4, caja_plg_invinicial.getText()); // 5-
       ps.setString(9, inv_final.getText()); // 10-
       
    }
           
           
           
           int resultado = ps.executeUpdate(); //ejecutamos
           if (resultado > 0){
                JOptionPane.showMessageDialog(null, "Registro insertado correctamente.");
                limpiarcajas1();
                
            }else{
                    JOptionPane.showMessageDialog(null, "Error al insertar el registro.");
           }
           
           
           
       }catch(Exception ex){
       System.err.println("Error. "+ex);
       
       }
        
    }//GEN-LAST:event_ingresar_dieselActionPerformed

    private void atrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atrasActionPerformed
        // TODO add your handling code here:
        Control_Combustible_Diario boton_Control_Combustible_Diario = new Control_Combustible_Diario();
        boton_Control_Combustible_Diario.setVisible(true);
        Control_Combustible_Diario.useC.setText(useInventario.getText());
        this.dispose();
    }//GEN-LAST:event_atrasActionPerformed

    private void Conversion_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Conversion_buttonActionPerformed
       
        
        //convertir plg
        Double a = Double.parseDouble(caja_recibido_diesel.getText());
                
        String convert1= Double.toString(a/61.024);
        
        caja_plg_recibido.setText(convert1);
        
        //2
        
        Double b = Double.parseDouble(inv_inicial.getText());
                
        String convert2= Double.toString(b/61.024);
        
        caja_plg_invinicial.setText((convert2));
        
        //3
        
        Double c = Double.parseDouble(caja_despa_diesel.getText());
                
        String convert3= Double.toString(c/61.024);
        
        caja_plg_despachado.setText((convert3));
        
        //4
        
        Double d = Double.parseDouble(inv_final.getText());
                
        String convert4= Double.toString(d/61.024);
        
        caja_plg_invfinal.setText((convert4));
        
        //5
        
        Double e = Double.parseDouble(caja_litfaltantes_diesel.getText());
                
        String convert5= Double.toString(e/61.024);
        
        caja_plg_litfaltantes.setText((convert5));
        
       
        // convertir litros 3.78541
        
        Double f = Double.parseDouble(caja_litfaltantes_diesel.getText());
                
        String convert6= Double.toString(f/3.78541);
        
        recibido_litro_diesel.setText((convert6));
        
        //2
        Double g = Double.parseDouble(inv_inicial.getText());
                
        String convert7= Double.toString(g/3.78541);
        
        invinicial_litro_diesel.setText((convert7));
        
        //3
        Double h = Double.parseDouble(caja_despa_diesel.getText());
                
        String convert8= Double.toString(h/3.78541);
        
        despachado_litro_diesel.setText((convert8));
        
        
        //4
        Double i = Double.parseDouble(inv_final.getText());
                
        String convert9= Double.toString(i/3.78541);
        
        invfinal_litro_diesel.setText((convert9));
        
        
        //5
        Double j = Double.parseDouble(caja_litfaltantes_diesel.getText());
                
        String convert10= Double.toString(j/3.78541);
        
        litfaltantes_litro_diesel.setText((convert10));
        
        
        
        
        
    }//GEN-LAST:event_Conversion_buttonActionPerformed

    private void atrasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_atrasMouseClicked
       
    }//GEN-LAST:event_atrasMouseClicked

    private void LimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LimpiarActionPerformed
     limpiarcajas1();
    }//GEN-LAST:event_LimpiarActionPerformed

    private void modificar_insertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificar_insertActionPerformed
        // TODO add your handling code here:
        try {
            //String sql= "`proveedores` SET `id_proveedores`='"+idproveedor.getText()+"',`nombre`='"+descripcion.getText()+"',`telefono`='"+telefono.getText()+"',`direccion_correo`='"+correo.getText()+"',`direccion`='"+direccion.getText()+"',`id_categoria_productos`='"+idcategoria.getSelectedIndex()+"' WHERE `id_proveedores` ='"+idproveedor.getText()+"'";
            //String consulta="UPDATE `proveedores` SET `id_proveedores` = '"+idproveedor.getText()+"', `nombre` = '"+descripcion.getText()+"', `telefono` = '"+telefono.getText()+"', `direccion_correo` = '"+correo.getText()+"', `direccion` = '"+direccion.getText()+"', `id_categoria_productos` = '"+idcategoria.getSelectedIndex()+"' WHERE `proveedores`.`id_proveedores` = "+idproveedor.getText()+"";
            String consulta = "UPDATE `inventario_combustible` SET `recibido`='"+caja_recibido_diesel.getText()+"',`recibido_plg3`='"+recibido_litro_diesel.getText()+"',`inventario_inicial`='"+inv_inicial.getText()+"',`inventario_inicial_plg3`='"+invinicial_litro_diesel.getText()+"',`litros_faltantes`='"+caja_litfaltantes_diesel.getText()+"',`litros_faltantes_plg3`='"+caja_plg_litfaltantes.getText()+"',`despacho`='"+caja_despa_diesel.getText()+"',`despacho_plg3`='"+despachado_litro_diesel.getText()+"',`inventario_final`='"+inv_final.getText()+"',`inventario_final_plg3`='"+caja_plg_invfinal.getText()+"',`id_usuario`='"+id.getText()+"',`id_tipo_combustible`='"+tipocom.getText()+"' WHERE `inventario_combustible`.`id_inventario` = '"+idcom.getText()+"'";
            PreparedStatement pst  = cn.prepareStatement(consulta);
           
            
            
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "LOS DATOS HAN SIDO MODIFICADOS");
            cargar("");
            limpiarcajas1();
            
           
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex);
        
        } 
    }//GEN-LAST:event_modificar_insertActionPerformed

    private void tabla_inventarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabla_inventarioMouseClicked
        // TODO add your handling code here:
        int seleccionar = tabla_inventario.rowAtPoint(evt.getPoint());
        idcom.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,0)));
        caja_recibido_diesel.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,1)));
        caja_plg_recibido.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,2)));
        
        
        inv_inicial.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,3)));
        caja_plg_invinicial.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,4)));
        
        caja_litfaltantes_diesel.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,5)));
        caja_plg_litfaltantes.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,6)));
        
        caja_despa_diesel.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,7)));
        caja_plg_despachado.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,8)));
        
        inv_final.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,9)));
        caja_plg_invfinal.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,10)));
        
        id.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,11)));
        tipocom.setText(String.valueOf(tabla_inventario.getValueAt(seleccionar,12)));
        iidtipocomb.setSelectedItem(String.valueOf(tabla_inventario.getValueAt(seleccionar,12)));
        
        
        
    }//GEN-LAST:event_tabla_inventarioMouseClicked

    private void iidtipocombActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iidtipocombActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iidtipocombActionPerformed

    private void iidtipocombKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_iidtipocombKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_iidtipocombKeyPressed

    private void caja_recibido_dieselActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_caja_recibido_dieselActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_caja_recibido_dieselActionPerformed

    private void caja_despa_dieselActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_caja_despa_dieselActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_caja_despa_dieselActionPerformed

    private void caja_recibido_dieselKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_caja_recibido_dieselKeyTyped
        // TODO add your handling code here:
           char validar =evt.getKeyChar();
        
        if(Character.isLetter(validar)||Character.isSpaceChar(validar)){
        getToolkit().beep();
        evt.consume();
        error1.setText("Solo numeros y sin espacios");
        }
        if(!Character.isDigit(evt.getKeyChar())&& evt.getKeyChar()!='.' ){
            evt.consume();
  }        if(evt.getKeyChar()=='.'&&caja_litfaltantes_diesel.getText().contains(".")){
          evt.consume(); }
    }//GEN-LAST:event_caja_recibido_dieselKeyTyped

    private void buscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_buscarKeyReleased
        // TODO add your handling code here:
        cargar(buscar.getText());
    }//GEN-LAST:event_buscarKeyReleased

    private void inv_inicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inv_inicialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inv_inicialActionPerformed

    private void inv_inicialKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inv_inicialKeyTyped
        // TODO add your handling code here:
            char validar =evt.getKeyChar();
        
        if(Character.isLetter(validar)||Character.isSpaceChar(validar)){
        getToolkit().beep();
        evt.consume();
        error2.setText("Solo numeros y sin espacios");
        }
        if(!Character.isDigit(evt.getKeyChar())&& evt.getKeyChar()!='.' ){
            evt.consume();
  }        if(evt.getKeyChar()=='.'&&caja_litfaltantes_diesel.getText().contains(".")){
          evt.consume(); }
    }//GEN-LAST:event_inv_inicialKeyTyped

    private void caja_despa_dieselKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_caja_despa_dieselKeyTyped
        // TODO add your handling code here:
        char validar =evt.getKeyChar();
        
        if(Character.isLetter(validar)||Character.isSpaceChar(validar)){
        getToolkit().beep();
        evt.consume();
        error3.setText("Solo numeros y sin espacios");
        }
        if(!Character.isDigit(evt.getKeyChar())&& evt.getKeyChar()!='.' ){
            evt.consume();
  }        if(evt.getKeyChar()=='.'&&caja_litfaltantes_diesel.getText().contains(".")){
          evt.consume(); }
    }//GEN-LAST:event_caja_despa_dieselKeyTyped

    private void inv_finalKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inv_finalKeyTyped
        // TODO add your handling code here:
        char validar =evt.getKeyChar();
        
        if(Character.isLetter(validar)||Character.isSpaceChar(validar)){
        getToolkit().beep();
        evt.consume();
        error4.setText("Solo numeros y sin espacios");
        }
        if(!Character.isDigit(evt.getKeyChar())&& evt.getKeyChar()!='.' ){
            evt.consume();
  }        if(evt.getKeyChar()=='.'&&caja_litfaltantes_diesel.getText().contains(".")){
          evt.consume(); }
    }//GEN-LAST:event_inv_finalKeyTyped

    private void caja_litfaltantes_dieselKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_caja_litfaltantes_dieselKeyTyped
        // TODO add your handling code here:
        char validar =evt.getKeyChar();
        
        if(Character.isLetter(validar)||Character.isSpaceChar(validar)){
        getToolkit().beep();
        evt.consume();
        error5.setText("Solo numeros y sin espacios");
        }
        if(!Character.isDigit(evt.getKeyChar())&& evt.getKeyChar()!='.' ){
            evt.consume();
  }        if(evt.getKeyChar()=='.'&&caja_litfaltantes_diesel.getText().contains(".")){
          evt.consume(); }
    }//GEN-LAST:event_caja_litfaltantes_dieselKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ingreso_Inventario_Combustible.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ingreso_Inventario_Combustible.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ingreso_Inventario_Combustible.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ingreso_Inventario_Combustible.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ingreso_Inventario_Combustible().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button Conversion_button;
    private java.awt.Button Limpiar;
    private java.awt.Button atras;
    private javax.swing.JTextField buscar;
    private javax.swing.JTextField caja_despa_diesel;
    private javax.swing.JTextField caja_litfaltantes_diesel;
    private javax.swing.JLabel caja_plg_despachado;
    private javax.swing.JLabel caja_plg_invfinal;
    private javax.swing.JLabel caja_plg_invinicial;
    private javax.swing.JLabel caja_plg_litfaltantes;
    private javax.swing.JLabel caja_plg_recibido;
    private javax.swing.JTextField caja_recibido_diesel;
    private javax.swing.JLabel despachado_litro_diesel;
    private javax.swing.JLabel error1;
    private javax.swing.JLabel error11;
    private javax.swing.JLabel error12;
    private javax.swing.JLabel error13;
    private javax.swing.JLabel error14;
    private javax.swing.JLabel error15;
    private javax.swing.JLabel error2;
    private javax.swing.JLabel error3;
    private javax.swing.JLabel error4;
    private javax.swing.JLabel error5;
    private javax.swing.JLabel fecha_pantalla;
    private javax.swing.JLabel fecha_pantalla1;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel id;
    private javax.swing.JLabel idcom;
    private javax.swing.JComboBox iidtipocomb;
    private java.awt.Button ingresar_diesel;
    private javax.swing.JTextField inv_final;
    private javax.swing.JTextField inv_inicial;
    private javax.swing.JLabel invfinal_litro_diesel;
    private javax.swing.JLabel invinicial_litro_diesel;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_iconotecnogas;
    private javax.swing.JLabel litfaltantes_litro_diesel;
    private java.awt.Button modificar_insert;
    private javax.swing.JLabel recibido_litro_diesel;
    private javax.swing.JTable tabla_inventario;
    private java.awt.TextField textField31;
    private javax.swing.JLabel tipocom;
    public static javax.swing.JLabel useInventario;
    // End of variables declaration//GEN-END:variables
}
