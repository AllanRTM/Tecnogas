/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistematecnogas;


import Atxy2k.CustomTextField.RestrictedTextField;
import java.sql.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import servicios.conexion;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import java.awt.Dimension;
import java.awt.Graphics;
import java.text.DecimalFormat;
import javax.swing.ImageIcon;
import static sistematecnogas.panelcentral.fecha;

/**
 *
 * @author Alfon
 */
public final class SerieMecanicas extends javax.swing.JFrame {
final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SerieMecanicas.class);
    DefaultTableModel model;   
    Statement sent;
    conexion cc = new conexion();
    Connection Conn = cc.conexion();
    public class Imagen extends javax.swing.JPanel {
 

 
//Se crea un método cuyo parámetro debe ser un objeto Graphics
 
public void paint(Graphics grafico) {
Dimension height = getSize();
 
//Se selecciona la imagen que tenemos en el paquete de la //ruta del programa
 
ImageIcon Img = new ImageIcon(getClass().getResource("/imagenes/logo_tecnogas_transp.png")); 
 
//se dibuja la imagen que tenemos en el paquete Images //dentro de un panel
 
grafico.drawImage(Img.getImage(), 0, 0, height.width, height.height, null);
 
setOpaque(false);
super.paintComponent(grafico);
}
}
    void validar(){
    RestrictedTextField limitar0 =new RestrictedTextField(txtapertura);
    limitar0.setLimit(10);
    
    
    RestrictedTextField limitar1 =new RestrictedTextField(txtcierre);
    limitar1.setLimit(10);
    
    RestrictedTextField limitar2 =new RestrictedTextField(txtlps);
    limitar2.setLimit(6);
     
    RestrictedTextField limitar3 =new RestrictedTextField(txtlit);
    limitar3.setLimit(6);
    
    
    
   
    
    }
    
    Connection cn = cc.conexion();
    
    public SerieMecanicas() {
        
        initComponents();
        setLocationRelativeTo(null);
        cargar("");
        validar();
        fecha_pantalla.setText(fecha());
        asteriscoapertura.setVisible(false);
        astcierre.setVisible(false);
        astlps.setVisible(false);
        astlit.setVisible(false);
        
  
        try{
        sent=Conn.createStatement();
        String sql="SELECT * FROM `bombas` WHERE `estado` = 'activo'";
             java.sql.Statement st=Conn.createStatement();
        java.sql.ResultSet rs=sent.executeQuery(sql);
        comboidbomba.addItem("seleccione estado");
        while(rs.next()){ 
        this.comboidbomba.addItem(rs.getString("id_bombas"));
        }
        }catch(Exception e){
            
        } 
   
  
           
          
          
     
    

    
    DecimalFormat formateador=new DecimalFormat("#,###,###,###.##");
    String texto=txtapertura.getText();
    try{
      Number numero = formateador.parse(texto);
      double valor=numero.doubleValue();
    }catch(Exception e){
        
    }
    
    DecimalFormat formateadorc=new DecimalFormat("#,###,###,###.##");
    String cierre=txtcierre.getText();
    try{
      Number numero = formateador.parse(texto);
      double valor=numero.doubleValue();
    }catch(Exception e){
        
    }
    
    DecimalFormat formateadorlps=new DecimalFormat("#,###,###,###.##");
    String textolps=txtlps.getText();
    try{
      Number numero = formateador.parse(texto);
      double valor=numero.doubleValue();
    }catch(Exception e){
        
    }
    
    DecimalFormat formateadorlit=new DecimalFormat("#,###,###,###.##");
    String textolit=txtlit.getText();
    try{
      Number numero = formateador.parse(texto);
      double valor=numero.doubleValue();
    }catch(Exception e){
        
    }
    
    
    
    }
    public void forma(String v){
    DecimalFormat formateadorlit=new DecimalFormat("#,###,###,###.##");
    
    try{
      Number numero = formateadorlit.parse(v);
      double valor=numero.doubleValue();
    }catch(Exception e){
        
    }
    }
     
    
  public void Limpiar(){
        
        txtid.setText("");
        txtapertura.setText("");
        txtcierre.setText("");
        txtlit.setText(""); 
        txtlps.setText("");
        FDC.setText("");
        FDA.setText("");
        comboidbomba.setSelectedIndex(0);

    }
  
  
   
    void cargar(String valor){
    
    String mostrar="SELECT `id_series_mecanica`, `apertura_serie_mecanica`, `cierre_serie_mecanica`, `fecha_creacion_serie_mecanica`, `fecha_actualizacion_serie_mecanica`, `lempiras`, `litros_mecanica`, `id_bombas` FROM `series_mecanicas` WHERE `id_series_mecanica` LIKE '%"+valor+"%'";
    String []titulos={"Id serie mecanica","Apertura","Cierre","Fecha creacion","Fecha actualizacion","lempiras","Litros","Id cierre caja"};
    String []Registros=new String[12];
    DefaultTableModel modell = new DefaultTableModel(null,titulos);
  
        try {
              Statement st = Conn.createStatement();
              ResultSet rs = st.executeQuery(mostrar);
              
              while(rs.next())
              {
                  
                  Registros[0]= rs.getString("id_series_mecanica");
                  Registros[1]= rs.getString("apertura_serie_mecanica");
                  Registros[2]= rs.getString("cierre_serie_mecanica");
                  Registros[3]= rs.getString("fecha_creacion_serie_mecanica");
                  Registros[4]= rs.getString("fecha_actualizacion_serie_mecanica");
                  Registros[5]= rs.getString("lempiras");
                  Registros[6]= rs.getString("litros_mecanica");
                  Registros[7]= rs.getString("id_bombas");
                  
                  
                           
                  modell.addRow(Registros);
              }
              tabc.setModel(modell);
        } catch (java.sql.SQLException ex) {
            Logger.getLogger(SerieMecanicas.class.getName()).log(Level.SEVERE, null, ex);
        }
    
  }
   
       
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        txtapertura = new javax.swing.JTextField();
        txtcierre = new javax.swing.JTextField();
        txtlps = new javax.swing.JTextField();
        useMecanica = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        fecha_pantalla = new javax.swing.JLabel();
        txtlit = new javax.swing.JTextField();
        btninsertar = new javax.swing.JButton();
        comboidbomba = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabc = new javax.swing.JTable();
        mod = new javax.swing.JButton();
        lim = new javax.swing.JButton();
        FDC = new javax.swing.JLabel();
        FDA = new javax.swing.JLabel();
        busca = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        asteriscoapertura = new javax.swing.JLabel();
        astcierre = new javax.swing.JLabel();
        astlps = new javax.swing.JLabel();
        astlit = new javax.swing.JLabel();
        txtid = new javax.swing.JLabel();
        validarlempiras = new javax.swing.JLabel();
        validarlitros = new javax.swing.JLabel();
        atras = new javax.swing.JButton();
        valapertura = new javax.swing.JLabel();
        valcierre = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        label_iconotecnogas = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        error1 = new javax.swing.JLabel();
        annu1 = new javax.swing.JLabel();
        annu = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtapertura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtaperturaActionPerformed(evt);
            }
        });
        txtapertura.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtaperturaKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtaperturaKeyTyped(evt);
            }
        });
        jPanel1.add(txtapertura, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 156, 85, -1));

        txtcierre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtcierreKeyTyped(evt);
            }
        });
        jPanel1.add(txtcierre, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 190, 85, -1));

        txtlps.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtlpsActionPerformed(evt);
            }
        });
        txtlps.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtlpsKeyTyped(evt);
            }
        });
        jPanel1.add(txtlps, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 219, 85, -1));

        useMecanica.setText("....");
        jPanel1.add(useMecanica, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 60, 100, -1));

        jLabel7.setText("Usuario:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, -1, -1));

        jLabel1.setText("Id serie");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 125, -1, -1));

        jLabel3.setText("Apertura");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 159, -1, -1));

        jLabel4.setText("Cierre");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 193, -1, -1));

        jLabel5.setText("Lempiras");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 229, -1, -1));

        jLabel6.setText("Litros");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 261, -1, -1));

        jLabel9.setText("Fecha de creacion");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 58, -1, -1));

        jLabel10.setText("Fecha actualizacion");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 95, -1, -1));

        jLabel13.setText("Id bombas ");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 252, -1, 22));

        jLabel8.setText("Fecha:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, -1, -1));

        fecha_pantalla.setText("....");
        jPanel1.add(fecha_pantalla, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 30, 90, -1));

        txtlit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtlitActionPerformed(evt);
            }
        });
        txtlit.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtlitKeyTyped(evt);
            }
        });
        jPanel1.add(txtlit, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 255, 85, -1));

        btninsertar.setText("Ingresar");
        btninsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btninsertarActionPerformed(evt);
            }
        });
        jPanel1.add(btninsertar, new org.netbeans.lib.awtextra.AbsoluteConstraints(399, 355, 116, -1));

        jPanel1.add(comboidbomba, new org.netbeans.lib.awtextra.AbsoluteConstraints(399, 253, 105, -1));

        tabc.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tabc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabcMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabc);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 390, 980, 101));

        mod.setText("Modificar");
        mod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modActionPerformed(evt);
            }
        });
        jPanel1.add(mod, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 513, 119, -1));

        lim.setText("Limpiar");
        lim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limActionPerformed(evt);
            }
        });
        jPanel1.add(lim, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 513, 112, -1));

        FDC.setText(".");
        jPanel1.add(FDC, new org.netbeans.lib.awtextra.AbsoluteConstraints(437, 57, 105, 14));

        FDA.setText(".");
        jPanel1.add(FDA, new org.netbeans.lib.awtextra.AbsoluteConstraints(437, 94, 105, 14));

        busca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscaActionPerformed(evt);
            }
        });
        busca.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                buscaKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buscaKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                buscaKeyTyped(evt);
            }
        });
        jPanel1.add(busca, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 356, 84, -1));

        jLabel12.setText("Buscar:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 359, -1, -1));

        asteriscoapertura.setForeground(new java.awt.Color(255, 51, 0));
        asteriscoapertura.setText("*");
        jPanel1.add(asteriscoapertura, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 159, 14, -1));

        astcierre.setForeground(new java.awt.Color(255, 51, 0));
        astcierre.setText("*");
        jPanel1.add(astcierre, new org.netbeans.lib.awtextra.AbsoluteConstraints(209, 193, -1, -1));

        astlps.setForeground(new java.awt.Color(255, 51, 0));
        astlps.setText("*");
        jPanel1.add(astlps, new org.netbeans.lib.awtextra.AbsoluteConstraints(209, 222, -1, -1));

        astlit.setForeground(new java.awt.Color(255, 51, 0));
        astlit.setText("*");
        jPanel1.add(astlit, new org.netbeans.lib.awtextra.AbsoluteConstraints(209, 261, -1, -1));

        txtid.setText(".");
        jPanel1.add(txtid, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 125, 15, -1));

        validarlempiras.setForeground(new java.awt.Color(255, 51, 0));
        validarlempiras.setText("...");
        jPanel1.add(validarlempiras, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 222, -1, -1));

        validarlitros.setForeground(new java.awt.Color(255, 51, 0));
        validarlitros.setText("...");
        jPanel1.add(validarlitros, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 257, -1, -1));

        atras.setText("Atrás");
        atras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atrasActionPerformed(evt);
            }
        });
        jPanel1.add(atras, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 513, 114, -1));

        valapertura.setForeground(new java.awt.Color(255, 51, 0));
        valapertura.setText("...");
        jPanel1.add(valapertura, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 159, -1, -1));

        valcierre.setForeground(new java.awt.Color(255, 51, 0));
        valcierre.setText("...");
        jPanel1.add(valcierre, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 193, -1, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(51, 153, 255));
        jLabel17.setText("Serie mecanica");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 18, -1, -1));

        label_iconotecnogas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/logo_tecnogas_transp.png"))); // NOI18N
        label_iconotecnogas.setText("jLabel4");
        label_iconotecnogas.setPreferredSize(new java.awt.Dimension(270, 134));
        jPanel1.add(label_iconotecnogas, new org.netbeans.lib.awtextra.AbsoluteConstraints(542, 148, 220, 120));

        jLabel14.setText("con una serie mecanica que tiene fisicamente la bomba.");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 53, 387, -1));

        jLabel2.setText("Informacion: Esta pantalla es para llevar el control de litros en la bombas");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 18, 353, 29));

        error1.setForeground(new java.awt.Color(255, 51, 0));
        error1.setText("...");
        jPanel1.add(error1, new org.netbeans.lib.awtextra.AbsoluteConstraints(209, 359, 163, -1));

        annu1.setText("....");
        jPanel1.add(annu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 540, 120, -1));

        annu.setText("....");
        jPanel1.add(annu, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 360, 170, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/fondo5.jpg"))); // NOI18N
        fondo.setText("jLabel4");
        jPanel1.add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, 590));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1033, 562));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtaperturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtaperturaActionPerformed
        // TODO add your handling code here:
        forma(txtapertura.getText());
    }//GEN-LAST:event_txtaperturaActionPerformed

    private void btninsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btninsertarActionPerformed
       
        
        
        String cap="";
        String sql="SELECT * FROM `seriedigitalrol` WHERE `nombre` = '"+useMecanica.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("insertar"); 
            }
            if(cap.equals("Activo"))
            {
             
                try {
                    if(txtapertura.getText().equals("")){
                    asteriscoapertura.setVisible(true);
        
                    }
                   if(txtcierre.getText().equals("")){
                   astcierre.setVisible(true);
                   }
                   if(txtlps.getText().equals("")){
                   astlps.setVisible(true);
                   }
                  if(txtlit.getText().equals("")){
                  astlit.setVisible(true);
                  }
                  String apertura = "";
                  String cierre ="";
                  double cierr=0;
                   
    if (Double.parseDouble(txtapertura.getText())>=Double.parseDouble(txtcierre.getText())||Double.parseDouble(txtapertura.getText())==0||Double.parseDouble(txtcierre.getText())==0) {
             JOptionPane.showMessageDialog(null, "El cierre no puede ser menor que la apertura", "Error", JOptionPane.ERROR_MESSAGE);
        }
    else{
        apertura=txtapertura.getText();
        cierre=txtcierre.getText();
        cierr=Double.parseDouble(txtcierre.getText());
    }
    
 
           
        double tlps = 0;
        double tlit = 0;
        String lempiras="";
        String litros="";
        
       if(Double.parseDouble(txtlit.getText())==0||Double.parseDouble(txtlps.getText())==0){
             JOptionPane.showMessageDialog(null, "Porfavor ingrese un valor mayor a 0", "Error", JOptionPane.ERROR_MESSAGE);
        }else{
       lempiras=txtlps.getText();
       litros=txtlit.getText();
       }
       
       tlit=cierr+Double.parseDouble(txtlps.getText());
       tlps=Double.parseDouble(txtlps.getText())*Double.parseDouble(txtlit.getText());
      
        
       String S ="INSERT INTO `series_mecanicas` (`id_series_mecanica`, `apertura_serie_mecanica`, `cierre_serie_mecanica`, `fecha_creacion_serie_mecanica`, `fecha_actualizacion_serie_mecanica`, `lempiras`, `litros_mecanica`, `id_bombas`) VALUES (NULL, '"+apertura+"', '"+cierre+"', SYSDATE(), SYSDATE(), '"+lempiras+"', '"+litros+"', '"+comboidbomba.getSelectedIndex()+"')";
     
       PreparedStatement ps=Conn.prepareCall(S);
                
      
        int n=ps.executeUpdate();
            if(n>0)
            JOptionPane.showMessageDialog(null, "datos guardados");
        cargar("");
       }
       catch(Exception e){
           JOptionPane.showMessageDialog(null, "error: "+ e);       
       } 
                
            }
            else{
            btninsertar.setEnabled(true);
            annu.setText("No tienes permiso");
            logger.info("El usuario "+useMecanica.getText()+" inserto categoria. ");
            }
        } catch (java.sql.SQLException ex) {
           
            logger.fatal("Error: "+ex);
            
        }  


    }//GEN-LAST:event_btninsertarActionPerformed

    private void txtaperturaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtaperturaKeyTyped
        // TODO add your handling code here:
         char validar=evt.getKeyChar();
        if(Character.isLetter(validar)){
            getToolkit().beep();
            evt.consume();
            valapertura.setText("Ingresar solo numeros");
        }
        
         if (txtapertura.getText().equals("")) {
            asteriscoapertura.setText("*");
        } else {
            asteriscoapertura.setText("");
        }
         
if(!Character.isDigit(evt.getKeyChar())&& evt.getKeyChar()!='.' ){
            evt.consume();
        }        if(evt.getKeyChar()=='.'&&txtapertura.getText().contains(".")){
            evt.consume();
        }
        
    }//GEN-LAST:event_txtaperturaKeyTyped

    private void txtcierreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtcierreKeyTyped
        // TODO add your handling code here:
         char validar=evt.getKeyChar();
        if(Character.isLetter(validar)){
            getToolkit().beep();
            evt.consume();
            valcierre.setText("Ingresar solo numeros");
        }
        
   
    
    if(!Character.isDigit(evt.getKeyChar())&& evt.getKeyChar()!='.' ){
            evt.consume();
        }        if(evt.getKeyChar()=='.'&&txtcierre.getText().contains(".")){
            evt.consume();
        }
    
         
    }//GEN-LAST:event_txtcierreKeyTyped

    private void txtlpsKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtlpsKeyTyped
        // TODO add your handling code here:
        
         char validar=evt.getKeyChar();
         if(Character.isLetter(validar)){
        getToolkit().beep();
        evt.consume();
        validarlempiras.setText("Ingresar solo numeros");
        }
         
          if(!Character.isDigit(evt.getKeyChar())&& evt.getKeyChar()!='.' ){
            evt.consume();
        }        if(evt.getKeyChar()=='.'&&txtlps.getText().contains(".")){
            evt.consume();
        }
        
        
    }//GEN-LAST:event_txtlpsKeyTyped

    private void txtlitKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtlitKeyTyped
        // TODO add your handling code here:
         char validar=evt.getKeyChar();
        if(Character.isLetter(validar)){
            getToolkit().beep();
            evt.consume();
            validarlitros.setText("Ingresar solo numeros");
        }
         
          
          if(!Character.isDigit(evt.getKeyChar())&& evt.getKeyChar()!='.' ){
            evt.consume();
        }        if(evt.getKeyChar()=='.'&&txtlit.getText().contains(".")){
            evt.consume();
        }
        
    }//GEN-LAST:event_txtlitKeyTyped

    private void txtlpsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtlpsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtlpsActionPerformed

    private void txtlitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtlitActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtlitActionPerformed

    private void limActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limActionPerformed
        // TODO add your handling code here:
        Limpiar();
    }//GEN-LAST:event_limActionPerformed

    private void modActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modActionPerformed
        
        String cap="";
         
        String sql="SELECT * FROM `seriedigitalrol` WHERE `nombre` = '"+useMecanica.getText()+"'";
        try {
            Statement st = cn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                cap=rs.getString("modificar"); 
            }
            if(cap.equals("Activo"))
            {
             
              try {
            
      String apertura = "";
      String cierre ="";
      double cierr=0;
    if (Double.parseDouble(txtapertura.getText())>=Double.parseDouble(txtcierre.getText())) {
             JOptionPane.showMessageDialog(null, "El cierre no puede ser menor que la apertura y debe ser mayor a 0","Error",JOptionPane.ERROR_MESSAGE);
        }
    else{
        apertura=txtapertura.getText();
        cierre=txtcierre.getText();
        cierr=Double.parseDouble(txtcierre.getText());
    }
 
           
        double tlps = 0;
        double tlit = 0;
        String lempiras="";
        String litros="";
        
       if(Double.parseDouble(txtlit.getText())==0||Double.parseDouble(txtlps.getText())==0){
             JOptionPane.showMessageDialog(null, "Porfavor ingrese un valor mayor a 0");
        }else{
       lempiras=txtlps.getText();
       litros=txtlit.getText();
       }
       
       tlit=cierr+Double.parseDouble(txtlps.getText());
       tlps=Double.parseDouble(txtlit.getText())*Double.parseDouble(txtlps.getText());
          String w="UPDATE `series_mecanicas` SET `apertura_serie_mecanica` = '"+apertura+"', `cierre_serie_mecanica` = '"+cierre+"', `fecha_actualizacion_serie_mecanica` = SYSDATE(), `lempiras` = '"+tlit+"', `litros_mecanica` = '"+tlps+"', `id_bombas` = '"+comboidbomba.getSelectedIndex()+"' WHERE `series_mecanicas`.`id_series_mecanica` = '"+txtid.getText()+"'";
             
       //String sql= "UPDATE `series_mecanicas` SET `apertura_serie_mecanica` = '"+apertura+"', `cierre_serie_mecanica` = '"+cierre+"', `fecha_actualizacion_serie_mecanica` = SYSDATE(), `lempiras` = '"+lempiras+"', `litros_mecanica` = '"+litros+"', `lempiras_totales` = '"+tlps+"', `total_litros_mecanica` = '"+tlit+"', `id_bombas` = '"+comboidbomba.getSelectedIndex()+"', `id_cierre_caja` = ,`id_productos`='' WHERE `series_mecanicas`.`id_series_mecanica` = '"+txtid.getText()+"'";
            PreparedStatement pst  = Conn.prepareStatement(w);
           
            
            
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "LOS DATOS HAN SIDO MODIFICADOS");
            cargar("");
            
           
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Ingrese los datos correctamente","Error",JOptionPane.ERROR_MESSAGE);
        
        }  
                
            }
            else{
            btninsertar.setEnabled(true);
            annu1.setText("No tienes permiso");
            logger.info("El usuario "+useMecanica.getText()+" inserto categoria. ");
            }
        } catch (java.sql.SQLException ex) {
            
            logger.fatal("Error: "+ex);
            
        }  
        
    
        
    }//GEN-LAST:event_modActionPerformed

    private void tabcMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabcMouseClicked
        // TODO add your handling code here:
         int seleccionar = tabc.rowAtPoint(evt.getPoint());
        txtid.setText(String.valueOf(tabc.getValueAt(seleccionar, 0)));
        txtapertura.setText(String.valueOf(tabc.getValueAt(seleccionar, 1)));
        txtcierre.setText(String.valueOf(tabc.getValueAt(seleccionar, 2)));
         FDC.setText(String.valueOf(tabc.getValueAt(seleccionar, 3)));
        FDA.setText(String.valueOf(tabc.getValueAt(seleccionar, 4)));
        txtlps.setText(String.valueOf(tabc.getValueAt(seleccionar, 5)));
        txtlit.setText(String.valueOf(tabc.getValueAt(seleccionar, 6)));  
        comboidbomba.setSelectedItem(String.valueOf(tabc.getValueAt(seleccionar, 7)));
       
        
       
    }//GEN-LAST:event_tabcMouseClicked

    private void buscaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscaActionPerformed
        // TODO add your handling code here:
         cargar(busca.getText());
    }//GEN-LAST:event_buscaActionPerformed

    private void buscaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_buscaKeyReleased
        // TODO add your handling code here:
        cargar(busca.getText());
    }//GEN-LAST:event_buscaKeyReleased

    private void txtaperturaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtaperturaKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtaperturaKeyPressed

    private void atrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atrasActionPerformed
        // TODO add your handling code here:
        
        Serie botonatras = new Serie();
        botonatras.setVisible(true);
        Serie.usuSerie.setText(useMecanica.getText());
        this.dispose();
        
    }//GEN-LAST:event_atrasActionPerformed

    private void buscaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_buscaKeyPressed
        // TODO add your handling code here:
        cargar("");
    }//GEN-LAST:event_buscaKeyPressed

    private void buscaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_buscaKeyTyped
        // TODO add your handling code here:
          char validar =evt.getKeyChar();
        
        if(Character.isLetter(validar)){
        getToolkit().beep();
        evt.consume();
        error1.setText("Solo se puede buscar por ID !!");
        }
    }//GEN-LAST:event_buscaKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SerieMecanicas().setVisible(true);
            }
        });
    }
     
    
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel FDA;
    private javax.swing.JLabel FDC;
    private javax.swing.JLabel annu;
    private javax.swing.JLabel annu1;
    private javax.swing.JLabel astcierre;
    private javax.swing.JLabel asteriscoapertura;
    private javax.swing.JLabel astlit;
    private javax.swing.JLabel astlps;
    private javax.swing.JButton atras;
    private javax.swing.JButton btninsertar;
    private javax.swing.JTextField busca;
    private javax.swing.JComboBox<String> comboidbomba;
    private javax.swing.JLabel error1;
    private javax.swing.JLabel fecha_pantalla;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel label_iconotecnogas;
    private javax.swing.JButton lim;
    private javax.swing.JButton mod;
    private javax.swing.JTable tabc;
    private javax.swing.JTextField txtapertura;
    private javax.swing.JTextField txtcierre;
    private javax.swing.JLabel txtid;
    private javax.swing.JTextField txtlit;
    private javax.swing.JTextField txtlps;
    public static javax.swing.JLabel useMecanica;
    private javax.swing.JLabel valapertura;
    private javax.swing.JLabel valcierre;
    private javax.swing.JLabel validarlempiras;
    private javax.swing.JLabel validarlitros;
    // End of variables declaration//GEN-END:variables

    private void setOpaque(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
